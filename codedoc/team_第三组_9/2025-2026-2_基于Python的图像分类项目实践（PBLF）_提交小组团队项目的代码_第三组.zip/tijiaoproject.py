团队项目——图像分类实践
选择合适的实践主题，完成以下任务：
•	搜集主题分类相关的图片作为数据集（划分训练图片和测试图片）
•	使用图像增强的方法进行数据集增强
•	使用Paddle接口进行模型训练
•	训练后，选择一个未参与训练的数据集，使用推理接口，使用评价指标评价模型的识别效果（最基本的是准确率，可以扩展其他指标，自行计算）
•	运行结果保存为合适版本然后提交
In [15]
import paddle
print(paddle.__version__)
3.0.0
In [ ]

#数据集增强
"""import os
import cv2
import math
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import random

# 保持原始Img类和DotMatrix函数不变
def DotMatrix(A,B):
    if len(A[0]) == len(B):
        result = [[0 for _ in range(len(B[0]))] for _ in range(len(A))]
        for i in range(len(A)):
            for j in range(len(B[0])):
                for k in range(len(B)):
                    result[i][j] += A[i][k] * B[k][j]
        return result
    else:
        return ('输入矩阵有误！')

class Img:
    def __init__(self, image, rows=None, cols=None, center=None):
        self.src = np.array(image) if isinstance(image, Image.Image) else image
        self.rows, self.cols = rows or self.src.shape[0], cols or self.src.shape[1]
        self.center = center or [self.cols//2, self.rows//2]
        self.channels = self.src.shape[2] if len(self.src.shape) == 3 else 1
        
    def Move(self, delta_x, delta_y):
        """平移变换"""
        self.transform = np.array([
            [1, 0, delta_x],
            [0, 1, delta_y],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Zoom(self, factor):
        """缩放变换"""
        self.transform = np.array([
            [factor, 0, self.center[0] * (1 - factor)],
            [0, factor, self.center[1] * (1 - factor)],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Horizontal(self):
        """水平镜像"""
        self.transform = np.array([
            [-1, 0, self.cols - 1],
            [0, 1, 0],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Vertically(self):
        """垂直镜像"""
        self.transform = np.array([
            [1, 0, 0],
            [0, -1, self.rows - 1],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Rotate(self, beta):
        """旋转变换（弧度制）"""
        cos_beta = math.cos(beta)
        sin_beta = math.sin(beta)
        tx = self.center[0] * (1 - cos_beta) + self.center[1] * sin_beta
        ty = -self.center[0] * sin_beta + self.center[1] * (1 - cos_beta)
        
        self.transform = np.array([
            [cos_beta, -sin_beta, tx],
            [sin_beta, cos_beta, ty],
            [0, 0, 1]
        ])
        self._process_and_display()

    def _process_and_display(self):
        """处理变换并显示结果"""
        self.Process()
        img2 = Image.fromarray(self.dst)
        plt.figure(figsize=(8, 8))
        plt.imshow(img2)
        plt.axis('off')
        plt.show()

    def Process(self):
        """应用变换矩阵处理图像"""
        # 根据源图像通道数初始化目标图像
        if self.channels == 1:
            self.dst = np.zeros((self.rows, self.cols), dtype=np.uint8)
        else:
            self.dst = np.zeros((self.rows, self.cols, self.channels), dtype=np.uint8)
        
        inv_transform = np.linalg.inv(self.transform)
        
        for i in range(self.rows):
            for j in range(self.cols):
                dst_pos = np.array([[j], [i], [1]])
                [[x], [y], [_]] = np.dot(inv_transform, dst_pos)
                
                x, y = int(x), int(y)
                
                if 0 <= x < self.cols and 0 <= y < self.rows:
                    if self.channels == 1:
                        self.dst[i, j] = self.src[y, x]
                    else:
                        # 只取RGB通道，忽略Alpha通道
                        if self.src.shape[2] == 4 and self.dst.shape[2] == 3:
                            self.dst[i, j] = self.src[y, x, :3]
                        else:
                            self.dst[i, j] = self.src[y, x]
                else:
                    if self.channels == 1:
                        self.dst[i, j] = 255
                    else:
                        self.dst[i, j] = [255] * self.channels
# 新增：保存处理后的图像
def save_transformed_image(img_obj, output_path, transform_name):
    """保存变换后的图像"""
    img2 = Image.fromarray(img_obj.dst)
    img2.save(output_path)
    print(f"{transform_name} 变换后的图像已保存至: {output_path}")

# 新增：处理单个图像文件
def process_image_file(input_path, output_dir, filename):
    """处理单个图像文件，应用所有变换并保存结果"""
    try:
        # 读取图像
        img = Image.open(input_path)
        img_obj = Img(img)
        
        # 创建输出文件夹（如果不存在）
        os.makedirs(output_dir, exist_ok=True)
        
        # 获取文件名和扩展名
        base_name, ext = os.path.splitext(filename)
        
        # 应用平移变换
        img_obj.Move(50, 50)  # 向右下平移50像素
        output_path = os.path.join(output_dir, f"{base_name}_move{ext}")
        save_transformed_image(img_obj, output_path, "平移")
        
        # 应用缩放变换
        img_obj.Zoom(0.7)  # 缩小到70%
        output_path = os.path.join(output_dir, f"{base_name}_zoom{ext}")
        save_transformed_image(img_obj, output_path, "缩放")
        
        # 应用水平镜像
        img_obj.Horizontal()
        output_path = os.path.join(output_dir, f"{base_name}_horizontal{ext}")
        save_transformed_image(img_obj, output_path, "水平镜像")
        
        # 应用垂直镜像
        img_obj.Vertically()
        output_path = os.path.join(output_dir, f"{base_name}_vertically{ext}")
        save_transformed_image(img_obj, output_path, "垂直镜像")
        
        # 应用旋转变换
        img_obj.Rotate(math.radians(45))  # 旋转45度
        output_path = os.path.join(output_dir, f"{base_name}_rotate{ext}")
        save_transformed_image(img_obj, output_path, "旋转")
        
        print(f"已完成处理: {filename}")
        
    except Exception as e:
        print(f"处理文件 {filename} 时出错: {str(e)}")

# 新增：处理文件夹中的所有图像
def process_images_in_folder(input_folder, output_folder):
    """处理文件夹中的所有图像文件"""
    # 支持的图像文件格式
    supported_formats = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
    
    # 检查输入文件夹是否存在
    if not os.path.exists(input_folder):
        print(f"输入文件夹不存在: {input_folder}")
        return
    
    # 获取所有图像文件
    image_files = [f for f in os.listdir(input_folder) 
                  if os.path.isfile(os.path.join(input_folder, f)) 
                  and os.path.splitext(f)[1].lower() in supported_formats]
    
    if not image_files:
        print(f"在 {input_folder} 中未找到支持的图像文件")
        return
    
    # 处理每个图像文件
    for filename in image_files:
        input_path = os.path.join(input_folder, filename)
        process_image_file(input_path, output_folder, filename)
    
    print(f"所有图像处理完成！共处理 {len(image_files)} 个文件")

# 主函数
def main():
    input_folder = "/home/aistudio/data1/training"  
    output_folder = "/home/aistudio/data2/train"  
    

    process_images_in_folder(input_folder, output_folder)

if __name__ == "__main__":
    main()"""
In [16]
import os
import random


# 定义图片所在的根文件夹路径

root_folder = "/home/aistudio/wholedata/food-11/train"
# 定义类别标签对应关系字典
label_dict = {
    "海鲜": 0,
    "米饭": 1,
    "面包": 2,
    "肉类": 3
}

# 用于存储所有图片的路径和对应标签信息
all_images_info = []

# 递归遍历文件夹获取所有图片路径及对应标签
def traverse_folder(folder_path):
    category = os.path.basename(folder_path)
    if category not in label_dict:
        print(f"警告: 未知类别 '{category}'，跳过处理")
        return 0
    
    label = label_dict[category]
    image_count = 0
    
    # 遍历文件夹中的所有文件
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_extension = os.path.splitext(file)[1].lower()
            if file_extension in [".jpg", ".png", ".jpeg"]:  # 可根据实际图片格式调整
                image_path = os.path.join(root, file)
                all_images_info.append((image_path, label))
                image_count += 1
    
    print(f"类别 '{category}' 共有 {image_count} 张图片")
    return image_count

# 分别对四个子文件夹进行遍历
sub_folders = ["海鲜", "米饭", "面包", "肉类"]
total_images = 0

for sub_folder in sub_folders:
    sub_folder_path = os.path.join(root_folder, sub_folder)
    if os.path.isdir(sub_folder_path):
        count = traverse_folder(sub_folder_path)
        total_images += count
    else:
        print(f"警告: 文件夹 '{sub_folder_path}' 不存在")

# 生成统一的train.txt文件
with open("train.txt", "w") as train_file:
    for image_path, label in all_images_info:
        train_file.write(f"{image_path} {label}\n")

print(f"已生成统一的 train.txt 文件，包含 {total_images} 张图片")
类别 '海鲜' 共有 767 张图片
类别 '米饭' 共有 276 张图片
类别 '面包' 共有 994 张图片
类别 '肉类' 共有 1331 张图片
已生成统一的 train.txt 文件，包含 3368 张图片
In [17]
import os
import random


# 定义图片所在的根文件夹路径

root_folder = "/home/aistudio/wholedata/food-11/test"
# 定义类别标签对应关系字典
label_dict = {
    "海鲜": 0,
    "米饭": 1,
    "面包": 2,
    "肉类": 3
}

# 用于存储所有图片的路径和对应标签信息
all_images_info = []

# 递归遍历文件夹获取所有图片路径及对应标签
def traverse_folder(folder_path):
    category = os.path.basename(folder_path)
    if category not in label_dict:
        print(f"警告: 未知类别 '{category}'，跳过处理")
        return 0
    
    label = label_dict[category]
    image_count = 0
    
    # 遍历文件夹中的所有文件
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_extension = os.path.splitext(file)[1].lower()
            if file_extension in [".jpg", ".png", ".jpeg"]:  # 可根据实际图片格式调整
                image_path = os.path.join(root, file)
                all_images_info.append((image_path, label))
                image_count += 1
    
    print(f"类别 '{category}' 共有 {image_count} 张图片")
    return image_count

# 分别对四个子文件夹进行遍历
sub_folders = ["海鲜", "米饭", "面包", "肉类"]
total_images = 0

for sub_folder in sub_folders:
    sub_folder_path = os.path.join(root_folder, sub_folder)
    if os.path.isdir(sub_folder_path):
        count = traverse_folder(sub_folder_path)
        total_images += count
    else:
        print(f"警告: 文件夹 '{sub_folder_path}' 不存在")

# 生成统一的train.txt文件
with open("test.txt", "w") as train_file:
    for image_path, label in all_images_info:
        train_file.write(f"{image_path} {label}\n")

print(f"已生成统一的 text.txt 文件，包含 {total_images} 张图片")
类别 '海鲜' 共有 303 张图片
类别 '米饭' 共有 96 张图片
类别 '面包' 共有 368 张图片
类别 '肉类' 共有 432 张图片
已生成统一的 text.txt 文件，包含 1199 张图片
In [19]
import os
import cv2 
import numpy as np
from paddle.io import Dataset
from paddle.vision.transforms import Normalize
from paddle.vision.transforms import Compose, Resize, Normalize
class MyDataset(Dataset):
    def __init__(self, data_dir, label_path, transform=None):
        super().__init__()
        self.data_list = []
        with open(label_path, encoding="utf-8") as f:
            for line in f.readlines():
                image_path, label = line.strip().split(" ")
                image_path = os.path.join(data_dir, image_path)
                self.data_list.append([image_path, label])
        self.transform = transform

    def __getitem__(self, idx):
        img_path, label = self.data_list[idx]
        
        img = cv2.imread(img_path)
        if img is None:
            print(f"警告: 无法读取图像 {img_path}")
            return np.zeros((3, 224, 224), dtype=np.float32), 0  # 默认标签设为0（可自定义）
            
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        if self.transform:
            img = self.transform(img)
            
        # 转换标签为整数
        try:
            label = int(label)
        except ValueError:
            print(f"警告: 无效标签 {label}，已自动修正为0")
            label = 0  # 处理异常标签
        
        return img, label

    def __len__(self):
        return len(self.data_list)


# 定义图像归一化处理（保持不变）
transform = Normalize(mean=[127.5], std=[127.5], data_format="CHW")
train_custom_dataset = MyDataset("/home/aistudio/wholedata/food-11/train", "/home/aistudio/train.txt", transform)
test_custom_dataset = MyDataset("/home/aistudio/wholedata/food-11/test", "/home/aistudio/test.txt", transform)
from paddle.vision.transforms import Resize
transform = Compose([Resize((224, 224)), Normalize(mean=[127.5], std=[127.5], data_format="CHW")])
In [20]
import os
import cv2
import numpy as np
import paddle
from paddle.io import Dataset, DataLoader

# 自定义数据集类
class GarbageDataset(Dataset):
    def __init__(self, data_list, transform=None):
        self.data_list = data_list  # 格式: [(img_path, label), ...]
        self.transform = transform
        
    def __getitem__(self, idx):
        img_path, label = self.data_list[idx]
        
        try:
            # 读取图像
            img = cv2.imread(img_path)
            if img is None:
                print(f"警告: 图像文件为空或无法读取: {img_path}")
                return np.zeros((3, 224, 224), dtype=np.float32), label
            
            # 转换颜色空间
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            
            # 应用图像变换
            if self.transform:
                img = self.transform(img)
                
            # 调整图像尺寸（根据模型输入调整）
            if img.shape != (3, 224, 224):
                img = cv2.resize(img, (224, 224)).transpose((2, 0, 1))
                
            return img.astype(np.float32), label
            
        except Exception as e:
            print(f"处理图像时出错: {img_path}, 错误: {str(e)}")
            return np.zeros((3, 224, 224), dtype=np.float32), label
    
    def __len__(self):
        return len(self.data_list)

# 创建数据集的函数（之前缺失的部分）
def create_dataset(root_dir, image_extensions=[".jpg", ".jpeg", ".png"]):
    """
    从根目录创建数据集，假设文件夹结构为 root_dir/类别名/图片.jpg
    """
    data_list = []
    # 获取所有子文件夹作为类别
    categories = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]
    
    if not categories:
        raise ValueError(f"在 {root_dir} 下未找到类别文件夹")
    
    # 为每个类别分配标签（0, 1, 2...）
    label_dict = {category: i for i, category in enumerate(categories)}
    print(f"检测到的类别: {label_dict}")
    
    # 遍历每个类别文件夹
    for category, label in label_dict.items():
        category_dir = os.path.join(root_dir, category)
        if not os.path.exists(category_dir):
            continue
            
        # 遍历类别中的所有图片
        for img_name in os.listdir(category_dir):
            file_ext = os.path.splitext(img_name)[1].lower()
            if file_ext in image_extensions:
                img_path = os.path.join(category_dir, img_name)
                data_list.append((img_path, label))
    
    print(f"总共找到 {len(data_list)} 张图像")
    return GarbageDataset(data_list)

# 数据转换函数
def transform(img):
    # 归一化处理
    img = img / 255.0
    # 转换为PaddleTensor格式
    img = paddle.to_tensor(img)
    return img

# 设置数据根目录
root_folder = "/home/aistudio/wholedata/food-11/train"  # 修改为实际数据路径

# 创建数据集
train_custom_dataset = create_dataset(root_folder)

# 定义并初始化数据加载器
train_loader = DataLoader(
    train_custom_dataset,
    batch_size=32,
    shuffle=True,
    num_workers=0,
    drop_last=True,
)

print("开始测试数据加载...")

# 测试数据加载
try:
    for batch_id, (images, labels) in enumerate(train_loader):
        print(
            "batch_id: {}, 训练数据shape: {}, 标签数据shape: {}".format(
                batch_id, images.shape, labels.shape
            )
        )
        print("标签内容:", labels.numpy())
        break  # 只处理一个批次
    
    print("数据加载测试成功完成!")
    
except Exception as e:
    print(f"数据加载过程中出错: {str(e)}")
    import traceback
    traceback.print_exc()
检测到的类别: {'海鲜': 0, '面包': 1, '米饭': 2, '肉类': 3}
总共找到 3359 张图像
开始测试数据加载...
batch_id: 0, 训练数据shape: [32, 3, 224, 224], 标签数据shape: [32]
标签内容: [0 3 0 0 0 0 3 0 0 3 1 1 1 1 3 1 1 3 3 1 3 3 3 3 3 3 3 0 2 1 1 1]
数据加载测试成功完成!
In [21]
images, labels=train_custom_dataset.__getitem__(3)
print("训练数据shape: {}, 标签数据shape: {}".format(images.shape, labels))
训练数据shape: (3, 224, 224), 标签数据shape: 0
In [22]
from paddle.io import DataLoader
# 定义并初始化数据读取器
train_loader = DataLoader(
    train_custom_dataset,
    batch_size=32,
    shuffle=True,
    num_workers=1,#同步/异步读取数据，通过 num_workers 来设置加载数据的子进程个数，num_workers的值设为大于0时，即开启多进程方式异步加载数据，可提升数据读取速度。
    drop_last=True,
)
In [23]
for batch_id, data in enumerate(train_loader()):
    images, labels = data

    print("batch_id: {}, 训练数据shape: {}, 标签数据shape: {}".format(batch_id, images.shape, labels))
团队项目——图像分类实践
选择合适的实践主题，完成以下任务：
•	搜集主题分类相关的图片作为数据集（划分训练图片和测试图片）
•	使用图像增强的方法进行数据集增强
•	使用Paddle接口进行模型训练
•	训练后，选择一个未参与训练的数据集，使用推理接口，使用评价指标评价模型的识别效果（最基本的是准确率，可以扩展其他指标，自行计算）
•	运行结果保存为合适版本然后提交
In [15]
import paddle
print(paddle.__version__)
3.0.0
In [ ]

#数据集增强
"""import os
import cv2
import math
import numpy as np
from PIL import Image
import matplotlib.pyplot as plt
import random

# 保持原始Img类和DotMatrix函数不变
def DotMatrix(A,B):
    if len(A[0]) == len(B):
        result = [[0 for _ in range(len(B[0]))] for _ in range(len(A))]
        for i in range(len(A)):
            for j in range(len(B[0])):
                for k in range(len(B)):
                    result[i][j] += A[i][k] * B[k][j]
        return result
    else:
        return ('输入矩阵有误！')

class Img:
    def __init__(self, image, rows=None, cols=None, center=None):
        self.src = np.array(image) if isinstance(image, Image.Image) else image
        self.rows, self.cols = rows or self.src.shape[0], cols or self.src.shape[1]
        self.center = center or [self.cols//2, self.rows//2]
        self.channels = self.src.shape[2] if len(self.src.shape) == 3 else 1
        
    def Move(self, delta_x, delta_y):
        """平移变换"""
        self.transform = np.array([
            [1, 0, delta_x],
            [0, 1, delta_y],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Zoom(self, factor):
        """缩放变换"""
        self.transform = np.array([
            [factor, 0, self.center[0] * (1 - factor)],
            [0, factor, self.center[1] * (1 - factor)],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Horizontal(self):
        """水平镜像"""
        self.transform = np.array([
            [-1, 0, self.cols - 1],
            [0, 1, 0],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Vertically(self):
        """垂直镜像"""
        self.transform = np.array([
            [1, 0, 0],
            [0, -1, self.rows - 1],
            [0, 0, 1]
        ])
        self._process_and_display()

    def Rotate(self, beta):
        """旋转变换（弧度制）"""
        cos_beta = math.cos(beta)
        sin_beta = math.sin(beta)
        tx = self.center[0] * (1 - cos_beta) + self.center[1] * sin_beta
        ty = -self.center[0] * sin_beta + self.center[1] * (1 - cos_beta)
        
        self.transform = np.array([
            [cos_beta, -sin_beta, tx],
            [sin_beta, cos_beta, ty],
            [0, 0, 1]
        ])
        self._process_and_display()

    def _process_and_display(self):
        """处理变换并显示结果"""
        self.Process()
        img2 = Image.fromarray(self.dst)
        plt.figure(figsize=(8, 8))
        plt.imshow(img2)
        plt.axis('off')
        plt.show()

    def Process(self):
        """应用变换矩阵处理图像"""
        # 根据源图像通道数初始化目标图像
        if self.channels == 1:
            self.dst = np.zeros((self.rows, self.cols), dtype=np.uint8)
        else:
            self.dst = np.zeros((self.rows, self.cols, self.channels), dtype=np.uint8)
        
        inv_transform = np.linalg.inv(self.transform)
        
        for i in range(self.rows):
            for j in range(self.cols):
                dst_pos = np.array([[j], [i], [1]])
                [[x], [y], [_]] = np.dot(inv_transform, dst_pos)
                
                x, y = int(x), int(y)
                
                if 0 <= x < self.cols and 0 <= y < self.rows:
                    if self.channels == 1:
                        self.dst[i, j] = self.src[y, x]
                    else:
                        # 只取RGB通道，忽略Alpha通道
                        if self.src.shape[2] == 4 and self.dst.shape[2] == 3:
                            self.dst[i, j] = self.src[y, x, :3]
                        else:
                            self.dst[i, j] = self.src[y, x]
                else:
                    if self.channels == 1:
                        self.dst[i, j] = 255
                    else:
                        self.dst[i, j] = [255] * self.channels
# 新增：保存处理后的图像
def save_transformed_image(img_obj, output_path, transform_name):
    """保存变换后的图像"""
    img2 = Image.fromarray(img_obj.dst)
    img2.save(output_path)
    print(f"{transform_name} 变换后的图像已保存至: {output_path}")

# 新增：处理单个图像文件
def process_image_file(input_path, output_dir, filename):
    """处理单个图像文件，应用所有变换并保存结果"""
    try:
        # 读取图像
        img = Image.open(input_path)
        img_obj = Img(img)
        
        # 创建输出文件夹（如果不存在）
        os.makedirs(output_dir, exist_ok=True)
        
        # 获取文件名和扩展名
        base_name, ext = os.path.splitext(filename)
        
        # 应用平移变换
        img_obj.Move(50, 50)  # 向右下平移50像素
        output_path = os.path.join(output_dir, f"{base_name}_move{ext}")
        save_transformed_image(img_obj, output_path, "平移")
        
        # 应用缩放变换
        img_obj.Zoom(0.7)  # 缩小到70%
        output_path = os.path.join(output_dir, f"{base_name}_zoom{ext}")
        save_transformed_image(img_obj, output_path, "缩放")
        
        # 应用水平镜像
        img_obj.Horizontal()
        output_path = os.path.join(output_dir, f"{base_name}_horizontal{ext}")
        save_transformed_image(img_obj, output_path, "水平镜像")
        
        # 应用垂直镜像
        img_obj.Vertically()
        output_path = os.path.join(output_dir, f"{base_name}_vertically{ext}")
        save_transformed_image(img_obj, output_path, "垂直镜像")
        
        # 应用旋转变换
        img_obj.Rotate(math.radians(45))  # 旋转45度
        output_path = os.path.join(output_dir, f"{base_name}_rotate{ext}")
        save_transformed_image(img_obj, output_path, "旋转")
        
        print(f"已完成处理: {filename}")
        
    except Exception as e:
        print(f"处理文件 {filename} 时出错: {str(e)}")

# 新增：处理文件夹中的所有图像
def process_images_in_folder(input_folder, output_folder):
    """处理文件夹中的所有图像文件"""
    # 支持的图像文件格式
    supported_formats = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
    
    # 检查输入文件夹是否存在
    if not os.path.exists(input_folder):
        print(f"输入文件夹不存在: {input_folder}")
        return
    
    # 获取所有图像文件
    image_files = [f for f in os.listdir(input_folder) 
                  if os.path.isfile(os.path.join(input_folder, f)) 
                  and os.path.splitext(f)[1].lower() in supported_formats]
    
    if not image_files:
        print(f"在 {input_folder} 中未找到支持的图像文件")
        return
    
    # 处理每个图像文件
    for filename in image_files:
        input_path = os.path.join(input_folder, filename)
        process_image_file(input_path, output_folder, filename)
    
    print(f"所有图像处理完成！共处理 {len(image_files)} 个文件")

# 主函数
def main():
    input_folder = "/home/aistudio/data1/training"  
    output_folder = "/home/aistudio/data2/train"  
    

    process_images_in_folder(input_folder, output_folder)

if __name__ == "__main__":
    main()"""
In [16]
import os
import random


# 定义图片所在的根文件夹路径

root_folder = "/home/aistudio/wholedata/food-11/train"
# 定义类别标签对应关系字典
label_dict = {
    "海鲜": 0,
    "米饭": 1,
    "面包": 2,
    "肉类": 3
}

# 用于存储所有图片的路径和对应标签信息
all_images_info = []

# 递归遍历文件夹获取所有图片路径及对应标签
def traverse_folder(folder_path):
    category = os.path.basename(folder_path)
    if category not in label_dict:
        print(f"警告: 未知类别 '{category}'，跳过处理")
        return 0
    
    label = label_dict[category]
    image_count = 0
    
    # 遍历文件夹中的所有文件
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_extension = os.path.splitext(file)[1].lower()
            if file_extension in [".jpg", ".png", ".jpeg"]:  # 可根据实际图片格式调整
                image_path = os.path.join(root, file)
                all_images_info.append((image_path, label))
                image_count += 1
    
    print(f"类别 '{category}' 共有 {image_count} 张图片")
    return image_count

# 分别对四个子文件夹进行遍历
sub_folders = ["海鲜", "米饭", "面包", "肉类"]
total_images = 0

for sub_folder in sub_folders:
    sub_folder_path = os.path.join(root_folder, sub_folder)
    if os.path.isdir(sub_folder_path):
        count = traverse_folder(sub_folder_path)
        total_images += count
    else:
        print(f"警告: 文件夹 '{sub_folder_path}' 不存在")

# 生成统一的train.txt文件
with open("train.txt", "w") as train_file:
    for image_path, label in all_images_info:
        train_file.write(f"{image_path} {label}\n")

print(f"已生成统一的 train.txt 文件，包含 {total_images} 张图片")
类别 '海鲜' 共有 767 张图片
类别 '米饭' 共有 276 张图片
类别 '面包' 共有 994 张图片
类别 '肉类' 共有 1331 张图片
已生成统一的 train.txt 文件，包含 3368 张图片
In [17]
import os
import random


# 定义图片所在的根文件夹路径

root_folder = "/home/aistudio/wholedata/food-11/test"
# 定义类别标签对应关系字典
label_dict = {
    "海鲜": 0,
    "米饭": 1,
    "面包": 2,
    "肉类": 3
}

# 用于存储所有图片的路径和对应标签信息
all_images_info = []

# 递归遍历文件夹获取所有图片路径及对应标签
def traverse_folder(folder_path):
    category = os.path.basename(folder_path)
    if category not in label_dict:
        print(f"警告: 未知类别 '{category}'，跳过处理")
        return 0
    
    label = label_dict[category]
    image_count = 0
    
    # 遍历文件夹中的所有文件
    for root, _, files in os.walk(folder_path):
        for file in files:
            file_extension = os.path.splitext(file)[1].lower()
            if file_extension in [".jpg", ".png", ".jpeg"]:  # 可根据实际图片格式调整
                image_path = os.path.join(root, file)
                all_images_info.append((image_path, label))
                image_count += 1
    
    print(f"类别 '{category}' 共有 {image_count} 张图片")
    return image_count

# 分别对四个子文件夹进行遍历
sub_folders = ["海鲜", "米饭", "面包", "肉类"]
total_images = 0

for sub_folder in sub_folders:
    sub_folder_path = os.path.join(root_folder, sub_folder)
    if os.path.isdir(sub_folder_path):
        count = traverse_folder(sub_folder_path)
        total_images += count
    else:
        print(f"警告: 文件夹 '{sub_folder_path}' 不存在")

# 生成统一的train.txt文件
with open("test.txt", "w") as train_file:
    for image_path, label in all_images_info:
        train_file.write(f"{image_path} {label}\n")

print(f"已生成统一的 text.txt 文件，包含 {total_images} 张图片")
类别 '海鲜' 共有 303 张图片
类别 '米饭' 共有 96 张图片
类别 '面包' 共有 368 张图片
类别 '肉类' 共有 432 张图片
已生成统一的 text.txt 文件，包含 1199 张图片
In [19]
import os
import cv2 
import numpy as np
from paddle.io import Dataset
from paddle.vision.transforms import Normalize
from paddle.vision.transforms import Compose, Resize, Normalize
class MyDataset(Dataset):
    def __init__(self, data_dir, label_path, transform=None):
        super().__init__()
        self.data_list = []
        with open(label_path, encoding="utf-8") as f:
            for line in f.readlines():
                image_path, label = line.strip().split(" ")
                image_path = os.path.join(data_dir, image_path)
                self.data_list.append([image_path, label])
        self.transform = transform

    def __getitem__(self, idx):
        img_path, label = self.data_list[idx]
        
        img = cv2.imread(img_path)
        if img is None:
            print(f"警告: 无法读取图像 {img_path}")
            return np.zeros((3, 224, 224), dtype=np.float32), 0  # 默认标签设为0（可自定义）
            
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        
        if self.transform:
            img = self.transform(img)
            
        # 转换标签为整数
        try:
            label = int(label)
        except ValueError:
            print(f"警告: 无效标签 {label}，已自动修正为0")
            label = 0  # 处理异常标签
        
        return img, label

    def __len__(self):
        return len(self.data_list)


# 定义图像归一化处理（保持不变）
transform = Normalize(mean=[127.5], std=[127.5], data_format="CHW")
train_custom_dataset = MyDataset("/home/aistudio/wholedata/food-11/train", "/home/aistudio/train.txt", transform)
test_custom_dataset = MyDataset("/home/aistudio/wholedata/food-11/test", "/home/aistudio/test.txt", transform)
from paddle.vision.transforms import Resize
transform = Compose([Resize((224, 224)), Normalize(mean=[127.5], std=[127.5], data_format="CHW")])
In [20]
import os
import cv2
import numpy as np
import paddle
from paddle.io import Dataset, DataLoader

# 自定义数据集类
class GarbageDataset(Dataset):
    def __init__(self, data_list, transform=None):
        self.data_list = data_list  # 格式: [(img_path, label), ...]
        self.transform = transform
        
    def __getitem__(self, idx):
        img_path, label = self.data_list[idx]
        
        try:
            # 读取图像
            img = cv2.imread(img_path)
            if img is None:
                print(f"警告: 图像文件为空或无法读取: {img_path}")
                return np.zeros((3, 224, 224), dtype=np.float32), label
            
            # 转换颜色空间
            img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            
            # 应用图像变换
            if self.transform:
                img = self.transform(img)
                
            # 调整图像尺寸（根据模型输入调整）
            if img.shape != (3, 224, 224):
                img = cv2.resize(img, (224, 224)).transpose((2, 0, 1))
                
            return img.astype(np.float32), label
            
        except Exception as e:
            print(f"处理图像时出错: {img_path}, 错误: {str(e)}")
            return np.zeros((3, 224, 224), dtype=np.float32), label
    
    def __len__(self):
        return len(self.data_list)

# 创建数据集的函数（之前缺失的部分）
def create_dataset(root_dir, image_extensions=[".jpg", ".jpeg", ".png"]):
    """
    从根目录创建数据集，假设文件夹结构为 root_dir/类别名/图片.jpg
    """
    data_list = []
    # 获取所有子文件夹作为类别
    categories = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]
    
    if not categories:
        raise ValueError(f"在 {root_dir} 下未找到类别文件夹")
    
    # 为每个类别分配标签（0, 1, 2...）
    label_dict = {category: i for i, category in enumerate(categories)}
    print(f"检测到的类别: {label_dict}")
    
    # 遍历每个类别文件夹
    for category, label in label_dict.items():
        category_dir = os.path.join(root_dir, category)
        if not os.path.exists(category_dir):
            continue
            
        # 遍历类别中的所有图片
        for img_name in os.listdir(category_dir):
            file_ext = os.path.splitext(img_name)[1].lower()
            if file_ext in image_extensions:
                img_path = os.path.join(category_dir, img_name)
                data_list.append((img_path, label))
    
    print(f"总共找到 {len(data_list)} 张图像")
    return GarbageDataset(data_list)

# 数据转换函数
def transform(img):
    # 归一化处理
    img = img / 255.0
    # 转换为PaddleTensor格式
    img = paddle.to_tensor(img)
    return img

# 设置数据根目录
root_folder = "/home/aistudio/wholedata/food-11/train"  # 修改为实际数据路径

# 创建数据集
train_custom_dataset = create_dataset(root_folder)

# 定义并初始化数据加载器
train_loader = DataLoader(
    train_custom_dataset,
    batch_size=32,
    shuffle=True,
    num_workers=0,
    drop_last=True,
)

print("开始测试数据加载...")

# 测试数据加载
try:
    for batch_id, (images, labels) in enumerate(train_loader):
        print(
            "batch_id: {}, 训练数据shape: {}, 标签数据shape: {}".format(
                batch_id, images.shape, labels.shape
            )
        )
        print("标签内容:", labels.numpy())
        break  # 只处理一个批次
    
    print("数据加载测试成功完成!")
    
except Exception as e:
    print(f"数据加载过程中出错: {str(e)}")
    import traceback
    traceback.print_exc()
检测到的类别: {'海鲜': 0, '面包': 1, '米饭': 2, '肉类': 3}
总共找到 3359 张图像
开始测试数据加载...
batch_id: 0, 训练数据shape: [32, 3, 224, 224], 标签数据shape: [32]
标签内容: [0 3 0 0 0 0 3 0 0 3 1 1 1 1 3 1 1 3 3 1 3 3 3 3 3 3 3 0 2 1 1 1]
数据加载测试成功完成!
In [21]
images, labels=train_custom_dataset.__getitem__(3)
print("训练数据shape: {}, 标签数据shape: {}".format(images.shape, labels))
训练数据shape: (3, 224, 224), 标签数据shape: 0
In [22]
from paddle.io import DataLoader
# 定义并初始化数据读取器
train_loader = DataLoader(
    train_custom_dataset,
    batch_size=32,
    shuffle=True,
    num_workers=1,#同步/异步读取数据，通过 num_workers 来设置加载数据的子进程个数，num_workers的值设为大于0时，即开启多进程方式异步加载数据，可提升数据读取速度。
    drop_last=True,
)
In [23]
for batch_id, data in enumerate(train_loader()):
    images, labels = data

    print("batch_id: {}, 训练数据shape: {}, 标签数据shape: {}".format(batch_id, images.shape, labels))
import paddle.nn as nn
import paddle


# 使用 paddle.nn.Sequential 构建 LeNet 模型
Mynet = nn.Sequential(
    nn.Conv2D(3, 16, 2, stride=1, padding=1),
    nn.ReLU(),
    nn.MaxPool2D(2, 2),
    nn.Conv2D(16, 64, 3, stride=1, padding=0),
    nn.ReLU(),
    nn.MaxPool2D(2, 2),
    nn.Conv2D(64, 128, 3, stride=1, padding=0),
    nn.ReLU(),
    nn.MaxPool2D(2, 2),
    nn.Flatten(1, -1),
    nn.Linear(86528, 120),
    nn.Linear(120, 84),
    nn.Linear(84, 4)
)
# 可视化模型组网结构和参数
paddle.summary(Mynet, (1,3, 224, 224))
---------------------------------------------------------------------------
 Layer (type)       Input Shape          Output Shape         Param #    
===========================================================================
   Conv2D-12     [[1, 3, 224, 224]]   [1, 16, 225, 225]         208      
    ReLU-15     [[1, 16, 225, 225]]   [1, 16, 225, 225]          0       
 MaxPool2D-12   [[1, 16, 225, 225]]   [1, 16, 112, 112]          0       
   Conv2D-13    [[1, 16, 112, 112]]   [1, 64, 110, 110]        9,280     
    ReLU-16     [[1, 64, 110, 110]]   [1, 64, 110, 110]          0       
 MaxPool2D-13   [[1, 64, 110, 110]]    [1, 64, 55, 55]           0       
   Conv2D-14     [[1, 64, 55, 55]]     [1, 128, 53, 53]       73,856     
    ReLU-17      [[1, 128, 53, 53]]    [1, 128, 53, 53]          0       
 MaxPool2D-14    [[1, 128, 53, 53]]    [1, 128, 26, 26]          0       
   Flatten-4     [[1, 128, 26, 26]]       [1, 86528]             0       
   Linear-12        [[1, 86528]]           [1, 120]         10,383,480   
   Linear-13         [[1, 120]]            [1, 84]            10,164     
   Linear-14         [[1, 84]]              [1, 4]              340      
===========================================================================
Total params: 10,477,328
Trainable params: 10,477,328
Non-trainable params: 0
---------------------------------------------------------------------------
Input size (MB): 0.57
Forward/backward pass size (MB): 33.99
Params size (MB): 39.97
Estimated Total Size (MB): 74.53
---------------------------------------------------------------------------

{'total_params': 10477328, 'trainable_params': 10477328}
In [26]
import paddle.nn as nn
import paddle

Mynet = nn.Sequential(
    nn.Conv2D(3, 20, 5, stride=1, padding=0),
    nn.ReLU(),
    nn.MaxPool2D(2, 2),
    nn.Conv2D(20, 50, 5, stride=1, padding=0),
    nn.ReLU(),
    nn.MaxPool2D(2, 2),
    nn.Flatten(1, -1),
    nn.Linear(50*3*3, 120),
    nn.ReLU(),
    nn.Linear(120, 84),
    nn.ReLU(),
    nn.Linear(84, 4),
    nn.Softmax(axis=1) 
)
# 可视化模型组网结构和参数
paddle.summary(Mynet, (1,3, 24, 24))
---------------------------------------------------------------------------
 Layer (type)       Input Shape          Output Shape         Param #    
===========================================================================
   Conv2D-15      [[1, 3, 24, 24]]     [1, 20, 20, 20]         1,520     
    ReLU-18      [[1, 20, 20, 20]]     [1, 20, 20, 20]           0       
 MaxPool2D-15    [[1, 20, 20, 20]]     [1, 20, 10, 10]           0       
   Conv2D-16     [[1, 20, 10, 10]]      [1, 50, 6, 6]         25,050     
    ReLU-19       [[1, 50, 6, 6]]       [1, 50, 6, 6]            0       
 MaxPool2D-16     [[1, 50, 6, 6]]       [1, 50, 3, 3]            0       
   Flatten-5      [[1, 50, 3, 3]]          [1, 450]              0       
   Linear-15         [[1, 450]]            [1, 120]           54,120     
    ReLU-20          [[1, 120]]            [1, 120]              0       
   Linear-16         [[1, 120]]            [1, 84]            10,164     
    ReLU-21          [[1, 84]]             [1, 84]               0       
   Linear-17         [[1, 84]]              [1, 4]              340      
   Softmax-2          [[1, 4]]              [1, 4]               0       
===========================================================================
Total params: 91,194
Trainable params: 91,194
Non-trainable params: 0
---------------------------------------------------------------------------
Input size (MB): 0.01
Forward/backward pass size (MB): 0.17
Params size (MB): 0.35
Estimated Total Size (MB): 0.53
---------------------------------------------------------------------------

{'total_params': 91194, 'trainable_params': 91194}
In [27]
class Mynet(nn.Layer):
    def __init__(self, num_classes=10):
        super(Mynet, self).__init__()
        self.features = nn.Sequential(
            # 输入: 3x224x224
            nn.Conv2D(3, 32, kernel_size=3, stride=1, padding=1),  # 32x224x224
            nn.ReLU(),
            nn.MaxPool2D(kernel_size=2, stride=2),  # 32x112x112
            
            nn.Conv2D(32, 64, kernel_size=3, stride=1, padding=1),  # 64x112x112
            nn.ReLU(),
            nn.MaxPool2D(kernel_size=2, stride=2),  # 64x56x56
            
            nn.Conv2D(64, 128, kernel_size=3, stride=1, padding=1),  # 128x56x56
            nn.ReLU(),
            nn.MaxPool2D(kernel_size=2, stride=2),  # 128x28x28
        )
        
        # 计算全连接层输入维度: 128 * 28 * 28 = 100352
        self.classifier = nn.Sequential(
            nn.Linear(100352, 512),  # 修正输入维度
            nn.ReLU(),
            nn.Dropout(0.5),
            nn.Linear(512, num_classes)
        )
    
    def forward(self, x):
        x = self.features(x)
        x = paddle.flatten(x, 1)  # 展平为一维向量
        x = self.classifier(x)
        return x
In [34]
# 导入必要库（建议统一放在文件开头）
import paddle
from paddle import nn
from paddle.io import Dataset
from paddle.vision.transforms import Compose, Resize, Normalize, ToTensor
import cv2
import numpy as np
from matplotlib import pyplot as plt

# 假设已定义好MyDataset类和Mynet模型类...

# 配置设备（取消注释以启用GPU）
# paddle.device.set_device('gpu')

# 定义数据预处理流程
transform = Compose([
    Resize((224, 224)),
    ToTensor(),
    Normalize(mean=[127.5], std=[127.5], data_format="CHW")
])

# 加载数据集（假设路径正确）
train_custom_dataset = MyDataset("/home/aistudio/wholedata/food-11/train", "/home/aistudio/train.txt", transform)
test_custom_dataset = MyDataset("/home/aistudio/wholedata/food-11/test", "/home/aistudio/test.txt", transform)

# 实例化模型
net = Mynet(num_classes=10)
model = paddle.Model(net)

# 模型准备（仅需一次）
model.prepare(
    optimizer=paddle.optimizer.Adam(learning_rate=0.001, parameters=model.parameters()),
    loss=paddle.nn.CrossEntropyLoss(),
    metrics=paddle.metric.Accuracy()
)

# 模型训练（仅需一次）
model.fit(
    train_custom_dataset,
    epochs=5,
    batch_size=64,
    verbose=1
)

# 模型评估
eval_result = model.evaluate(test_custom_dataset, verbose=1)
print("评估结果：", eval_result)

# 模型推理
test_result = model.predict(test_custom_dataset)
print("推理结果形状：", len(test_result), test_result[0].shape)  # 检查形状是否正确

# 可视化单张图片并显示推理结果
def visualize_predictions(dataset, result, index=0):
    # 取出数据并反归一化
    img, true_label = dataset[index]
    img = img.transpose((1, 2, 0))  # CHW -> HWC
    img = (img * 127.5 + 127.5).astype(np.uint8)  # 反归一化回[0, 255]
    
    # 取出预测结果
    pred_scores = result[0][index]
    pred_label = pred_scores.argmax()
    
    # 绘制图像
    plt.figure(figsize=(4, 4))
    plt.imshow(img)
    plt.title(f"真实标签: {true_label}\n预测标签: {pred_label}", fontsize=12)
    plt.axis('off')
    plt.show()

# 调用可视化函数（取第一个样本）
visualize_predictions(test_custom_dataset, test_result)
The loss value printed in the log is the current step, and the metric is the average value of previous steps.
Epoch 1/5
step 53/53 [==============================] - loss: 1.3648 - acc: 0.3379 - 8s/step                           
Epoch 2/5
step 53/53 [==============================] - loss: 1.2986 - acc: 0.3765 - 8s/step                            
Epoch 3/5
step 53/53 [==============================] - loss: 1.2693 - acc: 0.3655 - 8s/step                           
Epoch 4/5
step 53/53 [==============================] - loss: 1.2611 - acc: 0.3750 - 8s/step                           
Epoch 5/5
step 53/53 [==============================] - loss: 1.3208 - acc: 0.3818 - 8s/step                            
Eval begin...
step 1199/1199 [==============================] - loss: 0.8973 - acc: 0.3603 - 36ms/step                            
Eval samples: 1199
评估结果： {'loss': [0.8973417282104492], 'acc': 0.3603002502085071}
Predict begin...
step 1199/1199 [==============================] - 37ms/step                             
Predict samples: 1199
---------------------------------------------------------------------------AttributeError Traceback (most recent call last)Cell In[34], line 51 49 # 模型推理 50 test_result = model.predict(test_custom_dataset) ---> 51 print("推理结果形状：", len(test_result), test_result[0].shape) # 检查形状是否正确 53 # 可视化单张图片并显示推理结果 54 def visualize_predictions(dataset, result, index=0): 55 # 取出数据并反归一化 AttributeError: 'tuple' object has no attribute 'shape'
In [ ]


