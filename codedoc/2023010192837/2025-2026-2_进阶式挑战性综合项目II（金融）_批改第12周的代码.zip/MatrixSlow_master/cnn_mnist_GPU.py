# -*- coding: utf-8 -*-
"""
集成结构化剪枝和混合精度量化的CNN MNIST训练 - GPU版本
基于MatrixSlow框架的GPU加速训练（假设框架支持GPU）
"""

import time
import sys
import copy
import os

sys.path.append('../..')

import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.preprocessing import OneHotEncoder
from MatrixSlow_master import matrixslow as ms

# 修正后的导入
from matrixslow.compression.pruning import StructuredPruner, AdaptivePruner
from matrixslow.compression.quantization import MixedPrecisionQuantizer, QuantizationType, LayerSensitivity

# GPU相关导入（假设MatrixSlow支持）
try:
    import cupy as cp  # CuPy作为GPU加速库

    GPU_AVAILABLE = True
    print("✅ GPU加速库CuPy可用")
except ImportError:
    print("⚠️  CuPy未安装，将使用CPU训练")
    GPU_AVAILABLE = False


class GPUCompressedCNNTrainer:
    """
    支持GPU的集成剪枝和量化CNN训练器
    """

    def __init__(self, pruning_ratio=0.2, enable_quantization=True, enable_pruning=True, use_gpu=True):
        self.pruning_ratio = pruning_ratio
        self.enable_quantization = enable_quantization
        self.enable_pruning = enable_pruning
        self.use_gpu = use_gpu and GPU_AVAILABLE

        # GPU设备检查
        if self.use_gpu:
            try:
                self.device_id = 0  # 使用第一个GPU
                cp.cuda.Device(self.device_id).use()
                print(f"🚀 使用GPU设备: {cp.cuda.Device().id}")
                print(f"   GPU内存: {cp.cuda.Device().mem_info[1] / 1024 ** 3:.1f} GB")
            except Exception as e:
                print(f"⚠️  GPU初始化失败: {e}，回退到CPU")
                self.use_gpu = False
        else:
            print("🖥️  使用CPU训练")

        # 初始化剪枝器和量化器
        if self.enable_pruning:
            self.pruner = AdaptivePruner(
                base_pruning_ratio=pruning_ratio,
                sensitivity_threshold=0.1
            )

        if self.enable_quantization:
            self.quantizer = MixedPrecisionQuantizer(
                default_precision=QuantizationType.INT8,
                sensitivity_threshold=0.1
            )

        self.compression_applied = False
        self.baseline_accuracy = None

    def to_gpu(self, data):
        """将数据转移到GPU"""
        if self.use_gpu and GPU_AVAILABLE:
            if isinstance(data, np.ndarray):
                return cp.asarray(data)
            elif isinstance(data, np.matrix):
                return cp.asmatrix(cp.asarray(data))
        return data

    def to_cpu(self, data):
        """将数据转移到CPU"""
        if self.use_gpu and GPU_AVAILABLE:
            if hasattr(data, 'get'):  # CuPy数组
                return data.get()
        return data

    def load_and_prepare_data(self, num_samples=1000):
        """加载和预处理MNIST数据 - GPU版本"""
        print("📥 加载MNIST数据集...")
        X, y = fetch_openml('mnist_784', version=1, return_X_y=True, parser='auto')
        X, y = X[:num_samples].to_numpy() / 255, y.to_numpy().astype(int)[:num_samples]

        # 将整数形式的标签转换成One-Hot编码
        oh = OneHotEncoder(sparse_output=False)
        one_hot_label = oh.fit_transform(y.reshape(-1, 1))

        # 转移到GPU
        if self.use_gpu:
            print("🚀 将数据转移到GPU...")
            X = self.to_gpu(X)
            one_hot_label = self.to_gpu(one_hot_label)
            print(f"   数据形状: X={X.shape}, labels={one_hot_label.shape}")

        return X, y, one_hot_label

    def build_network_gpu(self):
        """构建支持GPU的CNN网络"""
        print("🏗️  构建GPU CNN网络...")

        # 输入图像尺寸
        img_shape = (28, 28)

        # 假设MatrixSlow支持GPU，在这里设置设备
        if self.use_gpu:
            # 假设的GPU设置语法
            # ms.set_device('gpu:0')  # 假设的API
            pass

        # 输入图像
        x = ms.core.Variable(img_shape, init=False, trainable=False)

        # One-Hot标签
        one_hot = ms.core.Variable(dim=(10, 1), init=False, trainable=False)

        # 第一卷积层
        conv1 = ms.layer.conv([x], img_shape, 3, (5, 5), "ReLU")

        # 第一池化层
        pooling1 = ms.layer.pooling(conv1, (3, 3), (2, 2))

        # 第二卷积层
        conv2 = ms.layer.conv(pooling1, (14, 14), 3, (3, 3), "ReLU")

        # 第二池化层
        pooling2 = ms.layer.pooling(conv2, (3, 3), (2, 2))

        # 全连接层
        fc1 = ms.layer.fc(ms.ops.Concat(*pooling2), 147, 120, "ReLU")

        # 输出层
        output = ms.layer.fc(fc1, 120, 10, "None")

        # 分类概率
        predict = ms.ops.SoftMax(output)

        # 交叉熵损失
        loss = ms.ops.loss.CrossEntropyWithSoftMax(output, one_hot)

        print(f"✅ 网络构建完成，设备: {'GPU' if self.use_gpu else 'CPU'}")

        return x, one_hot, predict, loss, conv1, conv2, fc1, output

    def extract_layer_weights_gpu(self, conv1, conv2, fc1, output):
        """提取各层权重用于压缩 - GPU版本"""
        layer_weights = {}
        layer_nodes = {}

        print("\n🔍 识别网络层权重（GPU版本）:")

        weight_count = 0
        valid_nodes = []

        # 收集所有有效的权重节点
        for node in ms.default_graph.nodes:
            if (isinstance(node, ms.core.Variable) and
                    node.trainable and
                    node.value is not None and
                    node.value.size > 0):
                valid_nodes.append(node)

        print(f"   发现 {len(valid_nodes)} 个候选权重节点")

        # 按照预期顺序识别层
        layer_names = ['conv1', 'conv2', 'fc1', 'output']

        for i, node in enumerate(valid_nodes[:4]):
            if i < len(layer_names):
                layer_name = layer_names[i]

                if len(node.value.shape) == 2 and node.value.shape[0] > 0 and node.value.shape[1] > 0:
                    # 将GPU权重转移到CPU进行压缩分析
                    cpu_weights = self.to_cpu(node.value)
                    layer_weights[layer_name] = cpu_weights
                    layer_nodes[layer_name] = node

                    device_info = "GPU" if self.use_gpu else "CPU"
                    print(f"   ✅ {layer_name}: {node.value.shape} [{device_info}]")
                    weight_count += 1
                else:
                    print(f"   ⚠️  跳过节点 {i}: 形状异常 {node.value.shape}")

        if weight_count == 0:
            print("   ❌ 未识别到有效的权重层")
        else:
            print(f"   📊 成功识别 {weight_count} 个权重层")

        return layer_weights, layer_nodes

    def apply_compression_gpu(self, layer_weights, layer_nodes, current_accuracy=None):
        """应用剪枝和量化压缩 - GPU版本"""
        if self.compression_applied:
            print("压缩已应用，跳过...")
            return

        print("\n" + "=" * 60)
        print("🚀 开始应用GPU模型压缩...")
        print("=" * 60)

        if not layer_weights:
            print("❌ 未找到有效的层权重，跳过压缩")
            return

        print(f"📊 发现 {len(layer_weights)} 个权重层:")
        for name, weights in layer_weights.items():
            print(f"   {name}: {weights.shape}")

        # 在CPU上进行压缩分析和计算
        print("🔄 在CPU上执行压缩计算...")
        compressed_weights = copy.deepcopy(layer_weights)

        # 1. 结构化剪枝（在CPU上）
        if self.enable_pruning:
            print("\n1. 执行结构化剪枝:")
            print("-" * 30)

            try:
                pruning_success = False

                for layer_name, weights in layer_weights.items():
                    print(f"\n🔧 处理层: {layer_name}")

                    if weights.size == 0:
                        print(f"⚠️  {layer_name} 权重为空，跳过")
                        continue

                    if weights.shape[0] <= 1 or weights.shape[1] <= 1:
                        print(f"⚠️  {layer_name} 维度过小 {weights.shape}，跳过")
                        continue

                    try:
                        if layer_name == 'output':
                            original_ratio = self.pruner.base_pruning_ratio
                            self.pruner.base_pruning_ratio = min(0.1, original_ratio)

                            compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
                            self.pruner.base_pruning_ratio = original_ratio
                            pruning_success = True

                        elif weights.shape[0] > 5:
                            compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
                            pruning_success = True
                        else:
                            print(f"   ⚠️  {layer_name} 输出维度过小({weights.shape[0]})，跳过剪枝")

                    except Exception as e:
                        print(f"   ❌ {layer_name} 剪枝失败: {e}")
                        compressed_weights[layer_name] = weights

                if pruning_success:
                    try:
                        pruning_stats = self.pruner.get_pruning_statistics()
                        if 'error' not in pruning_stats:
                            print(f"\n✅ 剪枝完成！总体压缩比例: {pruning_stats['total_compression_ratio']:.2%}")
                            print(f"📉 减少参数数量: {pruning_stats['total_parameter_reduction']:,}")
                    except Exception as e:
                        print(f"⚠️  获取剪枝统计失败: {e}")

            except Exception as e:
                print(f"❌ 剪枝过程出现严重错误: {e}")
                compressed_weights = copy.deepcopy(layer_weights)

        # 2. 混合精度量化（在CPU上）
        if self.enable_quantization:
            print("\n2. 执行混合精度量化:")
            print("-" * 30)

            try:
                custom_precision = {
                    'output': QuantizationType.FP16,
                    'fc1': QuantizationType.INT16
                }

                valid_weights = {}
                for name, weights in compressed_weights.items():
                    if weights.size > 0 and weights.shape[0] > 0 and weights.shape[1] > 0:
                        valid_weights[name] = weights
                        print(f"   ✅ {name}: {weights.shape} - 准备量化")

                if valid_weights:
                    quantized_weights = self.quantizer.quantize_full_model(
                        valid_weights,
                        custom_precision
                    )

                    for name, weights in quantized_weights.items():
                        compressed_weights[name] = weights

                    print("✅ 量化完成")

            except Exception as e:
                print(f"❌ 量化过程失败: {e}")

        # 3. 将压缩后的权重应用回GPU网络
        print("\n3. 应用压缩后的权重到GPU网络:")
        print("-" * 30)

        success_count = 0
        for layer_name, compressed_weight in compressed_weights.items():
            if layer_name in layer_nodes:
                try:
                    node = layer_nodes[layer_name]
                    original_shape = node.value.shape

                    if compressed_weight.shape != original_shape:
                        print(f"   📐 更新 {layer_name}: {original_shape} -> {compressed_weight.shape}")

                        if compressed_weight.size > 0:
                            # 将压缩后的权重转移回GPU
                            gpu_weights = self.to_gpu(compressed_weight)
                            node.set_value(gpu_weights)
                            node.dim = compressed_weight.shape
                            success_count += 1
                            print(f"   ✅ {layer_name} GPU更新成功")
                    else:
                        gpu_weights = self.to_gpu(compressed_weight)
                        node.set_value(gpu_weights)
                        success_count += 1
                        print(f"   ✅ {layer_name} GPU权重已更新")

                except Exception as e:
                    print(f"   ❌ {layer_name} GPU更新失败: {e}")

        if success_count > 0:
            self.compression_applied = True
            print(f"\n✅ 成功更新 {success_count}/{len(compressed_weights)} 个GPU层")

        print("=" * 60)
        if self.compression_applied:
            print("🚀 GPU模型压缩完成！")
        else:
            print("⚠️  GPU模型压缩未完全成功")
        print("=" * 60)

    def train_with_gpu_compression(self, num_epochs=60, batch_size=32, learning_rate=0.005,
                                   compression_epoch=20):
        """
        GPU加速的带压缩训练流程
        """
        print(f"🚀 开始GPU训练（设备: {'GPU' if self.use_gpu else 'CPU'}）")

        # 准备数据
        X, y, one_hot_label = self.load_and_prepare_data()

        # 构建网络
        x, one_hot, predict, loss, conv1, conv2, fc1, output = self.build_network_gpu()

        # 优化器
        optimizer = ms.optimizer.Adam(ms.default_graph, loss, learning_rate)

        # 跟踪最佳精度
        best_accuracy = 0.0
        accuracy_history = []

        print(f"\n🎯 开始训练 - 计划在第 {compression_epoch} 轮应用压缩")
        print("=" * 80)

        # GPU内存监控
        if self.use_gpu:
            print(f"🔍 初始GPU内存使用: {self._get_gpu_memory_usage():.1f} MB")

        for epoch in range(num_epochs):
            start_time = time.time()
            batch_count = 0
            total_loss = 0.0

            # GPU内存监控
            if self.use_gpu and epoch % 10 == 0:
                memory_usage = self._get_gpu_memory_usage()
                print(f"📊 Epoch {epoch} GPU内存: {memory_usage:.1f} MB")

            # 训练一轮
            for i in range(len(X)):
                # 准备数据
                if self.use_gpu:
                    feature = cp.asmatrix(X[i]).reshape((28, 28))
                    label = cp.asmatrix(one_hot_label[i]).T
                else:
                    feature = np.mat(X[i]).reshape((28, 28))
                    label = np.mat(one_hot_label[i]).T

                x.set_value(feature)
                one_hot.set_value(label)

                optimizer.one_step()

                current_loss = loss.value[0, 0]
                total_loss += current_loss

                batch_count += 1
                if batch_count >= batch_size:
                    optimizer.update()

                    if epoch < 5 or epoch % 5 == 0:
                        device_info = "GPU" if self.use_gpu else "CPU"
                        print(
                            f"[{device_info}] epoch: {epoch + 1}, iteration: {i + 1}, loss: {total_loss / batch_count:.6f}")

                    batch_count = 0
                    total_loss = 0.0

            # 计算精度
            pred = []
            for i in range(len(X)):
                if self.use_gpu:
                    feature = cp.asmatrix(X[i]).reshape((28, 28))
                else:
                    feature = np.mat(X[i]).reshape((28, 28))

                x.set_value(feature)
                predict.forward()

                # 将结果转回CPU进行精度计算
                pred_value = self.to_cpu(predict.value.A.ravel())
                pred.append(pred_value)

            pred = np.array(pred).argmax(axis=1)
            y_cpu = self.to_cpu(y)  # 确保y在CPU上
            accuracy = (y_cpu == pred).astype(int).sum() / len(X)
            accuracy_history.append(accuracy)

            if accuracy > best_accuracy:
                best_accuracy = accuracy
                print(f"🎯 新的最佳精度: {best_accuracy:.3f}")

            end_time = time.time()
            epoch_duration = end_time - start_time

            device_info = "GPU" if self.use_gpu else "CPU"
            print(f"[{device_info}] epoch: {epoch + 1}, accuracy: {accuracy:.3f}, "
                  f"best_accuracy: {best_accuracy:.3f}, time: {epoch_duration:.2f}s")

            # 在指定轮次应用压缩
            if epoch + 1 == compression_epoch and not self.compression_applied:
                print(f"\n⚡ 第 {epoch + 1} 轮，开始应用GPU模型压缩...")

                self.baseline_accuracy = accuracy

                # 提取层权重
                layer_weights, layer_nodes = self.extract_layer_weights_gpu(conv1, conv2, fc1, output)

                # 应用压缩
                self.apply_compression_gpu(layer_weights, layer_nodes, accuracy)

                print(f"📊 压缩前精度: {self.baseline_accuracy:.3f}")
                print("继续GPU训练以评估压缩效果...\n")

            # 学习率调整
            if (epoch + 1) % 20 == 0:
                learning_rate *= 0.8
                optimizer.learning_rate = learning_rate
                print(f"📉 学习率调整为: {learning_rate:.6f}")

            print("-" * 80)

        print("\n🎉 GPU训练完成！")
        if self.use_gpu:
            print(f"🔍 最终GPU内存使用: {self._get_gpu_memory_usage():.1f} MB")

        # 最终统计
        final_stats = {
            'best_accuracy': best_accuracy,
            'baseline_accuracy': self.baseline_accuracy,
            'accuracy_history': accuracy_history,
            'compression_applied': self.compression_applied,
            'device': 'GPU' if self.use_gpu else 'CPU'
        }

        if self.compression_applied:
            accuracy_drop = self.baseline_accuracy - best_accuracy if best_accuracy < self.baseline_accuracy else 0
            print(f"📈 最终最佳精度: {best_accuracy:.3f}")
            print(f"📊 压缩前基准精度: {self.baseline_accuracy:.3f}")
            if accuracy_drop > 0:
                print(f"📉 精度下降: {accuracy_drop:.3f} ({accuracy_drop / self.baseline_accuracy * 100:.1f}%)")
            else:
                improvement = best_accuracy - self.baseline_accuracy
                print(f"📈 精度提升: {improvement:.3f} ({improvement / self.baseline_accuracy * 100:.1f}%)")

        return final_stats

    def _get_gpu_memory_usage(self):
        """获取GPU内存使用情况"""
        if self.use_gpu and GPU_AVAILABLE:
            try:
                mempool = cp.get_default_memory_pool()
                return mempool.used_bytes() / 1024 / 1024  # 转换为MB
            except:
                return 0.0
        return 0.0


# GPU训练主函数
def main_gpu():
    """GPU训练主函数"""
    print("🚀 开始GPU集成剪枝和量化的CNN训练")
    print("=" * 80)

    try:
        # 创建GPU训练器
        trainer = GPUCompressedCNNTrainer(
            pruning_ratio=0.2,
            enable_quantization=True,
            enable_pruning=True,
            use_gpu=True  # 启用GPU
        )

        # 开始GPU训练
        stats = trainer.train_with_gpu_compression(
            num_epochs=60,
            batch_size=32,
            learning_rate=0.005,
            compression_epoch=20
        )

        print(f"\n📊 GPU训练统计:")
        print(f"设备: {stats['device']}")
        print(f"最佳精度: {stats['best_accuracy']:.3f}")
        if stats['compression_applied']:
            print(f"压缩前精度: {stats['baseline_accuracy']:.3f}")

        return stats

    except Exception as e:
        print(f"\n❌ GPU训练过程中出现错误: {e}")
        import traceback
        traceback.print_exc()

        print("\n🔧 GPU调试建议:")
        print("1. 检查CUDA和CuPy是否正确安装")
        print("2. 确认GPU驱动程序版本兼容")
        print("3. 检查GPU内存是否充足")
        print("4. 尝试减小batch_size或模型大小")

        return None


if __name__ == "__main__":
    # 运行GPU训练
    gpu_training_stats = main_gpu()