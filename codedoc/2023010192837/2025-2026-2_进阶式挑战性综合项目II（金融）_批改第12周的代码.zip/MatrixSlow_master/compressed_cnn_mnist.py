# # -*- coding: utf-8 -*-
# """
# 修复版本：集成结构化剪枝和混合精度量化的CNN MNIST训练 - 根目录版本
# 适配matrixslow框架的目录结构
# """
#
# import time
# import sys
# import copy
# import os
#
# # 添加当前目录到Python路径
# current_dir = os.path.dirname(os.path.abspath(__file__))
# sys.path.insert(0, current_dir)
#
# import numpy as np
# from sklearn.datasets import fetch_openml
# from sklearn.preprocessing import OneHotEncoder
#
# # 导入MatrixSlow框架
# try:
#     # 从当前目录的matrixslow包导入
#     import matrixslow as ms
#
#     print("✅ 成功导入MatrixSlow框架")
# except ImportError as e:
#     print(f"❌ 无法导入MatrixSlow框架: {e}")
#     print("请确保在包含matrixslow文件夹的根目录下运行此脚本")
#     sys.exit(1)
#
# # 导入压缩模块
# try:
#     # 从matrixslow.compression导入
#     from matrixslow.compression.pruning import StructuredPruner, AdaptivePruner
#     from matrixslow.compression.quantization import MixedPrecisionQuantizer, QuantizationType, LayerSensitivity
#
#     print("✅ 成功导入压缩模块")
# except ImportError as e:
#     print(f"❌ 无法导入压缩模块: {e}")
#     print("请确保compression文件夹在matrixslow目录下，并包含pruning.py和quantization.py")
#     sys.exit(1)
#
# # GPU相关导入
# try:
#     import cupy as cp
#
#     GPU_AVAILABLE = True
#     print("✅ GPU加速库CuPy可用")
# except ImportError:
#     print("⚠️  CuPy未安装，将使用CPU训练")
#     GPU_AVAILABLE = False
#     cp = None
#
#
# class GPUCompressedCNNTrainer:
#     """
#     支持GPU的集成剪枝和量化CNN训练器
#     适配matrixslow框架结构
#     """
#
#     def __init__(self, pruning_ratio=0.2, enable_quantization=True, enable_pruning=True, use_gpu=True):
#         self.pruning_ratio = pruning_ratio
#         self.enable_quantization = enable_quantization
#         self.enable_pruning = enable_pruning
#         self.use_gpu = use_gpu and GPU_AVAILABLE
#
#         print(f"🔧 初始化训练器配置:")
#         print(f"   剪枝比例: {self.pruning_ratio}")
#         print(f"   启用量化: {self.enable_quantization}")
#         print(f"   启用剪枝: {self.enable_pruning}")
#
#         # GPU设备检查
#         if self.use_gpu and cp is not None:
#             try:
#                 self.device_id = 0
#                 cp.cuda.Device(self.device_id).use()
#                 mem_info = cp.cuda.Device().mem_info
#                 total_memory = mem_info[1] / 1024 ** 3
#                 print(f"🚀 使用GPU设备: {cp.cuda.Device().id}")
#                 print(f"   GPU内存: {total_memory:.1f} GB")
#             except Exception as e:
#                 print(f"⚠️  GPU初始化失败: {e}，回退到CPU")
#                 self.use_gpu = False
#         else:
#             print("🖥️  使用CPU训练")
#
#         # 初始化剪枝器和量化器
#         try:
#             if self.enable_pruning:
#                 self.pruner = AdaptivePruner(
#                     base_pruning_ratio=pruning_ratio,
#                     sensitivity_threshold=0.1
#                 )
#                 print("✅ 自适应剪枝器初始化成功")
#
#             if self.enable_quantization:
#                 self.quantizer = MixedPrecisionQuantizer(
#                     default_precision=QuantizationType.INT8,
#                     sensitivity_threshold=0.1
#                 )
#                 print("✅ 混合精度量化器初始化成功")
#
#         except Exception as e:
#             print(f"❌ 压缩模块初始化失败: {e}")
#             raise
#
#         self.compression_applied = False
#         self.baseline_accuracy = None
#
#     def to_gpu(self, data):
#         """安全地将数据转移到GPU"""
#         if self.use_gpu and cp is not None:
#             try:
#                 if isinstance(data, np.ndarray):
#                     return cp.asarray(data)
#                 elif isinstance(data, np.matrix):
#                     return cp.asmatrix(cp.asarray(data))
#             except Exception as e:
#                 print(f"⚠️  GPU转换失败: {e}，使用CPU数据")
#                 return data
#         return data
#
#     def to_cpu(self, data):
#         """安全地将数据转移到CPU"""
#         if self.use_gpu and cp is not None:
#             try:
#                 if hasattr(data, 'get'):  # CuPy数组
#                     return data.get()
#             except Exception as e:
#                 print(f"⚠️  CPU转换失败: {e}")
#         return data
#
#     def load_and_prepare_data(self, num_samples=1000):
#         """加载和预处理MNIST数据"""
#         print("📥 加载MNIST数据集...")
#         try:
#             X, y = fetch_openml('mnist_784', version=1, return_X_y=True, parser='auto')
#             X = X[:num_samples].to_numpy() / 255.0
#             y = y.to_numpy().astype(int)[:num_samples]
#
#             # One-Hot编码
#             oh = OneHotEncoder(sparse_output=False)
#             one_hot_label = oh.fit_transform(y.reshape(-1, 1))
#
#             print(f"📊 数据加载完成: X={X.shape}, y={y.shape}, one_hot={one_hot_label.shape}")
#
#             # 转移到GPU（如果可用）
#             if self.use_gpu:
#                 print("🚀 将数据转移到GPU...")
#                 X = self.to_gpu(X)
#                 one_hot_label = self.to_gpu(one_hot_label)
#                 print(f"   GPU数据形状: X={X.shape}, labels={one_hot_label.shape}")
#
#             return X, y, one_hot_label
#
#         except Exception as e:
#             print(f"❌ 数据加载失败: {e}")
#             raise
#
#     def build_network_gpu(self):
#         """构建CNN网络 - 适配matrixslow框架"""
#         print("🏗️  构建CNN网络...")
#
#         try:
#             # MatrixSlow图管理（不使用clear方法）
#             print(f"   当前图节点数: {len(ms.default_graph.nodes)}")
#
#             # 输入图像尺寸
#             img_shape = (28, 28)
#
#             # 输入变量
#             x = ms.core.Variable(img_shape, init=False, trainable=False)
#             one_hot = ms.core.Variable(dim=(10, 1), init=False, trainable=False)
#
#             # 网络层构建
#             print("   构建卷积层...")
#
#             try:
#                 # 第一卷积层 - 3个5x5卷积核
#                 conv1 = ms.layer.conv([x], img_shape, 3, (5, 5), "ReLU")
#                 print(f"   Conv1构建成功，输出: {len(conv1) if isinstance(conv1, (list, tuple)) else 'single'} 个特征图")
#
#                 # 第一池化层 - 3x3池化，步长2x2
#                 pooling1 = ms.layer.pooling(conv1, (3, 3), (2, 2))
#                 print(f"   Pooling1构建成功")
#
#                 # 第二卷积层 - 3个3x3卷积核，输入14x14
#                 conv2 = ms.layer.conv(pooling1, (14, 14), 3, (3, 3), "ReLU")
#                 print(f"   Conv2构建成功")
#
#                 # 第二池化层
#                 pooling2 = ms.layer.pooling(conv2, (3, 3), (2, 2))
#                 print(f"   Pooling2构建成功")
#
#                 # 展平层 - 连接所有池化输出
#                 flatten = ms.ops.Concat(*pooling2)
#                 print(f"   展平层构建成功")
#
#                 # 全连接层 - 动态计算输入维度
#                 # 先尝试147维，如果不对会在训练时调整
#                 fc1 = ms.layer.fc(flatten, 147, 120, "ReLU")
#                 print(f"   FC1构建成功: ? -> 120")
#
#                 # 输出层 - 120->10
#                 output = ms.layer.fc(fc1, 120, 10, "None")
#                 print(f"   输出层构建成功: 120 -> 10")
#
#                 # 分类概率
#                 predict = ms.ops.SoftMax(output)
#                 print(f"   SoftMax构建成功")
#
#                 # 损失函数
#                 loss = ms.ops.loss.CrossEntropyWithSoftMax(output, one_hot)
#                 print(f"   损失函数构建成功")
#
#             except Exception as layer_error:
#                 print(f"   ❌ 网络层构建出错: {layer_error}")
#                 raise
#
#             device_info = "GPU" if self.use_gpu else "CPU"
#             print(f"✅ 网络构建完成，设备: {device_info}")
#             print(f"   网络节点数: {len(ms.default_graph.nodes)}")
#
#             return x, one_hot, predict, loss, conv1, conv2, fc1, output
#
#         except Exception as e:
#             print(f"❌ 网络构建失败: {e}")
#             import traceback
#             traceback.print_exc()
#             raise
#
#     def extract_layer_weights_gpu(self, conv1, conv2, fc1, output):
#         """提取各层权重用于压缩 - 适配matrixslow"""
#         layer_weights = {}
#         layer_nodes = {}
#
#         print("\n🔍 提取网络层权重:")
#
#         try:
#             # 收集所有可训练的权重节点
#             valid_nodes = []
#             all_nodes = ms.default_graph.nodes if hasattr(ms.default_graph, 'nodes') else []
#
#             print(f"   总节点数: {len(all_nodes)}")
#
#             for i, node in enumerate(all_nodes):
#                 try:
#                     # 检查节点是否是Variable且可训练
#                     if (isinstance(node, ms.core.Variable) and
#                             hasattr(node, 'trainable') and node.trainable and
#                             hasattr(node, 'value') and node.value is not None):
#
#                         # 检查是否有有效的形状
#                         if hasattr(node.value, 'shape') and len(node.value.shape) == 2:
#                             if node.value.shape[0] > 0 and node.value.shape[1] > 0:
#                                 valid_nodes.append(node)
#                                 print(f"   找到权重节点{i}: 形状={node.value.shape}")
#
#                 except Exception as node_error:
#                     # 跳过有问题的节点
#                     continue
#
#             print(f"   发现 {len(valid_nodes)} 个有效权重节点")
#
#             # 如果没有找到足够的节点，尝试其他方法
#             if len(valid_nodes) < 2:
#                 print("   ⚠️  权重节点较少，尝试其他识别方法...")
#
#                 # 尝试从层对象中获取权重
#                 layer_objects = [fc1, output]  # 重点关注全连接层
#                 layer_names_alt = ['fc1', 'output']
#
#                 for i, layer_obj in enumerate(layer_objects):
#                     try:
#                         if hasattr(layer_obj, 'W') and layer_obj.W is not None:
#                             if hasattr(layer_obj.W, 'value') and layer_obj.W.value is not None:
#                                 cpu_weights = self.to_cpu(layer_obj.W.value)
#                                 if isinstance(cpu_weights, np.ndarray):
#                                     cpu_weights = np.matrix(cpu_weights)
#
#                                 layer_name = layer_names_alt[i]
#                                 layer_weights[layer_name] = cpu_weights
#                                 layer_nodes[layer_name] = layer_obj.W
#
#                                 print(f"   ✅ 从层对象提取 {layer_name}: {cpu_weights.shape}")
#                     except Exception as e:
#                         print(f"   ⚠️  层对象 {i} 权重提取失败: {e}")
#                         continue
#
#             else:
#                 # 使用标准方法处理权重节点
#                 # 根据权重矩阵的形状和位置推断层类型
#                 for i, node in enumerate(valid_nodes):
#                     try:
#                         shape = node.value.shape
#
#                         # 根据形状推断层类型
#                         layer_name = None
#                         if shape[0] == 10:  # 输出层通常是10个类别
#                             layer_name = 'output'
#                         elif shape[0] == 120:  # FC1层输出120
#                             layer_name = 'fc1'
#                         elif shape[1] < 200 and shape[0] < 200:  # 可能的卷积层
#                             if i == 0:
#                                 layer_name = 'conv1'
#                             elif i == 1:
#                                 layer_name = 'conv2'
#                         else:
#                             # 其他情况，按顺序命名
#                             layer_names = ['layer1', 'layer2', 'fc1', 'output']
#                             if i < len(layer_names):
#                                 layer_name = layer_names[i]
#
#                         if layer_name and layer_name not in layer_weights:
#                             # 转换到CPU进行压缩处理
#                             cpu_weights = self.to_cpu(node.value)
#                             if isinstance(cpu_weights, np.ndarray):
#                                 cpu_weights = np.matrix(cpu_weights)
#
#                             layer_weights[layer_name] = cpu_weights
#                             layer_nodes[layer_name] = node
#
#                             device_info = "GPU" if self.use_gpu else "CPU"
#                             print(f"   ✅ {layer_name}: {node.value.shape} [{device_info}]")
#
#                     except Exception as e:
#                         print(f"   ❌ 节点 {i} 权重提取失败: {e}")
#                         continue
#
#             print(f"   📊 成功识别 {len(layer_weights)} 个权重层")
#
#             # 如果仍然没有提取到权重，提供建议
#             if len(layer_weights) == 0:
#                 print("   ⚠️  未能提取到任何权重，可能的原因:")
#                 print("      1. 网络尚未初始化")
#                 print("      2. 权重节点结构与预期不同")
#                 print("      3. 需要先进行一次前向传播")
#
#             return layer_weights, layer_nodes
#
#         except Exception as e:
#             print(f"❌ 权重提取失败: {e}")
#             import traceback
#             traceback.print_exc()
#             return {}, {}
#
#     def apply_compression_gpu(self, layer_weights, layer_nodes):
#         """应用压缩"""
#         if self.compression_applied:
#             print("⚠️  压缩已应用，跳过...")
#             return
#
#         print("\n" + "=" * 60)
#         print("🚀 开始应用模型压缩...")
#         print("=" * 60)
#
#         if not layer_weights:
#             print("❌ 未找到有效的层权重，跳过压缩")
#             return
#
#         print(f"📊 待压缩层:")
#         for name, weights in layer_weights.items():
#             print(f"   {name}: {weights.shape}")
#
#         compressed_weights = copy.deepcopy(layer_weights)
#
#         # 1. 结构化剪枝
#         if self.enable_pruning:
#             print("\n1. 执行结构化剪枝:")
#             print("-" * 30)
#
#             try:
#                 for layer_name, weights in layer_weights.items():
#                     print(f"\n🔧 处理层: {layer_name}")
#
#                     # 检查权重有效性
#                     if weights.size == 0:
#                         print(f"⚠️  {layer_name} 权重为空，跳过")
#                         continue
#
#                     if min(weights.shape) <= 2:
#                         print(f"⚠️  {layer_name} 维度过小 {weights.shape}，跳过")
#                         continue
#
#                     try:
#                         # 对输出层使用更保守的剪枝
#                         if layer_name == 'output':
#                             original_ratio = self.pruner.base_pruning_ratio
#                             self.pruner.base_pruning_ratio = min(0.1, original_ratio)
#                             compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
#                             self.pruner.base_pruning_ratio = original_ratio
#                         else:
#                             compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
#
#                         print(f"   ✅ {layer_name} 剪枝成功")
#
#                     except Exception as e:
#                         print(f"   ❌ {layer_name} 剪枝失败: {e}")
#                         compressed_weights[layer_name] = weights
#
#                 # 显示剪枝统计
#                 try:
#                     stats = self.pruner.get_pruning_statistics()
#                     if 'error' not in stats:
#                         comp_ratio = stats.get('total_compression_ratio', 1.0)
#                         param_reduction = stats.get('total_parameter_reduction', 0)
#                         print(f"\n✅ 剪枝完成！压缩比例: {comp_ratio:.2%}")
#                         print(f"📉 减少参数: {param_reduction:,}")
#                 except Exception as e:
#                     print(f"⚠️  统计获取失败: {e}")
#
#             except Exception as e:
#                 print(f"❌ 剪枝过程失败: {e}")
#
#         # 2. 混合精度量化
#         if self.enable_quantization:
#             print("\n2. 执行混合精度量化:")
#             print("-" * 30)
#
#             try:
#                 # 自定义精度设置
#                 custom_precision = {
#                     'output': QuantizationType.FP16,  # 输出层保持较高精度
#                     'fc1': QuantizationType.INT16  # 全连接层中等精度
#                 }
#
#                 # 过滤有效权重
#                 valid_weights = {}
#                 for name, weights in compressed_weights.items():
#                     if weights.size > 0 and min(weights.shape) > 0:
#                         valid_weights[name] = weights
#
#                 if valid_weights:
#                     quantized_weights = self.quantizer.quantize_full_model(
#                         valid_weights, custom_precision
#                     )
#
#                     for name, weights in quantized_weights.items():
#                         compressed_weights[name] = weights
#
#                     print("✅ 量化完成")
#                 else:
#                     print("⚠️  无有效权重可量化")
#
#             except Exception as e:
#                 print(f"❌ 量化过程失败: {e}")
#
#         # 3. 应用压缩后的权重
#         print("\n3. 应用压缩权重:")
#         print("-" * 30)
#
#         success_count = 0
#         for layer_name, compressed_weight in compressed_weights.items():
#             if layer_name in layer_nodes:
#                 try:
#                     node = layer_nodes[layer_name]
#                     original_shape = node.value.shape
#
#                     if compressed_weight.shape != original_shape:
#                         print(f"   📐 形状变化 {layer_name}: {original_shape} -> {compressed_weight.shape}")
#
#                     # 转换回GPU格式
#                     if self.use_gpu:
#                         gpu_weights = self.to_gpu(compressed_weight)
#                         node.set_value(gpu_weights)
#                     else:
#                         node.set_value(compressed_weight)
#
#                     # 更新节点维度
#                     if hasattr(node, 'dim'):
#                         node.dim = compressed_weight.shape
#
#                     success_count += 1
#                     print(f"   ✅ {layer_name} 权重更新成功")
#
#                 except Exception as e:
#                     print(f"   ❌ {layer_name} 权重更新失败: {e}")
#
#         if success_count > 0:
#             self.compression_applied = True
#             print(f"\n✅ 成功更新 {success_count}/{len(compressed_weights)} 个层")
#
#         print("=" * 60)
#         print("🚀 模型压缩完成！" if self.compression_applied else "⚠️  模型压缩未完全成功")
#         print("=" * 60)
#
#     def train_with_gpu_compression(self, num_epochs=40, batch_size=32, learning_rate=0.005, compression_epoch=15):
#         """GPU加速训练流程"""
#         print(f"🚀 开始训练（设备: {'GPU' if self.use_gpu else 'CPU'}）")
#
#         try:
#             # 准备数据
#             X, y, one_hot_label = self.load_and_prepare_data(num_samples=1000)
#
#             # 构建网络
#             x, one_hot, predict, loss, conv1, conv2, fc1, output = self.build_network_gpu()
#
#             # 优化器
#             optimizer = ms.optimizer.Adam(ms.default_graph, loss, learning_rate)
#
#             # 训练跟踪
#             best_accuracy = 0.0
#             accuracy_history = []
#
#             print(f"\n🎯 开始训练 - 计划在第 {compression_epoch} 轮应用压缩")
#             print("=" * 80)
#
#             for epoch in range(num_epochs):
#                 start_time = time.time()
#                 batch_count = 0
#                 total_loss = 0.0
#
#                 # 训练一轮
#                 for i in range(len(X)):
#                     try:
#                         # 准备批次数据
#                         if self.use_gpu and cp is not None:
#                             feature = cp.asmatrix(X[i]).reshape((28, 28))
#                             label = cp.asmatrix(one_hot_label[i]).T
#                         else:
#                             x_cpu = self.to_cpu(X[i]) if hasattr(X[i], 'get') else X[i]
#                             label_cpu = self.to_cpu(one_hot_label[i]) if hasattr(one_hot_label[i], 'get') else \
#                             one_hot_label[i]
#                             feature = np.mat(x_cpu).reshape((28, 28))
#                             label = np.mat(label_cpu).T
#
#                         x.set_value(feature)
#                         one_hot.set_value(label)
#
#                         optimizer.one_step()
#
#                         current_loss = float(loss.value[0, 0])
#                         total_loss += current_loss
#                         batch_count += 1
#
#                         if batch_count >= batch_size:
#                             optimizer.update()
#
#                             if epoch < 3 or epoch % 5 == 0:
#                                 device_info = "GPU" if self.use_gpu else "CPU"
#                                 avg_loss = total_loss / batch_count
#                                 print(f"[{device_info}] epoch: {epoch + 1}, iter: {i + 1}, loss: {avg_loss:.6f}")
#
#                             batch_count = 0
#                             total_loss = 0.0
#
#                     except Exception as e:
#                         print(f"⚠️  训练步骤 {i} 出错: {e}")
#                         continue
#
#                 # 计算精度
#                 try:
#                     pred = []
#                     for i in range(min(len(X), 200)):  # 限制验证样本数量
#                         if self.use_gpu and cp is not None:
#                             feature = cp.asmatrix(X[i]).reshape((28, 28))
#                         else:
#                             x_cpu = self.to_cpu(X[i]) if hasattr(X[i], 'get') else X[i]
#                             feature = np.mat(x_cpu).reshape((28, 28))
#
#                         x.set_value(feature)
#                         predict.forward()
#
#                         pred_value = self.to_cpu(predict.value.A.ravel())
#                         pred.append(pred_value)
#
#                     pred = np.array(pred).argmax(axis=1)
#                     y_cpu = self.to_cpu(y) if hasattr(y, 'get') else y
#                     y_subset = y_cpu[:len(pred)]
#                     accuracy = (y_subset == pred).astype(int).sum() / len(pred)
#                     accuracy_history.append(accuracy)
#
#                     if accuracy > best_accuracy:
#                         best_accuracy = accuracy
#
#                 except Exception as e:
#                     print(f"⚠️  精度计算出错: {e}")
#                     accuracy = 0.0
#                     accuracy_history.append(accuracy)
#
#                 end_time = time.time()
#                 epoch_duration = end_time - start_time
#
#                 device_info = "GPU" if self.use_gpu else "CPU"
#                 print(f"[{device_info}] epoch: {epoch + 1}, accuracy: {accuracy:.3f}, "
#                       f"best: {best_accuracy:.3f}, time: {epoch_duration:.2f}s")
#
#                 # 应用压缩
#                 if epoch + 1 == compression_epoch and not self.compression_applied:
#                     print(f"\n⚡ 第 {epoch + 1} 轮，开始应用模型压缩...")
#                     self.baseline_accuracy = accuracy
#
#                     layer_weights, layer_nodes = self.extract_layer_weights_gpu(conv1, conv2, fc1, output)
#                     if layer_weights:
#                         self.apply_compression_gpu(layer_weights, layer_nodes)
#                         print(f"📊 压缩前精度: {self.baseline_accuracy:.3f}")
#                         print("继续训练以评估压缩效果...\n")
#                     else:
#                         print("⚠️  无法提取权重，可能需要等待网络初始化完成")
#                         print("    将在下一轮重试压缩...")
#                         # 延迟压缩到下一轮
#                         compression_epoch = epoch + 2 if epoch + 2 < num_epochs else epoch + 1
#
#                 # 学习率衰减
#                 if (epoch + 1) % 15 == 0:
#                     learning_rate *= 0.8
#                     optimizer.learning_rate = learning_rate
#                     print(f"📉 学习率调整为: {learning_rate:.6f}")
#
#                 print("-" * 80)
#
#             print("\n🎉 训练完成！")
#
#             # 最终统计
#             final_stats = {
#                 'best_accuracy': best_accuracy,
#                 'baseline_accuracy': self.baseline_accuracy,
#                 'accuracy_history': accuracy_history,
#                 'compression_applied': self.compression_applied,
#                 'device': 'GPU' if self.use_gpu else 'CPU'
#             }
#
#             if self.compression_applied and self.baseline_accuracy:
#                 if best_accuracy >= self.baseline_accuracy:
#                     improvement = best_accuracy - self.baseline_accuracy
#                     print(f"📈 最终精度: {best_accuracy:.3f} (提升: +{improvement:.3f})")
#                 else:
#                     drop = self.baseline_accuracy - best_accuracy
#                     print(f"📈 最终精度: {best_accuracy:.3f} (下降: -{drop:.3f})")
#                 print(f"📊 压缩前基准: {self.baseline_accuracy:.3f}")
#             else:
#                 print(f"📈 最终精度: {best_accuracy:.3f}")
#
#             return final_stats
#
#         except Exception as e:
#             print(f"❌ 训练过程出现错误: {e}")
#             import traceback
#             traceback.print_exc()
#             return None
#
#
# def main_gpu():
#     """主训练函数"""
#     print("🚀 MatrixSlow GPU集成剪枝和量化CNN训练")
#     print("=" * 80)
#
#     try:
#         # 创建训练器
#         trainer = GPUCompressedCNNTrainer(
#             pruning_ratio=0.15,  # 剪枝15%（较保守）
#             enable_quantization=True,  # 启用量化
#             enable_pruning=True,  # 启用剪枝
#             use_gpu=True  # 尝试使用GPU
#         )
#
#         # 开始训练
#         stats = trainer.train_with_gpu_compression(
#             num_epochs=40,  # 训练40轮
#             batch_size=16,  # 较小的批次大小
#             learning_rate=0.01,  # 学习率
#             compression_epoch=15  # 第15轮应用压缩
#         )
#
#         if stats:
#             print(f"\n📊 最终训练统计:")
#             print(f"设备: {stats['device']}")
#             print(f"最佳精度: {stats['best_accuracy']:.3f}")
#             if stats['compression_applied']:
#                 print(f"压缩效果: {'✅ 成功' if stats['compression_applied'] else '❌ 失败'}")
#                 if stats['baseline_accuracy']:
#                     accuracy_change = stats['best_accuracy'] - stats['baseline_accuracy']
#                     print(f"精度变化: {accuracy_change:+.3f}")
#
#         return stats
#
#     except Exception as e:
#         print(f"\n❌ 训练失败: {e}")
#         print("\n🔧 可能的解决方案:")
#         print("1. 确保在包含matrixslow文件夹的根目录下运行")
#         print("2. 检查matrixslow.compression模块是否正确安装")
#         print("3. 如果使用GPU，检查CUDA和CuPy安装")
#         print("4. 尝试减少数据量或调整超参数")
#
#         import traceback
#         traceback.print_exc()
#
#         return None
#
#
# if __name__ == "__main__":
#     # 运行训练
#     print("开始执行MatrixSlow训练...")
#     print(f"当前工作目录: {os.getcwd()}")
#     print(f"Python路径: {sys.path[:3]}")  # 显示前3个路径
#
#     training_results = main_gpu()
#
#     if training_results:
#         print("\n✅ 训练成功完成")
#     else:
#         print("\n❌ 训练失败")

# -*- coding: utf-8 -*-
"""
修复版本：集成结构化剪枝和混合精度量化的CNN MNIST训练 - 根目录版本
适配matrixslow框架的目录结构
修复CuPy兼容性问题
"""

import time
import sys
import copy
import os

# 添加当前目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.preprocessing import OneHotEncoder

# 导入MatrixSlow框架
try:
    # 从当前目录的matrixslow包导入
    import matrixslow as ms

    print("✅ 成功导入MatrixSlow框架")
except ImportError as e:
    print(f"❌ 无法导入MatrixSlow框架: {e}")
    print("请确保在包含matrixslow文件夹的根目录下运行此脚本")
    sys.exit(1)

# 导入压缩模块
try:
    # 从matrixslow.compression导入
    from matrixslow.compression.pruning import StructuredPruner, AdaptivePruner
    from matrixslow.compression.quantization import MixedPrecisionQuantizer, QuantizationType, LayerSensitivity

    print("✅ 成功导入压缩模块")
except ImportError as e:
    print(f"❌ 无法导入压缩模块: {e}")
    print("请确保compression文件夹在matrixslow目录下，并包含pruning.py和quantization.py")
    sys.exit(1)

# GPU相关导入
try:
    import cupy as cp

    GPU_AVAILABLE = True
    print("✅ GPU加速库CuPy可用")
except ImportError:
    print("⚠️  CuPy未安装，将使用CPU训练")
    GPU_AVAILABLE = False
    cp = None


class GPUCompressedCNNTrainer:
    """
    支持GPU的集成剪枝和量化CNN训练器
    适配matrixslow框架结构
    """

    def __init__(self, pruning_ratio=0.2, enable_quantization=True, enable_pruning=True, use_gpu=True):
        self.pruning_ratio = pruning_ratio
        self.enable_quantization = enable_quantization
        self.enable_pruning = enable_pruning
        self.use_gpu = use_gpu and GPU_AVAILABLE

        print(f"🔧 初始化训练器配置:")
        print(f"   剪枝比例: {self.pruning_ratio}")
        print(f"   启用量化: {self.enable_quantization}")
        print(f"   启用剪枝: {self.enable_pruning}")

        # GPU设备检查
        if self.use_gpu and cp is not None:
            try:
                self.device_id = 0
                cp.cuda.Device(self.device_id).use()
                mem_info = cp.cuda.Device().mem_info
                total_memory = mem_info[1] / 1024 ** 3
                print(f"🚀 使用GPU设备: {cp.cuda.Device().id}")
                print(f"   GPU内存: {total_memory:.1f} GB")
            except Exception as e:
                print(f"⚠️  GPU初始化失败: {e}，回退到CPU")
                self.use_gpu = False
        else:
            print("🖥️  使用CPU训练")

        # 初始化剪枝器和量化器
        try:
            if self.enable_pruning:
                self.pruner = AdaptivePruner(
                    base_pruning_ratio=pruning_ratio,
                    sensitivity_threshold=0.1
                )
                print("✅ 自适应剪枝器初始化成功")

            if self.enable_quantization:
                self.quantizer = MixedPrecisionQuantizer(
                    default_precision=QuantizationType.INT8,
                    sensitivity_threshold=0.1
                )
                print("✅ 混合精度量化器初始化成功")

        except Exception as e:
            print(f"❌ 压缩模块初始化失败: {e}")
            raise

        self.compression_applied = False
        self.baseline_accuracy = None

    def to_gpu(self, data):
        """安全地将数据转移到GPU"""
        if self.use_gpu and cp is not None:
            try:
                if isinstance(data, np.ndarray):
                    return cp.asarray(data)
                elif isinstance(data, np.matrix):
                    # 将numpy矩阵转换为CuPy数组
                    return cp.asarray(np.asarray(data))
                else:
                    return cp.asarray(data)
            except Exception as e:
                print(f"⚠️  GPU转换失败: {e}，使用CPU数据")
                return data
        return data

    def to_cpu(self, data):
        """安全地将数据转移到CPU"""
        if self.use_gpu and cp is not None:
            try:
                if hasattr(data, 'get'):  # CuPy数组
                    return data.get()
            except Exception as e:
                print(f"⚠️  CPU转换失败: {e}")
        return data

    def array_to_matrix(self, arr, target_shape=None):
        """安全地将数组转换为矩阵格式"""
        try:
            if self.use_gpu and cp is not None and hasattr(arr, 'get'):
                # CuPy数组，转换为numpy再处理
                cpu_arr = arr.get()
            else:
                cpu_arr = np.asarray(arr)

            if target_shape is not None:
                cpu_arr = cpu_arr.reshape(target_shape)

            # 返回矩阵格式
            return np.matrix(cpu_arr)
        except Exception as e:
            print(f"⚠️  数组转矩阵失败: {e}")
            return np.matrix(np.asarray(arr))

    def load_and_prepare_data(self, num_samples=1000):
        """加载和预处理MNIST数据"""
        print("📥 加载MNIST数据集...")
        try:
            X, y = fetch_openml('mnist_784', version=1, return_X_y=True, parser='auto')
            X = X[:num_samples].to_numpy() / 255.0
            y = y.to_numpy().astype(int)[:num_samples]

            # One-Hot编码
            oh = OneHotEncoder(sparse_output=False)
            one_hot_label = oh.fit_transform(y.reshape(-1, 1))

            print(f"📊 数据加载完成: X={X.shape}, y={y.shape}, one_hot={one_hot_label.shape}")

            # 转移到GPU（如果可用）
            if self.use_gpu:
                print("🚀 将数据转移到GPU...")
                X = self.to_gpu(X)
                one_hot_label = self.to_gpu(one_hot_label)
                print(f"   GPU数据形状: X={X.shape}, labels={one_hot_label.shape}")

            return X, y, one_hot_label

        except Exception as e:
            print(f"❌ 数据加载失败: {e}")
            raise

    def build_network_gpu(self):
        """构建CNN网络 - 适配matrixslow框架"""
        print("🏗️  构建CNN网络...")

        try:
            # MatrixSlow图管理（不使用clear方法）
            print(f"   当前图节点数: {len(ms.default_graph.nodes)}")

            # 输入图像尺寸
            img_shape = (28, 28)

            # 输入变量
            x = ms.core.Variable(img_shape, init=False, trainable=False)
            one_hot = ms.core.Variable(dim=(10, 1), init=False, trainable=False)

            # 网络层构建
            print("   构建卷积层...")

            try:
                # 第一卷积层 - 3个5x5卷积核
                conv1 = ms.layer.conv([x], img_shape, 3, (5, 5), "ReLU")
                print(f"   Conv1构建成功，输出: {len(conv1) if isinstance(conv1, (list, tuple)) else 'single'} 个特征图")

                # 第一池化层 - 3x3池化，步长2x2
                pooling1 = ms.layer.pooling(conv1, (3, 3), (2, 2))
                print(f"   Pooling1构建成功")

                # 第二卷积层 - 3个3x3卷积核，输入14x14
                conv2 = ms.layer.conv(pooling1, (14, 14), 3, (3, 3), "ReLU")
                print(f"   Conv2构建成功")

                # 第二池化层
                pooling2 = ms.layer.pooling(conv2, (3, 3), (2, 2))
                print(f"   Pooling2构建成功")

                # 展平层 - 连接所有池化输出
                flatten = ms.ops.Concat(*pooling2)
                print(f"   展平层构建成功")

                # 全连接层 - 动态计算输入维度
                # 先尝试147维，如果不对会在训练时调整
                fc1 = ms.layer.fc(flatten, 147, 120, "ReLU")
                print(f"   FC1构建成功: ? -> 120")

                # 输出层 - 120->10
                output = ms.layer.fc(fc1, 120, 10, "None")
                print(f"   输出层构建成功: 120 -> 10")

                # 分类概率
                predict = ms.ops.SoftMax(output)
                print(f"   SoftMax构建成功")

                # 损失函数
                loss = ms.ops.loss.CrossEntropyWithSoftMax(output, one_hot)
                print(f"   损失函数构建成功")

            except Exception as layer_error:
                print(f"   ❌ 网络层构建出错: {layer_error}")
                raise

            device_info = "GPU" if self.use_gpu else "CPU"
            print(f"✅ 网络构建完成，设备: {device_info}")
            print(f"   网络节点数: {len(ms.default_graph.nodes)}")

            return x, one_hot, predict, loss, conv1, conv2, fc1, output

        except Exception as e:
            print(f"❌ 网络构建失败: {e}")
            import traceback
            traceback.print_exc()
            raise

    def extract_layer_weights_gpu(self, conv1, conv2, fc1, output):
        """提取各层权重用于压缩 - 适配matrixslow"""
        layer_weights = {}
        layer_nodes = {}

        print("\n🔍 提取网络层权重:")

        try:
            # 收集所有可训练的权重节点
            valid_nodes = []
            all_nodes = ms.default_graph.nodes if hasattr(ms.default_graph, 'nodes') else []

            print(f"   总节点数: {len(all_nodes)}")

            for i, node in enumerate(all_nodes):
                try:
                    # 检查节点是否是Variable且可训练
                    if (isinstance(node, ms.core.Variable) and
                            hasattr(node, 'trainable') and node.trainable and
                            hasattr(node, 'value') and node.value is not None):

                        # 检查是否有有效的形状
                        if hasattr(node.value, 'shape') and len(node.value.shape) == 2:
                            if node.value.shape[0] > 0 and node.value.shape[1] > 0:
                                valid_nodes.append(node)
                                print(f"   找到权重节点{i}: 形状={node.value.shape}")

                except Exception as node_error:
                    # 跳过有问题的节点
                    continue

            print(f"   发现 {len(valid_nodes)} 个有效权重节点")

            # 如果没有找到足够的节点，尝试其他方法
            if len(valid_nodes) < 2:
                print("   ⚠️  权重节点较少，尝试其他识别方法...")

                # 尝试从层对象中获取权重
                layer_objects = [fc1, output]  # 重点关注全连接层
                layer_names_alt = ['fc1', 'output']

                for i, layer_obj in enumerate(layer_objects):
                    try:
                        if hasattr(layer_obj, 'W') and layer_obj.W is not None:
                            if hasattr(layer_obj.W, 'value') and layer_obj.W.value is not None:
                                cpu_weights = self.to_cpu(layer_obj.W.value)
                                if isinstance(cpu_weights, np.ndarray):
                                    cpu_weights = np.matrix(cpu_weights)

                                layer_name = layer_names_alt[i]
                                layer_weights[layer_name] = cpu_weights
                                layer_nodes[layer_name] = layer_obj.W

                                print(f"   ✅ 从层对象提取 {layer_name}: {cpu_weights.shape}")
                    except Exception as e:
                        print(f"   ⚠️  层对象 {i} 权重提取失败: {e}")
                        continue

            else:
                # 使用标准方法处理权重节点
                # 根据权重矩阵的形状和位置推断层类型
                for i, node in enumerate(valid_nodes):
                    try:
                        shape = node.value.shape

                        # 根据形状推断层类型
                        layer_name = None
                        if shape[0] == 10:  # 输出层通常是10个类别
                            layer_name = 'output'
                        elif shape[0] == 120:  # FC1层输出120
                            layer_name = 'fc1'
                        elif shape[1] < 200 and shape[0] < 200:  # 可能的卷积层
                            if i == 0:
                                layer_name = 'conv1'
                            elif i == 1:
                                layer_name = 'conv2'
                        else:
                            # 其他情况，按顺序命名
                            layer_names = ['layer1', 'layer2', 'fc1', 'output']
                            if i < len(layer_names):
                                layer_name = layer_names[i]

                        if layer_name and layer_name not in layer_weights:
                            # 转换到CPU进行压缩处理
                            cpu_weights = self.to_cpu(node.value)
                            if isinstance(cpu_weights, np.ndarray):
                                cpu_weights = np.matrix(cpu_weights)

                            layer_weights[layer_name] = cpu_weights
                            layer_nodes[layer_name] = node

                            device_info = "GPU" if self.use_gpu else "CPU"
                            print(f"   ✅ {layer_name}: {node.value.shape} [{device_info}]")

                    except Exception as e:
                        print(f"   ❌ 节点 {i} 权重提取失败: {e}")
                        continue

            print(f"   📊 成功识别 {len(layer_weights)} 个权重层")

            # 如果仍然没有提取到权重，提供建议
            if len(layer_weights) == 0:
                print("   ⚠️  未能提取到任何权重，可能的原因:")
                print("      1. 网络尚未初始化")
                print("      2. 权重节点结构与预期不同")
                print("      3. 需要先进行一次前向传播")

            return layer_weights, layer_nodes

        except Exception as e:
            print(f"❌ 权重提取失败: {e}")
            import traceback
            traceback.print_exc()
            return {}, {}

    def apply_compression_gpu(self, layer_weights, layer_nodes):
        """应用压缩"""
        if self.compression_applied:
            print("⚠️  压缩已应用，跳过...")
            return

        print("\n" + "=" * 60)
        print("🚀 开始应用模型压缩...")
        print("=" * 60)

        if not layer_weights:
            print("❌ 未找到有效的层权重，跳过压缩")
            return

        print(f"📊 待压缩层:")
        for name, weights in layer_weights.items():
            print(f"   {name}: {weights.shape}")

        compressed_weights = copy.deepcopy(layer_weights)

        # 1. 结构化剪枝
        if self.enable_pruning:
            print("\n1. 执行结构化剪枝:")
            print("-" * 30)

            try:
                for layer_name, weights in layer_weights.items():
                    print(f"\n🔧 处理层: {layer_name}")

                    # 检查权重有效性
                    if weights.size == 0:
                        print(f"⚠️  {layer_name} 权重为空，跳过")
                        continue

                    if min(weights.shape) <= 2:
                        print(f"⚠️  {layer_name} 维度过小 {weights.shape}，跳过")
                        continue

                    try:
                        # 对输出层使用更保守的剪枝
                        if layer_name == 'output':
                            original_ratio = self.pruner.base_pruning_ratio
                            self.pruner.base_pruning_ratio = min(0.1, original_ratio)
                            compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
                            self.pruner.base_pruning_ratio = original_ratio
                        else:
                            compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)

                        print(f"   ✅ {layer_name} 剪枝成功")

                    except Exception as e:
                        print(f"   ❌ {layer_name} 剪枝失败: {e}")
                        compressed_weights[layer_name] = weights

                # 显示剪枝统计
                try:
                    stats = self.pruner.get_pruning_statistics()
                    if 'error' not in stats:
                        comp_ratio = stats.get('total_compression_ratio', 1.0)
                        param_reduction = stats.get('total_parameter_reduction', 0)
                        print(f"\n✅ 剪枝完成！压缩比例: {comp_ratio:.2%}")
                        print(f"📉 减少参数: {param_reduction:,}")
                except Exception as e:
                    print(f"⚠️  统计获取失败: {e}")

            except Exception as e:
                print(f"❌ 剪枝过程失败: {e}")

        # 2. 混合精度量化
        if self.enable_quantization:
            print("\n2. 执行混合精度量化:")
            print("-" * 30)

            try:
                # 自定义精度设置
                custom_precision = {
                    'output': QuantizationType.FP16,  # 输出层保持较高精度
                    'fc1': QuantizationType.INT16  # 全连接层中等精度
                }

                # 过滤有效权重
                valid_weights = {}
                for name, weights in compressed_weights.items():
                    if weights.size > 0 and min(weights.shape) > 0:
                        valid_weights[name] = weights

                if valid_weights:
                    quantized_weights = self.quantizer.quantize_full_model(
                        valid_weights, custom_precision
                    )

                    for name, weights in quantized_weights.items():
                        compressed_weights[name] = weights

                    print("✅ 量化完成")
                else:
                    print("⚠️  无有效权重可量化")

            except Exception as e:
                print(f"❌ 量化过程失败: {e}")

        # 3. 应用压缩后的权重
        print("\n3. 应用压缩权重:")
        print("-" * 30)

        success_count = 0
        for layer_name, compressed_weight in compressed_weights.items():
            if layer_name in layer_nodes:
                try:
                    node = layer_nodes[layer_name]
                    original_shape = node.value.shape

                    if compressed_weight.shape != original_shape:
                        print(f"   📐 形状变化 {layer_name}: {original_shape} -> {compressed_weight.shape}")

                    # 转换回GPU格式
                    if self.use_gpu:
                        gpu_weights = self.to_gpu(compressed_weight)
                        node.set_value(gpu_weights)
                    else:
                        node.set_value(compressed_weight)

                    # 更新节点维度
                    if hasattr(node, 'dim'):
                        node.dim = compressed_weight.shape

                    success_count += 1
                    print(f"   ✅ {layer_name} 权重更新成功")

                except Exception as e:
                    print(f"   ❌ {layer_name} 权重更新失败: {e}")

        if success_count > 0:
            self.compression_applied = True
            print(f"\n✅ 成功更新 {success_count}/{len(compressed_weights)} 个层")

        print("=" * 60)
        print("🚀 模型压缩完成！" if self.compression_applied else "⚠️  模型压缩未完全成功")
        print("=" * 60)

    def train_with_gpu_compression(self, num_epochs=40, batch_size=32, learning_rate=0.005, compression_epoch=15):
        """GPU加速训练流程"""
        print(f"🚀 开始训练（设备: {'GPU' if self.use_gpu else 'CPU'}）")

        try:
            # 准备数据
            X, y, one_hot_label = self.load_and_prepare_data(num_samples=1000)

            # 构建网络
            x, one_hot, predict, loss, conv1, conv2, fc1, output = self.build_network_gpu()

            # 优化器
            optimizer = ms.optimizer.Adam(ms.default_graph, loss, learning_rate)

            # 训练跟踪
            best_accuracy = 0.0
            accuracy_history = []

            print(f"\n🎯 开始训练 - 计划在第 {compression_epoch} 轮应用压缩")
            print("=" * 80)

            for epoch in range(num_epochs):
                start_time = time.time()
                batch_count = 0
                total_loss = 0.0

                # 训练一轮
                for i in range(len(X)):
                    try:
                        # 准备批次数据
                        if self.use_gpu and cp is not None:
                            # 修复：使用cp.asarray而不是cp.asmatrix
                            x_data = self.to_cpu(X[i]) if hasattr(X[i], 'get') else X[i]
                            label_data = self.to_cpu(one_hot_label[i]) if hasattr(one_hot_label[i], 'get') else \
                            one_hot_label[i]

                            # 转换为矩阵格式
                            feature = self.array_to_matrix(x_data, (28, 28))
                            label = self.array_to_matrix(label_data).T
                        else:
                            x_cpu = self.to_cpu(X[i]) if hasattr(X[i], 'get') else X[i]
                            label_cpu = self.to_cpu(one_hot_label[i]) if hasattr(one_hot_label[i], 'get') else \
                            one_hot_label[i]
                            feature = np.mat(x_cpu).reshape((28, 28))
                            label = np.mat(label_cpu).T

                        x.set_value(feature)
                        one_hot.set_value(label)

                        optimizer.one_step()

                        current_loss = float(loss.value[0, 0])
                        total_loss += current_loss
                        batch_count += 1

                        if batch_count >= batch_size:
                            optimizer.update()

                            if epoch < 3 or epoch % 5 == 0:
                                device_info = "GPU" if self.use_gpu else "CPU"
                                avg_loss = total_loss / batch_count
                                print(f"[{device_info}] epoch: {epoch + 1}, iter: {i + 1}, loss: {avg_loss:.6f}")

                            batch_count = 0
                            total_loss = 0.0

                    except Exception as e:
                        print(f"⚠️  训练步骤 {i} 出错: {e}")
                        continue

                # 计算精度
                try:
                    pred = []
                    for i in range(min(len(X), 200)):  # 限制验证样本数量
                        if self.use_gpu and cp is not None:
                            x_data = self.to_cpu(X[i]) if hasattr(X[i], 'get') else X[i]
                            feature = self.array_to_matrix(x_data, (28, 28))
                        else:
                            x_cpu = self.to_cpu(X[i]) if hasattr(X[i], 'get') else X[i]
                            feature = np.mat(x_cpu).reshape((28, 28))

                        x.set_value(feature)
                        predict.forward()

                        pred_value = self.to_cpu(predict.value.A.ravel())
                        pred.append(pred_value)

                    pred = np.array(pred).argmax(axis=1)
                    y_cpu = self.to_cpu(y) if hasattr(y, 'get') else y
                    y_subset = y_cpu[:len(pred)]
                    accuracy = (y_subset == pred).astype(int).sum() / len(pred)
                    accuracy_history.append(accuracy)

                    if accuracy > best_accuracy:
                        best_accuracy = accuracy

                except Exception as e:
                    print(f"⚠️  精度计算出错: {e}")
                    accuracy = 0.0
                    accuracy_history.append(accuracy)

                end_time = time.time()
                epoch_duration = end_time - start_time

                device_info = "GPU" if self.use_gpu else "CPU"
                print(f"[{device_info}] epoch: {epoch + 1}, accuracy: {accuracy:.3f}, "
                      f"best: {best_accuracy:.3f}, time: {epoch_duration:.2f}s")

                # 应用压缩
                if epoch + 1 == compression_epoch and not self.compression_applied:
                    print(f"\n⚡ 第 {epoch + 1} 轮，开始应用模型压缩...")
                    self.baseline_accuracy = accuracy

                    layer_weights, layer_nodes = self.extract_layer_weights_gpu(conv1, conv2, fc1, output)
                    if layer_weights:
                        self.apply_compression_gpu(layer_weights, layer_nodes)
                        print(f"📊 压缩前精度: {self.baseline_accuracy:.3f}")
                        print("继续训练以评估压缩效果...\n")
                    else:
                        print("⚠️  无法提取权重，可能需要等待网络初始化完成")
                        print("    将在下一轮重试压缩...")
                        # 延迟压缩到下一轮
                        compression_epoch = epoch + 2 if epoch + 2 < num_epochs else epoch + 1

                # 学习率衰减
                if (epoch + 1) % 15 == 0:
                    learning_rate *= 0.8
                    optimizer.learning_rate = learning_rate
                    print(f"📉 学习率调整为: {learning_rate:.6f}")

                print("-" * 80)

            print("\n🎉 训练完成！")

            # 最终统计
            final_stats = {
                'best_accuracy': best_accuracy,
                'baseline_accuracy': self.baseline_accuracy,
                'accuracy_history': accuracy_history,
                'compression_applied': self.compression_applied,
                'device': 'GPU' if self.use_gpu else 'CPU'
            }

            if self.compression_applied and self.baseline_accuracy:
                if best_accuracy >= self.baseline_accuracy:
                    improvement = best_accuracy - self.baseline_accuracy
                    print(f"📈 最终精度: {best_accuracy:.3f} (提升: +{improvement:.3f})")
                else:
                    drop = self.baseline_accuracy - best_accuracy
                    print(f"📈 最终精度: {best_accuracy:.3f} (下降: -{drop:.3f})")
                print(f"📊 压缩前基准: {self.baseline_accuracy:.3f}")
            else:
                print(f"📈 最终精度: {best_accuracy:.3f}")

            return final_stats

        except Exception as e:
            print(f"❌ 训练过程出现错误: {e}")
            import traceback
            traceback.print_exc()
            return None


def main_gpu():
    """主训练函数"""
    print("🚀 MatrixSlow GPU集成剪枝和量化CNN训练")
    print("=" * 80)

    try:
        # 创建训练器
        trainer = GPUCompressedCNNTrainer(
            pruning_ratio=0.15,  # 剪枝15%（较保守）
            enable_quantization=True,  # 启用量化
            enable_pruning=True,  # 启用剪枝
            use_gpu=True  # 尝试使用GPU
        )

        # 开始训练
        stats = trainer.train_with_gpu_compression(
            num_epochs=40,  # 训练40轮
            batch_size=16,  # 较小的批次大小
            learning_rate=0.01,  # 学习率
            compression_epoch=15  # 第15轮应用压缩
        )

        if stats:
            print(f"\n📊 最终训练统计:")
            print(f"设备: {stats['device']}")
            print(f"最佳精度: {stats['best_accuracy']:.3f}")
            if stats['compression_applied']:
                print(f"压缩效果: {'✅ 成功' if stats['compression_applied'] else '❌ 失败'}")
                if stats['baseline_accuracy']:
                    accuracy_change = stats['best_accuracy'] - stats['baseline_accuracy']
                    print(f"精度变化: {accuracy_change:+.3f}")

        return stats

    except Exception as e:
        print(f"\n❌ 训练失败: {e}")
        print("\n🔧 可能的解决方案:")
        print("1. 确保在包含matrixslow文件夹的根目录下运行")
        print("2. 检查matrixslow.compression模块是否正确安装")
        print("3. 如果使用GPU，检查CUDA和CuPy安装")
        print("4. 尝试减少数据量或调整超参数")

        import traceback
        traceback.print_exc()

        return None


if __name__ == "__main__":
    # 运行训练
    print("开始执行MatrixSlow训练...")
    print(f"当前工作目录: {os.getcwd()}")
    print(f"Python路径: {sys.path[:3]}")  # 显示前3个路径

    training_results = main_gpu()

    if training_results:
        print("\n✅ 训练成功完成")
    else:
        print("\n❌ 训练失败")