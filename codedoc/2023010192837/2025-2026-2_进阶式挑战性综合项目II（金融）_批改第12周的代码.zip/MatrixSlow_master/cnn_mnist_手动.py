# -*- coding: utf-8 -*-
"""
集成结构化剪枝和混合精度量化的CNN MNIST训练 - 完整修复版
在原有手动混合精度基础上添加模型压缩功能
修复了所有已知的错误和边界情况
"""

import time
import sys
import copy

sys.path.append('../..')

import numpy as np
from sklearn.datasets import fetch_openml
from sklearn.preprocessing import OneHotEncoder
from MatrixSlow_master import matrixslow as ms

# 修正后的导入 - 使用正确的相对导入路径
from matrixslow.compression.pruning import StructuredPruner, AdaptivePruner
from matrixslow.compression.quantization import MixedPrecisionQuantizer, QuantizationType, LayerSensitivity


class CompressedCNNTrainer:
    """
    集成剪枝和量化的CNN训练器 - 修复版本
    """

    def __init__(self, pruning_ratio=0.2, enable_quantization=True, enable_pruning=True):
        self.pruning_ratio = pruning_ratio
        self.enable_quantization = enable_quantization
        self.enable_pruning = enable_pruning

        # 初始化剪枝器和量化器
        if self.enable_pruning:
            self.pruner = AdaptivePruner(
                base_pruning_ratio=pruning_ratio,
                sensitivity_threshold=0.1
            )

        if self.enable_quantization:
            self.quantizer = MixedPrecisionQuantizer(
                default_precision=QuantizationType.INT8,
                sensitivity_threshold=0.1
            )

        self.compression_applied = False
        self.baseline_accuracy = None

    def load_and_prepare_data(self, num_samples=1000):
        """加载和预处理MNIST数据"""
        print("加载MNIST数据集...")
        X, y = fetch_openml('mnist_784', version=1, return_X_y=True, parser='auto')
        X, y = X[:num_samples].to_numpy() / 255, y.to_numpy().astype(int)[:num_samples]

        # 将整数形式的标签转换成One-Hot编码
        oh = OneHotEncoder(sparse_output=False)
        one_hot_label = oh.fit_transform(y.reshape(-1, 1))

        return X, y, one_hot_label

    def build_network(self):
        """构建CNN网络"""
        print("构建CNN网络...")

        # 输入图像尺寸
        img_shape = (28, 28)

        # 输入图像
        x = ms.core.Variable(img_shape, init=False, trainable=False)

        # One-Hot标签
        one_hot = ms.core.Variable(dim=(10, 1), init=False, trainable=False)

        # 第一卷积层
        conv1 = ms.layer.conv([x], img_shape, 3, (5, 5), "ReLU")

        # 第一池化层
        pooling1 = ms.layer.pooling(conv1, (3, 3), (2, 2))

        # 第二卷积层
        conv2 = ms.layer.conv(pooling1, (14, 14), 3, (3, 3), "ReLU")

        # 第二池化层
        pooling2 = ms.layer.pooling(conv2, (3, 3), (2, 2))

        # 全连接层
        fc1 = ms.layer.fc(ms.ops.Concat(*pooling2), 147, 120, "ReLU")

        # 输出层
        output = ms.layer.fc(fc1, 120, 10, "None")

        # 分类概率
        predict = ms.ops.SoftMax(output)

        # 交叉熵损失
        loss = ms.ops.loss.CrossEntropyWithSoftMax(output, one_hot)

        return x, one_hot, predict, loss, conv1, conv2, fc1, output

    def extract_layer_weights(self, conv1, conv2, fc1, output):
        """提取各层权重用于压缩 - 修复版本"""
        layer_weights = {}
        layer_nodes = {}

        print("\n🔍 识别网络层权重:")

        # 修复6：更安全的权重识别
        weight_count = 0
        valid_nodes = []

        # 先收集所有有效的权重节点
        for node in ms.default_graph.nodes:
            if (isinstance(node, ms.core.Variable) and
                    node.trainable and
                    node.value is not None and
                    node.value.size > 0):
                valid_nodes.append(node)

        print(f"   发现 {len(valid_nodes)} 个候选权重节点")

        # 按照预期顺序识别层
        layer_names = ['conv1', 'conv2', 'fc1', 'output']

        for i, node in enumerate(valid_nodes[:4]):  # 最多处理4层
            if i < len(layer_names):
                layer_name = layer_names[i]

                # 检查权重维度合理性
                if len(node.value.shape) == 2 and node.value.shape[0] > 0 and node.value.shape[1] > 0:
                    layer_weights[layer_name] = node.value
                    layer_nodes[layer_name] = node
                    print(f"   ✅ {layer_name}: {node.value.shape}")
                    weight_count += 1
                else:
                    print(f"   ⚠️  跳过节点 {i}: 形状异常 {node.value.shape}")

        if weight_count == 0:
            print("   ❌ 未识别到有效的权重层")
        else:
            print(f"   📊 成功识别 {weight_count} 个权重层")

        return layer_weights, layer_nodes

    def apply_compression(self, layer_weights, layer_nodes, current_accuracy=None):
        """应用剪枝和量化压缩 - 完整修复版本"""
        if self.compression_applied:
            print("压缩已应用，跳过...")
            return

        print("\n" + "=" * 60)
        print("开始应用模型压缩...")
        print("=" * 60)

        # 修复1：检查输入数据有效性
        if not layer_weights:
            print("❌ 未找到有效的层权重，跳过压缩")
            return

        print(f"📊 发现 {len(layer_weights)} 个权重层:")
        for name, weights in layer_weights.items():
            print(f"   {name}: {weights.shape}")

        compressed_weights = copy.deepcopy(layer_weights)

        # 1. 结构化剪枝
        if self.enable_pruning:
            print("\n1. 执行结构化剪枝:")
            print("-" * 30)

            try:
                pruning_success = False

                for layer_name, weights in layer_weights.items():
                    print(f"\n🔧 处理层: {layer_name}")

                    # 修复2：检查每层权重的有效性
                    if weights.size == 0:
                        print(f"⚠️  {layer_name} 权重为空，跳过")
                        continue

                    if weights.shape[0] <= 1 or weights.shape[1] <= 1:
                        print(f"⚠️  {layer_name} 维度过小 {weights.shape}，跳过")
                        continue

                    try:
                        if layer_name == 'output':
                            # 输出层使用更保守的剪枝策略
                            print(f"   🛡️  输出层保护策略")
                            original_ratio = self.pruner.base_pruning_ratio
                            self.pruner.base_pruning_ratio = min(0.1, original_ratio)

                            compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
                            self.pruner.base_pruning_ratio = original_ratio
                            pruning_success = True

                        elif weights.shape[0] > 5:  # 只对有足够通道的层进行剪枝
                            compressed_weights[layer_name] = self.pruner.adaptive_prune_layer(weights, layer_name)
                            pruning_success = True
                        else:
                            print(f"   ⚠️  {layer_name} 输出维度过小({weights.shape[0]})，跳过剪枝")

                    except Exception as e:
                        print(f"   ❌ {layer_name} 剪枝失败: {e}")
                        # 剪枝失败时保持原权重
                        compressed_weights[layer_name] = weights

                # 获取剪枝统计
                if pruning_success:
                    try:
                        pruning_stats = self.pruner.get_pruning_statistics()
                        if 'error' not in pruning_stats:
                            print(f"\n✅ 剪枝完成！总体压缩比例: {pruning_stats['total_compression_ratio']:.2%}")
                            print(f"📉 减少参数数量: {pruning_stats['total_parameter_reduction']:,}")
                        else:
                            print(f"⚠️  剪枝统计计算有问题: {pruning_stats.get('error', 'Unknown')}")
                    except Exception as e:
                        print(f"⚠️  获取剪枝统计失败: {e}")
                else:
                    print("⚠️  没有成功剪枝任何层")

            except Exception as e:
                print(f"❌ 剪枝过程出现严重错误: {e}")
                # 剪枝完全失败时，保持原始权重
                compressed_weights = copy.deepcopy(layer_weights)

        # 2. 混合精度量化
        if self.enable_quantization:
            print("\n2. 执行混合精度量化:")
            print("-" * 30)

            try:
                # 修复3：更保守的精度配置
                custom_precision = {
                    'output': QuantizationType.FP16,  # 输出层使用FP16保护
                    'fc1': QuantizationType.INT16  # 全连接层使用INT16
                    # conv层让系统自动分析，通常会是INT8或INT16
                }

                # 检查待量化的权重
                valid_weights = {}
                for name, weights in compressed_weights.items():
                    if weights.size > 0 and weights.shape[0] > 0 and weights.shape[1] > 0:
                        valid_weights[name] = weights
                        print(f"   ✅ {name}: {weights.shape} - 准备量化")
                    else:
                        print(f"   ⚠️  {name}: {weights.shape} - 跳过量化")

                if valid_weights:
                    quantized_weights = self.quantizer.quantize_full_model(
                        valid_weights,
                        custom_precision
                    )

                    # 更新压缩权重（保留未量化的层）
                    for name, weights in quantized_weights.items():
                        compressed_weights[name] = weights

                    print("✅ 量化完成")
                else:
                    print("⚠️  没有有效权重可供量化")

            except Exception as e:
                print(f"❌ 量化过程失败: {e}")
                print("   继续使用剪枝后的权重...")

        # 3. 将压缩后的权重应用回网络
        print("\n3. 应用压缩后的权重到网络:")
        print("-" * 30)

        success_count = 0
        for layer_name, compressed_weight in compressed_weights.items():
            if layer_name in layer_nodes:
                try:
                    node = layer_nodes[layer_name]
                    original_shape = node.value.shape

                    # 修复4：检查形状兼容性
                    if compressed_weight.shape != original_shape:
                        print(f"   📐 更新 {layer_name}: {original_shape} -> {compressed_weight.shape}")

                        # 检查新形状是否合理
                        if compressed_weight.size > 0:
                            node.set_value(compressed_weight)
                            node.dim = compressed_weight.shape
                            success_count += 1
                            print(f"   ✅ {layer_name} 更新成功")
                        else:
                            print(f"   ❌ {layer_name} 压缩后权重为空，保持原状")
                    else:
                        # 形状相同，直接更新值
                        node.set_value(compressed_weight)
                        success_count += 1
                        print(f"   ✅ {layer_name} 权重已更新")

                except Exception as e:
                    print(f"   ❌ {layer_name} 更新失败: {e}")
            else:
                print(f"   ⚠️  未找到 {layer_name} 对应的节点")

        if success_count > 0:
            self.compression_applied = True
            print(f"\n✅ 成功更新 {success_count}/{len(compressed_weights)} 个层")
        else:
            print(f"\n❌ 没有成功更新任何层")

        # 4. 计算总体压缩统计
        try:
            self._print_compression_summary(layer_weights, compressed_weights)
        except Exception as e:
            print(f"⚠️  压缩统计计算失败: {e}")

        print("=" * 60)
        if self.compression_applied:
            print("✅ 模型压缩完成！")
        else:
            print("⚠️  模型压缩未完全成功")
        print("=" * 60)

    def _print_compression_summary(self, original_weights, compressed_weights):
        """打印压缩摘要 - 修复版本"""
        print("\n4. 压缩摘要:")
        print("-" * 30)

        try:
            # 修复5：安全计算参数数量
            total_original_params = 0
            total_compressed_params = 0

            valid_layers = 0

            for layer_name in original_weights.keys():
                if layer_name in compressed_weights:
                    orig_w = original_weights[layer_name]
                    comp_w = compressed_weights[layer_name]

                    if orig_w.size > 0 and comp_w.size > 0:
                        orig_params = orig_w.shape[0] * orig_w.shape[1]
                        comp_params = comp_w.shape[0] * comp_w.shape[1]

                        total_original_params += orig_params
                        total_compressed_params += comp_params
                        valid_layers += 1

                        print(f"   {layer_name}: {orig_params:,} -> {comp_params:,} "
                              f"({comp_params / orig_params:.2%})")

            if total_original_params > 0 and valid_layers > 0:
                compression_ratio = total_compressed_params / total_original_params
                parameter_reduction = total_original_params - total_compressed_params

                print(f"\n   📊 压缩统计:")
                print(f"   原始参数数量: {total_original_params:,}")
                print(f"   压缩后参数数量: {total_compressed_params:,}")
                print(f"   总体压缩比例: {compression_ratio:.2%}")
                print(f"   参数减少数量: {parameter_reduction:,}")
                print(f"   模型大小减少: {(1 - compression_ratio) * 100:.1f}%")
                print(f"   有效处理层数: {valid_layers}")
            else:
                print("   ⚠️  无法计算压缩统计（参数数量为0）")

        except Exception as e:
            print(f"   ❌ 压缩统计计算失败: {e}")

    def train_with_compression(self, num_epochs=60, batch_size=32, learning_rate=0.005,
                               compression_epoch=20):
        """
        带压缩的训练流程

        Args:
            num_epochs: 训练轮数
            batch_size: 批大小
            learning_rate: 学习率
            compression_epoch: 在第几轮开始应用压缩
        """
        # 准备数据
        X, y, one_hot_label = self.load_and_prepare_data()

        # 构建网络
        x, one_hot, predict, loss, conv1, conv2, fc1, output = self.build_network()

        # 优化器
        optimizer = ms.optimizer.Adam(ms.default_graph, loss, learning_rate)

        # 跟踪最佳精度
        best_accuracy = 0.0
        accuracy_history = []

        print(f"\n开始训练 - 计划在第 {compression_epoch} 轮应用压缩")
        print("=" * 80)

        for epoch in range(num_epochs):
            start_time = time.time()
            batch_count = 0
            total_loss = 0.0

            # 训练一轮
            for i in range(len(X)):
                feature = np.mat(X[i]).reshape((28, 28))
                label = np.mat(one_hot_label[i]).T

                x.set_value(feature)
                one_hot.set_value(label)

                optimizer.one_step()

                current_loss = loss.value[0, 0]
                total_loss += current_loss

                batch_count += 1
                if batch_count >= batch_size:
                    optimizer.update()

                    if epoch < 5 or epoch % 5 == 0:  # 减少打印频率
                        print(f"epoch: {epoch + 1}, iteration: {i + 1}, loss: {total_loss / batch_count:.6f}")

                    batch_count = 0
                    total_loss = 0.0

            # 计算精度
            pred = []
            for i in range(len(X)):
                feature = np.mat(X[i]).reshape((28, 28))
                x.set_value(feature)
                predict.forward()
                pred.append(predict.value.A.ravel())

            pred = np.array(pred).argmax(axis=1)
            accuracy = (y == pred).astype(int).sum() / len(X)
            accuracy_history.append(accuracy)

            # 更新最佳精度
            if accuracy > best_accuracy:
                best_accuracy = accuracy
                print(f"🎯 新的最佳精度: {best_accuracy:.3f}")

            end_time = time.time()
            epoch_duration = end_time - start_time

            print(f"epoch: {epoch + 1}, accuracy: {accuracy:.3f}, "
                  f"best_accuracy: {best_accuracy:.3f}, time: {epoch_duration:.2f}s")

            # 在指定轮次应用压缩
            if epoch + 1 == compression_epoch and not self.compression_applied:
                print(f"\n⚡ 第 {epoch + 1} 轮，开始应用模型压缩...")

                # 记录压缩前的基准精度
                self.baseline_accuracy = accuracy

                # 提取层权重
                layer_weights, layer_nodes = self.extract_layer_weights(conv1, conv2, fc1, output)

                # 应用压缩
                self.apply_compression(layer_weights, layer_nodes, accuracy)

                print(f"📊 压缩前精度: {self.baseline_accuracy:.3f}")
                print("继续训练以评估压缩效果...\n")

            # 学习率调整
            if (epoch + 1) % 20 == 0:
                learning_rate *= 0.8
                optimizer.learning_rate = learning_rate
                print(f"📉 学习率调整为: {learning_rate:.6f}")

            print("-" * 80)

        print("\n🎉 训练完成！")
        print("=" * 80)

        # 最终统计
        final_stats = {
            'best_accuracy': best_accuracy,
            'baseline_accuracy': self.baseline_accuracy,
            'accuracy_history': accuracy_history,
            'compression_applied': self.compression_applied
        }

        if self.compression_applied:
            accuracy_drop = self.baseline_accuracy - best_accuracy if best_accuracy < self.baseline_accuracy else 0
            print(f"📈 最终最佳精度: {best_accuracy:.3f}")
            print(f"📊 压缩前基准精度: {self.baseline_accuracy:.3f}")
            if accuracy_drop > 0:
                print(f"📉 精度下降: {accuracy_drop:.3f} ({accuracy_drop / self.baseline_accuracy * 100:.1f}%)")
            else:
                improvement = best_accuracy - self.baseline_accuracy
                print(f"📈 精度提升: {improvement:.3f} ({improvement / self.baseline_accuracy * 100:.1f}%)")
        else:
            print(f"📈 最终最佳精度: {best_accuracy:.3f}")

        print("=" * 80)

        return final_stats


# 主训练函数 - 修复版本
def main():
    """主训练函数 - 修复版本"""
    print("🚀 开始集成剪枝和量化的CNN训练")
    print("=" * 80)

    try:
        # 创建训练器
        trainer = CompressedCNNTrainer(
            pruning_ratio=0.2,  # 降低到20%剪枝率，更保守
            enable_quantization=True,  # 启用量化
            enable_pruning=True  # 启用剪枝
        )

        # 开始训练
        stats = trainer.train_with_compression(
            num_epochs=60,
            batch_size=32,
            learning_rate=0.005,
            compression_epoch=20  # 在第20轮应用压缩
        )

        print("\n📊 训练统计:")
        print(f"最佳精度: {stats['best_accuracy']:.3f}")
        if stats['compression_applied']:
            print(f"压缩前精度: {stats['baseline_accuracy']:.3f}")

        return stats

    except Exception as e:
        print(f"\n❌ 训练过程中出现错误: {e}")
        import traceback
        traceback.print_exc()

        # 尝试提供一些调试信息
        print("\n🔧 调试建议:")
        print("1. 检查MatrixSlow框架是否正确安装")
        print("2. 确认数据集能够正常加载")
        print("3. 验证网络结构是否正确构建")
        print("4. 检查compression模块的导入路径")

        return None


if __name__ == "__main__":
    # 运行训练
    training_stats = main()