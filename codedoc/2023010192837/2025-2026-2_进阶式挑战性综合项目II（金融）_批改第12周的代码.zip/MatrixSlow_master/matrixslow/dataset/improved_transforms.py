import numpy as np
from scipy import ndimage
from .transform import Transform


class RandomRotation(Transform):
    """改进的随机旋转类"""

    def __init__(self, degrees=10):
        """
        初始化随机旋转变换

        Args:
            degrees: 旋转角度范围 (-degrees, degrees)
        """
        self.degrees = degrees

    def __call__(self, data):
        """对数据应用随机旋转变换"""
        # 保存原始形状
        original_shape = data.shape
        is_1d = len(original_shape) == 1

        # 如果是一维数据(如展平的图像)，尝试重塑为二维
        if is_1d:
            # 计算最接近的平方尺寸
            size = int(np.sqrt(len(data)))

            # 检查是否为完美平方
            if size * size != len(data):
                # 不是完美平方，创建临时数组并填充
                size = int(np.ceil(np.sqrt(len(data))))
                temp = np.zeros(size * size)
                temp[:len(data)] = data
                data = temp.reshape(size, size)
            else:
                data = data.reshape(size, size)

        # 如果是二维特征向量(x,y)，使用旋转矩阵
        elif len(original_shape) == 2 and original_shape[0] == 2:
            # 二维特征向量的旋转
            theta = np.random.uniform(-self.degrees, self.degrees) * np.pi / 180
            rotation_matrix = np.array([
                [np.cos(theta), -np.sin(theta)],
                [np.sin(theta), np.cos(theta)]
            ])
            return np.dot(rotation_matrix, data)

        # 随机选择角度并执行旋转
        angle = np.random.uniform(-self.degrees, self.degrees)
        data = ndimage.rotate(data, angle, reshape=False, mode='nearest')

        # 如果原始数据是一维的，将其展平回去
        if is_1d:
            data = data.flatten()[:original_shape[0]]  # 确保长度正确

        return data


class GaussianNoise(Transform):
    """添加高斯噪声"""

    def __init__(self, mean=0.0, std=0.1):
        """
        初始化高斯噪声变换

        Args:
            mean: 噪声的均值
            std: 噪声的标准差
        """
        self.mean = mean
        self.std = std

    def __call__(self, data):
        """对数据添加高斯噪声"""
        noise = np.random.normal(self.mean, self.std, data.shape)
        return data + noise


class RandomErase(Transform):
    """随机擦除变换 - 模拟遮挡"""

    def __init__(self, p=0.5, scale=(0.02, 0.2), ratio=(0.3, 3.3), value=0):
        """
        初始化随机擦除变换

        Args:
            p: 执行变换的概率
            scale: 擦除区域相对于整个图像面积的比例范围
            ratio: 擦除区域的宽高比范围
            value: 填充值
        """
        self.p = p
        self.scale = scale
        self.ratio = ratio
        self.value = value

    def __call__(self, data):
        """对数据应用随机擦除变换"""
        if np.random.random() > self.p:
            return data

        original_shape = data.shape
        is_1d = len(original_shape) == 1

        # 重塑为2D图像
        if is_1d:
            size = int(np.sqrt(len(data)))
            if size * size != len(data):
                size = int(np.ceil(np.sqrt(len(data))))
                temp = np.zeros(size * size)
                temp[:len(data)] = data
                data = temp.reshape(size, size)
            else:
                data = data.reshape(size, size)

        # 获取图像尺寸
        h, w = data.shape
        area = h * w

        # 随机选择擦除区域的面积和宽高比
        for _ in range(10):  # 最多尝试10次
            target_area = np.random.uniform(self.scale[0], self.scale[1]) * area
            aspect_ratio = np.random.uniform(self.ratio[0], self.ratio[1])

            # 计算擦除区域的宽和高
            ew = int(np.sqrt(target_area * aspect_ratio))
            eh = int(np.sqrt(target_area / aspect_ratio))

            if 0 < ew < w and 0 < eh < h:
                # 随机选择起始坐标
                x = np.random.randint(0, w - ew)
                y = np.random.randint(0, h - eh)

                # 执行擦除
                data[y:y + eh, x:x + ew] = self.value
                break

        # 恢复原始形状
        if is_1d:
            data = data.flatten()[:original_shape[0]]

        return data


class RandomShift(Transform):
    """随机平移变换"""

    def __init__(self, shift_range=0.1, p=0.5):
        """
        初始化随机平移变换

        Args:
            shift_range: 平移范围，相对于图像尺寸的比例
            p: 执行变换的概率
        """
        self.shift_range = shift_range
        self.p = p

    def __call__(self, data):
        """对数据应用随机平移变换"""
        if np.random.random() > self.p:
            return data

        original_shape = data.shape
        is_1d = len(original_shape) == 1

        # 重塑为2D图像
        if is_1d:
            size = int(np.sqrt(len(data)))
            if size * size != len(data):
                size = int(np.ceil(np.sqrt(len(data))))
                temp = np.zeros(size * size)
                temp[:len(data)] = data
                data = temp.reshape(size, size)
            else:
                data = data.reshape(size, size)

        # 获取图像尺寸
        h, w = data.shape

        # 计算平移量
        tx = int(w * self.shift_range * np.random.uniform(-1, 1))
        ty = int(h * self.shift_range * np.random.uniform(-1, 1))

        # 使用scipy的平移函数
        data = ndimage.shift(data, (ty, tx), mode='constant', cval=0)

        # 恢复原始形状
        if is_1d:
            data = data.flatten()[:original_shape[0]]

        return data


class RandomZoom(Transform):
    """随机缩放变换"""

    def __init__(self, zoom_range=(0.9, 1.1), p=0.5):
        """
        初始化随机缩放变换

        Args:
            zoom_range: 缩放范围的元组 (min_zoom, max_zoom)
            p: 执行变换的概率
        """
        self.zoom_range = zoom_range
        self.p = p

    def __call__(self, data):
        """对数据应用随机缩放变换"""
        if np.random.random() > self.p:
            return data

        original_shape = data.shape
        is_1d = len(original_shape) == 1

        # 重塑为2D图像
        if is_1d:
            size = int(np.sqrt(len(data)))
            if size * size != len(data):
                size = int(np.ceil(np.sqrt(len(data))))
                temp = np.zeros(size * size)
                temp[:len(data)] = data
                data = temp.reshape(size, size)
            else:
                data = data.reshape(size, size)

        # 随机选择缩放因子
        zoom_factor = np.random.uniform(self.zoom_range[0], self.zoom_range[1])

        # 使用scipy的缩放函数
        data = ndimage.zoom(data, zoom_factor, mode='nearest')

        # 调整回原始尺寸
        if data.shape[0] != size or data.shape[1] != size:
            # 如果缩放后尺寸变大，裁剪中心部分
            if data.shape[0] > size:
                start = (data.shape[0] - size) // 2
                data = data[start:start + size, start:start + size]
            # 如果缩放后尺寸变小，填充周围
            else:
                temp = np.zeros((size, size))
                start = (size - data.shape[0]) // 2
                temp[start:start + data.shape[0], start:start + data.shape[1]] = data
                data = temp

        # 恢复原始形状
        if is_1d:
            data = data.flatten()[:original_shape[0]]

        return data