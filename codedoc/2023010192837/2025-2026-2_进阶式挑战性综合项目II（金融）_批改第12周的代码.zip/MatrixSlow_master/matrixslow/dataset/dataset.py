# dataset/dataset.py
import numpy as np
import os
import gzip
import struct
import urllib.request


class Dataset:
    """数据集基类，定义数据集的基本接口"""

    def __init__(self):
        pass

    def __len__(self):
        """返回数据集中样本总数"""
        raise NotImplementedError

    def __getitem__(self, index):
        """根据索引返回数据样本"""
        raise NotImplementedError

    def __iter__(self):
        """返回一个迭代器"""
        for i in range(len(self)):
            yield self[i]


class ArrayDataset(Dataset):
    """基于NumPy数组的数据集"""

    def __init__(self, X, y=None, transform=None):
        super().__init__()
        self.X = X
        self.y = y
        self.transform = transform

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        X = self.X[index].copy()  # 复制以避免修改原始数据
        if self.transform:
            X = self.transform(X)

        if self.y is not None:
            return X, self.y[index]
        return X


class MNISTDataset(Dataset):
    """MNIST手写数字数据集"""

    def __init__(self, root_dir='./data', train=True, transform=None,
                 download=True, max_samples=None, normalize=True, center=True):
        super().__init__()
        self.root_dir = root_dir
        self.transform = transform
        self.train = train
        self.max_samples = max_samples
        self.normalize = normalize
        self.center = center

        # 数据集URL
        if train:
            self.images_file = 'train-images-idx3-ubyte.gz'
            self.labels_file = 'train-labels-idx1-ubyte.gz'
            self.images_url = f'http://yann.lecun.com/exdb/mnist/{self.images_file}'
            self.labels_url = f'http://yann.lecun.com/exdb/mnist/{self.labels_file}'
        else:
            self.images_file = 't10k-images-idx3-ubyte.gz'
            self.labels_file = 't10k-labels-idx1-ubyte.gz'
            self.images_url = f'http://yann.lecun.com/exdb/mnist/{self.images_file}'
            self.labels_url = f'http://yann.lecun.com/exdb/mnist/{self.labels_file}'

        # 如果需要下载且没有下载过
        if download:
            self._download_mnist()

        # 加载数据
        self.images, self.labels = self._load_mnist()

        # 预处理
        if self.normalize:
            self.images = self.images / 255.0

        if self.center:
            self.mean = np.mean(self.images, axis=0)
            self.images = self.images - self.mean

    def _download_mnist(self):
        """如果MNIST数据集尚未下载，则下载它"""
        import os
        import gzip
        import urllib.request

        # 如果目录不存在，则创建
        os.makedirs(self.root_dir, exist_ok=True)

        # 使用更可靠的MNIST数据集URL
        base_url = 'http://yann.lecun.com/exdb/mnist/'
        files = {
            'train_images': 'train-images-idx3-ubyte.gz',
            'train_labels': 'train-labels-idx1-ubyte.gz',
            'test_images': 't10k-images-idx3-ubyte.gz',
            'test_labels': 't10k-labels-idx1-ubyte.gz'
        }

        # 如果文件不存在，则下载
        for file_name in files.values():
            file_path = os.path.join(self.root_dir, file_name)
            if not os.path.exists(file_path):
                print(f"正在下载 {file_name}...")
                try:
                    urllib.request.urlretrieve(base_url + file_name, file_path)
                    print(f"已下载 {file_name}")
                except Exception as e:
                    print(f"下载 {file_name} 时出错: {e}")
                    # 如果主要来源失败，尝试替代方法
                    try:
                        alternative_url = f"https://storage.googleapis.com/cvdf-datasets/mnist/{file_name}"
                        print(f"尝试替代URL: {alternative_url}")
                        urllib.request.urlretrieve(alternative_url, file_path)
                        print(f"成功从替代来源下载 {file_name}")
                    except Exception as e2:
                        print(f"从替代来源下载失败: {e2}")
                        raise Exception(f"无法下载MNIST数据集。请手动下载并放置在 {self.root_dir} 中")

    def _load_mnist(self):
        """加载MNIST数据集"""
        # 加载图像
        images_path = os.path.join(self.root_dir, self.images_file)
        with gzip.open(images_path, 'rb') as f:
            # 读取文件头: magic number, 图像数量, 行数, 列数
            magic, num, rows, cols = struct.unpack('>IIII', f.read(16))
            # 读取图像数据
            images = np.frombuffer(f.read(), dtype=np.uint8).reshape(-1, rows * cols)

        # 加载标签
        labels_path = os.path.join(self.root_dir, self.labels_file)
        with gzip.open(labels_path, 'rb') as f:
            # 读取文件头: magic number, 标签数量
            magic, num = struct.unpack('>II', f.read(8))
            # 读取标签数据
            labels = np.frombuffer(f.read(), dtype=np.uint8)

        # 限制样本数量
        if self.max_samples is not None and self.max_samples < len(images):
            images = images[:self.max_samples]
            labels = labels[:self.max_samples]

        return images, labels

    def __len__(self):
        return len(self.images)

    def __getitem__(self, index):
        """获取指定索引的样本"""
        image = self.images[index].copy()
        if self.transform:
            image = self.transform(image)
        return image, self.labels[index]

    @staticmethod
    def to_one_hot(labels, num_classes=10):
        """将整数标签转换为one-hot编码"""
        one_hot = np.zeros((len(labels), num_classes))
        for i, label in enumerate(labels):
            one_hot[i, label] = 1
        return one_hot