# dataset/transform.py
import numpy as np


class Transform:
    """数据变换基类"""

    def __call__(self, data):
        """应用变换到数据"""
        raise NotImplementedError


class OneHotEncoder(Transform):
    """独热编码转换"""

    def __init__(self, num_classes):
        self.num_classes = num_classes

    def __call__(self, label):
        """将标签转换为独热编码"""
        one_hot = np.zeros(self.num_classes)
        one_hot[label] = 1
        return one_hot

class Compose(Transform):
    """组合多个变换"""

    def __init__(self, transforms):
        self.transforms = transforms

    def __call__(self, data):
        for t in self.transforms:
            data = t(data)
        return data


class Normalize(Transform):
    """标准化"""
    def __init__(self, mean=0, std=1):
        self.mean = mean
        self.std = std

    def __call__(self, data):
        return (data - self.mean) / self.std


class RandomFlip(Transform):
    """随机翻转"""

    def __init__(self, p=0.5):
        self.p = p

    def __call__(self, data):
        if np.random.random() < self.p:
            # 如果数据是一维的（展平的图像），则需要先重塑
            if len(data.shape) == 1:
                size = int(np.sqrt(data.shape[0]))
                return np.flip(data.reshape(size, size), axis=1).reshape(-1)
            return np.flip(data, axis=1)
        return data


class RandomRotation(Transform):
    """随机旋转"""

    def __init__(self, degrees=10):
        self.degrees = degrees

    def __call__(self, data):
        # 此实现简化了，实际应用中可能需要更复杂的图像处理库
        if len(data.shape) == 1:
            size = int(np.sqrt(data.shape[0]))
            data = data.reshape(size, size)

        # 随机选择旋转角度
        k = np.random.choice([1, 2, 3])  # 90, 180, 270度旋转
        data = np.rot90(data, k)

        # 如果原数据是一维的，则需要展平回去
        if len(data.shape) == 1:
            data = data.reshape(-1)

        return data


class DataCleaner(Transform):
    """增强版数据清洗转换 - 专用于NumPy数组"""

    def __init__(self, threshold=0.0, replace_value=0.0):
        self.threshold = threshold
        self.replace_value = replace_value

    def __call__(self, data):
        """处理异常值、缺失值等"""
        # 处理异常值
        data = np.where(data > self.threshold, data, self.replace_value)
        return data

    def full_clean(self, data, remove_duplicates=True,handle_missing=True, missing_strategy='replace'):
        # 处理缺失值
        if handle_missing:
            data = self.handle_missing_values(data, strategy=missing_strategy)

        # 去除重复数据
        if remove_duplicates:
            data = self.remove_duplicates(data)

        return data

    def remove_duplicates(self, data):
        """去除重复数据"""
        # 对NumPy数组使用unique函数进行去重
        return np.unique(data, axis=0)

    def handle_missing_values(self, data, strategy='replace'):
        """处理缺失值"""
        if strategy == 'replace':
            # 替换NaN值为指定值
            return np.nan_to_num(data, nan=self.replace_value)
        elif strategy == 'drop':
            # 移除含有NaN的行
            return data[~np.isnan(data).any(axis=1)]
        return data

class OutlierRemoval(Transform):
    """异常值检测与移除"""

    def __init__(self, lower_quantile=0.01, upper_quantile=0.99):
        self.lower_quantile = lower_quantile
        self.upper_quantile = upper_quantile

    def __call__(self, data):
        import numpy as np
        # 计算分位数阈值
        lower_bound = np.quantile(data, self.lower_quantile)
        upper_bound = np.quantile(data, self.upper_quantile)

        # 剪裁异常值
        return np.clip(data, lower_bound, upper_bound)

