# dataset/dataloader.py
import numpy as np
from ..core.node import Variable


class DataLoader:
    """数据加载器，用于批量加载数据"""

    def __init__(self, dataset, batch_size=32, shuffle=True, seed=None):
        """
        初始化数据加载器

        Args:
            dataset: 数据集对象，必须实现__len__和__getitem__方法
            batch_size: 批大小
            shuffle: 是否在每个epoch开始时打乱数据
            seed: 随机种子
        """
        self.dataset = dataset
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.seed = seed
        self.rng = np.random.RandomState(seed) if seed is not None else np.random
        self.indices = np.arange(len(dataset))
        if shuffle:
            self.rng.shuffle(self.indices)

    def __iter__(self):
        """返回一个批次迭代器"""
        if self.shuffle:
            self.rng.shuffle(self.indices)

        for start_idx in range(0, len(self.dataset), self.batch_size):
            batch_indices = self.indices[start_idx:min(start_idx + self.batch_size, len(self.dataset))]

            # 获取批次数据
            batch = [self.dataset[i] for i in batch_indices]

            if isinstance(batch[0], tuple) and len(batch[0]) == 2:
                # 分离特征和标签
                X_batch = np.array([item[0] for item in batch])
                y_batch = np.array([item[1] for item in batch])

                # 将NumPy数组转换为框架的Variable
                # 注意：这里假设X_batch需要转置为列向量矩阵，根据框架的实际需求调整
                X_var = Variable(X_batch.T)
                y_var = Variable(y_batch.reshape(-1, 1))

                yield X_var, y_var
            else:
                # 只有特征，没有标签
                X_batch = np.array(batch)
                X_var = Variable(X_batch.T)
                yield X_var

    def __len__(self):
        """返回批次数量"""
        return (len(self.dataset) + self.batch_size - 1) // self.batch_size