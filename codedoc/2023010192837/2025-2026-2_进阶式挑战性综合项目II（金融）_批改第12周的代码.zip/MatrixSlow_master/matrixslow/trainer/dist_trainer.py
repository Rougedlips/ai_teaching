# -*- coding: utf-8 -*-
"""
Created on Thu Jul 18 20:48:16 CST 2019

@author: chenzhen
"""
import math
import threading
import time
import numpy as np

from ..core import (Variable, get_trainable_variables_from_graph,
                    update_node_value_in_graph)
from ..core.graph import default_graph
from ..dist import allreduce, ps , tree_allreduce
from .trainer import Trainer


class DistTrainerParameterServer(Trainer):

    def __init__(self, *args, **kargs):
        Trainer.__init__(self, *args, **kargs)
        cluster_conf = kargs['cluster_conf']
        ps_host = cluster_conf['ps'][0]
        self.ps_client = ps.ParameterServiceClient(ps_host)


    def _variable_weights_init(self):
        '''
        多个worker通过ps保证变量节点初始化一致
        '''
        var_weights_dict = dict()
        for node in default_graph.nodes:
            if isinstance(node, Variable) and node.trainable:
                var_weights_dict[node.name] = node.value

        # 把自己的初始值发送给ps，由ps决定使用哪个Worker并返回
        duplicated_var_weights_dict = self.ps_client.variable_weights_init(
            var_weights_dict)

        # 使用ps返回的初始值，重新初始化本地
        for var_name, weights in duplicated_var_weights_dict.items():
            update_node_value_in_graph(var_name, weights)

        print('[INIT] Worker variable weights initialized')


    def _optimizer_update(self):

        # 把当前梯度push到ps上。此操作可能被block，直到所有节点都pull完成
        acc_gradient = self.optimizer.acc_gradient
        self.ps_client.push_gradients(
            acc_gradient, self.optimizer.acc_no)

        # 从ps把所有节点的平均梯度pull回来。此操作可能被block直到所有节点都push完成
        node_gradients_dict = self.ps_client.pull_gradients()

        # 使用平均梯度，利用优化器的优化算法，更新本地变量
        self.optimizer.update(node_gradients_dict)


class DistTrainerRingAllReduce(Trainer):
    '''
    Ring All-Reduce模式的分布式训练
    '''

    def __init__(self, *args, **kargs):
        Trainer.__init__(self, *args, **kargs)

        # 读取集群配置信息和自身信息
        self.cluster_conf = kargs['cluster_conf']
        self.worker_index = kargs['worker_index']

        self.workers = self.cluster_conf['workers']
        self.worker_num = len(self.workers)
        self.host = self.workers[self.worker_index]

        self.step = self.worker_num - 1

        # 根据集群的环状拓扑结构确定右邻居
        self.target_host = self.workers[(
            self.worker_index + 1) % self.worker_num]

        # 本节点是否已被初始化
        self.is_init = False
        self.init_cond = threading.Condition()

        self.cur_partion_index = self.worker_index
        self.partition = []

        # 获取所有可训练节点
        self.variables = get_trainable_variables_from_graph()

        # 根据worker的总数量，对即将更新的变量节点列表进行等长切分
        self._partition_variables()

        # 用于控制梯度的发送和接收
        self.is_recieved = False
        self.recieved_gradients = None
        self.recieved_acc_no = None
        self.cond = threading.Condition()

        # 创建本节点的梯度接收服务
        allreduce.RingAllReduceServer(
            self.host, self.worker_index,
            self._variable_weights_init_callback,
            self._scatter_callback,
            self._gather_callback).serve()

        # 创建连接目标节点的梯度发送client
        self.client = allreduce.RingAllReduceClient(self.target_host)


    def _variable_weights_init(self):

        var_weights_dict = dict()
        for node in default_graph.nodes:
            if isinstance(node, Variable) and node.trainable:
                var_weights_dict[node.name] = node.value
        print('[INIT] Send variable init weights to worker ', self.target_host)

        # 第一个节点不需要等待，使用默认值更新给下一个节点
        if self.worker_index == 0:
            self.client.variable_weights_init(var_weights_dict)
        else:
            self.init_cond.acquire()
            while not self.is_init:
                self.init_cond.wait()
            self.init_cond.release()
            self.client.variable_weights_init(var_weights_dict)


    def _variable_weights_init_callback(self, var_weights_dict):

        # 第一个节点不需要接收上一个节点的初始值
        if self.worker_index != 0:
            print('[INIT] Variables initializing weights from last worker node...')
            for var_name, weights in var_weights_dict.items():
                update_node_value_in_graph(var_name, weights)

        # 已初始化完成，通知发送流程
        self.init_cond.acquire()
        self.is_init = True
        self.init_cond.notify_all()
        self.init_cond.release()


    def _optimizer_update(self):

        # 共执行 N-1 次scatter操作，把本worker的梯度切片发送给下一个worker
        # 同时接收左邻居发送过来的梯度，累加到自己的对应切片上
        for scatter_index in range(self.step):
            gradients_part = self._get_gradients_partition()
            cur_acc_no = self.optimizer.acc_no if scatter_index == 0 else self.recieved_acc_no

            # 把自身的一个数据分块发送给右邻居
            self.client.send(gradients_part, cur_acc_no, 'scatter')

            # 等待接收并处理完左邻居节点的数据
            self._wait_for_recieve('scatter')

        # 然后执行 N-1 次all-gather操作，把本worker的梯度切片发送给下一个worker
        # 同时接收上一个worker发送过来的梯度并替换自己的对应切片
        for gather_index in range(self.step):
            gradients_part = self._get_gradients_partition()
            self.client.send(gradients_part, 0, 'gather')
            self._wait_for_recieve('gather')

        self.optimizer.update()


    def _partition_variables(self):
        '''
        根据worker的总数量，对即将更新的权值变量列表进行等长切分
        '''
        var_num = len(self.variables)
        part_length = math.ceil(var_num / self.worker_num)
        assert part_length > 0

        start = 0
        end = start + part_length
        for i in range(self.worker_num - 1):
            self.partition.append((start, end))
            start = end
            end = start + part_length

        self.partition.append((start, var_num))


    def _get_gradients_partition(self):
        '''
        获取下一个梯度切片
        '''
        start, end = self.partition[self.cur_partion_index]
        part_variables = self.variables[start:end]
        self.cur_partion_index = (
            self.cur_partion_index + self.step) % self.worker_num
        part_gradients = dict()
        for var in part_variables:
            part_gradients[var] = self.optimizer.acc_gradient[var]
        return part_gradients


    def _scatter_callback(self, node_gradients_dict, acc_no):
        '''
        Scatter 阶段的回调函数，接收上一个worker发送过来的梯度和样本数
        '''
        if self.cond.acquire():
            while self.is_recieved:
                self.cond.wait()

            # 把接收到的梯度缓存下来
            self.recieved_gradients = node_gradients_dict
            self.recieved_acc_no = acc_no
            self.is_recieved = True

            # 通知主流程，把接收到的梯度更新到优化器
            self.cond.notify_all()
            self.cond.release()
        else:
            self.cond.wait()


    def _gather_callback(self, node_gradients_dict):
        '''
        All-gather 阶段的回调函数，接收上一个worker发送来的梯度
        '''
        if self.cond.acquire():
            while self.is_recieved:
                self.cond.wait()

            self.recieved_gradients = node_gradients_dict
            self.is_recieved = True

            # 通知主流程，把接收到的梯度更新到优化器
            self.cond.notify_all()
            self.cond.release()
        else:
            self.cond.wait()


    def _wait_for_recieve(self, stage):
        '''
        等待梯度，并把接收到的梯度更新到优化器中
        '''
        if self.cond.acquire():
            while not self.is_recieved:
                self.cond.wait()

            # 如果是scatter阶段则累加梯度，同时累加样本数
            if stage == 'scatter':
                self.optimizer.apply_gradients(
                    self.recieved_gradients,  summarize=True, acc_no=self.recieved_acc_no)

            # 如果是all-gather阶段则覆盖梯度，样本数保持不变
            else:
                self.optimizer.apply_gradients(
                    self.recieved_gradients, summarize=False, acc_no=self.optimizer.acc_no)

            self.is_recieved = False

            # 梯度已被更新，通知接收流程继续接收新的梯度
            self.cond.notify_all()
            self.cond.release()
        else:
            self.cond.wait()

# class DistTrainerTreeAllReduce(Trainer):
#     """
#     Tree All-Reduce 模式的分布式训练
#     """
#
#     def __init__(self, *args, **kargs):
#         Trainer.__init__(self, *args, **kargs)
#
#         # 集群信息
#         self.cluster_conf = kargs['cluster_conf']
#         self.worker_index = kargs['worker_index']
#
#         self.workers = self.cluster_conf['workers']
#         self.worker_num = len(self.workers)
#         self.host = self.workers[self.worker_index]
#
#         # 本节点是否已初始化
#         self.is_init = False
#         self.init_cond = threading.Condition()
#
#         # 获取所有可训练变量
#         self.variables = get_trainable_variables_from_graph()
#
#         # 用于梯度接收
#         self.is_recieved = False
#         self.recieved_gradients = None
#         self.recieved_acc_no = None
#         self.cond = threading.Condition()
#
#         # 创建 TreeAllReduce 的服务端
#         self.server = tree_allreduce.TreeAllReduceServer(
#             host=self.host,
#             worker_index=self.worker_index,
#             total_workers=self.worker_num,
#             vars_init_fn=self._variable_weights_init_callback,
#             reduce_fn=self._reduce_callback,
#             broadcast_fn=self._broadcast_callback
#         )
#         self.server.serve()
#
#         # 创建客户端
#         self.client = tree_allreduce.TreeAllReduceClient(
#             worker_hosts=self.workers,
#             worker_index=self.worker_index,
#             total_workers=self.worker_num
#         )
#
#         # 协调器
#         self.coordinator = tree_allreduce.TreeAllReduceCoordinator(
#             worker_index=self.worker_index,
#             total_workers=self.worker_num,
#             client=self.client,
#             server_service=self.server.server._state.generic_handlers[0]._method_handlers[
#                 'ReceiveReduce']._unary_unary.servicer
#         )
#
#     # ====== 初始化阶段 ======
#     def _variable_weights_init(self):
#         """发送本地初始参数"""
#         var_weights_dict = {var.name: var.value for var in self.variables}
#         print(f'[INIT] Worker {self.worker_index} send init weights')
#
#         if self.worker_index == 0:
#             self.client.variable_weights_init(var_weights_dict)
#         else:
#             self.init_cond.acquire()
#             while not self.is_init:
#                 self.init_cond.wait()
#             self.init_cond.release()
#             self.client.variable_weights_init(var_weights_dict)
#
#     def _variable_weights_init_callback(self, var_weights_dict):
#         """接收上游参数"""
#         if self.worker_index != 0:
#             print(f'[INIT] Worker {self.worker_index} initializing from parent node')
#             for var_name, weights in var_weights_dict.items():
#                 update_node_value_in_graph(var_name, weights)
#
#         self.init_cond.acquire()
#         self.is_init = True
#         self.init_cond.notify_all()
#         self.init_cond.release()
#
#     # ====== Reduce 阶段 ======
#     def _reduce_callback(self, child_gradients_dict):
#         """合并子节点梯度"""
#         print(f'[REDUCE] Worker {self.worker_index} reduce {len(child_gradients_dict)} children')
#
#         merged_gradients = {}
#         for child_id, gradients in child_gradients_dict.items():
#             for key, value in gradients.items():
#                 if key not in merged_gradients:
#                     merged_gradients[key] = value
#                 else:
#                     merged_gradients[key] += value
#
#         # 加上自己的梯度
#         for key, value in self.optimizer.acc_gradient.items():
#             if key not in merged_gradients:
#                 merged_gradients[key] = value
#             else:
#                 merged_gradients[key] += value
#
#         self.recieved_gradients = merged_gradients
#         self.recieved_acc_no = self.optimizer.acc_no
#
#     # ====== Broadcast 阶段 ======
#     def _broadcast_callback(self, final_gradients):
#         """下发最终梯度"""
#         print(f'[BROADCAST] Worker {self.worker_index} update local params')
#         self.optimizer.apply_gradients(final_gradients, summarize=False, acc_no=self.optimizer.acc_no)
#
#     # ====== 执行一次训练步骤 ======
#     def _optimizer_update(self):
#         """一次梯度同步与更新"""
#         # 执行 tree allreduce
#         self.coordinator.execute_allreduce(self.optimizer.acc_gradient)
#         # 本地参数已在 broadcast 阶段更新
#


class DistTrainerTreeAllReduce(Trainer):
    """
    Tree All-Reduce 模式的分布式训练
    """

    def __init__(self, *args, **kargs):
        Trainer.__init__(self, *args, **kargs)

        # 集群信息
        self.cluster_conf = kargs['cluster_conf']
        self.worker_index = kargs['worker_index']

        self.workers = self.cluster_conf['workers']
        self.worker_num = len(self.workers)
        self.host = self.workers[self.worker_index]

        # 构建二叉树拓扑
        self._build_tree_topology()

        # 本节点是否已被初始化
        self.is_init = False
        self.init_cond = threading.Condition()

        # 获取所有可训练变量
        self.variables = get_trainable_variables_from_graph()

        # 用于梯度接收和同步
        self.is_received = False
        self.received_gradients = None
        self.received_acc_no = None
        self.cond = threading.Condition()

        # 用于reduce阶段的梯度聚合
        self.children_gradients = {}
        self.reduce_ready = False
        self.reduce_cond = threading.Condition()

        # 用于broadcast阶段的最终梯度
        self.final_gradients = None
        self.broadcast_ready = False
        self.broadcast_cond = threading.Condition()

        # 创建 TreeAllReduce 的服务端
        self.server = tree_allreduce.TreeAllReduceServer(
            host=self.host,
            worker_index=self.worker_index,
            total_workers=self.worker_num,
            vars_init_fn=self._variable_weights_init_callback,
            reduce_fn=self._reduce_callback,
            broadcast_fn=self._broadcast_callback
        )
        self.server.serve()

        # 创建客户端
        self.client = tree_allreduce.TreeAllReduceClient(
            worker_hosts=self.workers,
            worker_index=self.worker_index,
            total_workers=self.worker_num
        )

        print(f'[TREE] Worker {self.worker_index} initialized: parent={self.parent_id}, children={self.children_ids}')

    # def _build_tree_topology(self):
    #     """构建二叉树拓扑结构"""
    #     # 父节点计算
    #     self.parent_id = None if self.worker_index == 0 else (self.worker_index - 1) // 2
    #
    #     # 子节点计算
    #     left_child = 2 * self.worker_index + 1
    #     right_child = 2 * self.worker_index + 2
    #
    #     self.children_ids = []
    #     if left_child < self.worker_num:
    #         self.children_ids.append(left_child)
    #     if right_child < self.worker_num:
    #         self.children_ids.append(right_child)
    #
    #     self.is_root = (self.worker_index == 0)
    #     self.is_leaf = len(self.children_ids) == 0
    #
    # def _variable_weights_init(self):
    #     """发送本地初始参数"""
    #     var_weights_dict = {var.name: var.value for var in self.variables}
    #     print(f'[INIT] Worker {self.worker_index} initializing weights')
    #
    #     if self.worker_index == 0:
    #         # 根节点直接发送给子节点
    #         self.client.variable_weights_init(var_weights_dict)
    #     else:
    #         # 其他节点等待父节点初始化
    #         self.init_cond.acquire()
    #         while not self.is_init:
    #             self.init_cond.wait()
    #         self.init_cond.release()
    #         # 然后向子节点传播
    #         if not self.is_leaf:
    #             self.client.variable_weights_init(var_weights_dict)
    #
    # def _variable_weights_init_callback(self, var_weights_dict):
    #     """接收上游参数初始化"""
    #     if self.worker_index != 0:
    #         print(f'[INIT] Worker {self.worker_index} receiving weights from parent')
    #         for var_name, weights in var_weights_dict.items():
    #             update_node_value_in_graph(var_name, weights)
    #
    #     # 标记初始化完成
    #     self.init_cond.acquire()
    #     self.is_init = True
    #     self.init_cond.notify_all()
    #     self.init_cond.release()
    #
    # def _reduce_callback(self, child_gradients_dict):
    #     """Reduce阶段：合并子节点梯度"""
    #     print(f'[REDUCE] Worker {self.worker_index} received gradients from {len(child_gradients_dict)} children')
    #
    #     with self.reduce_cond:
    #         # 合并所有子节点的梯度
    #         merged_gradients = {}
    #         total_samples = 0
    #
    #         for child_id, child_data in child_gradients_dict.items():
    #             child_grads = child_data['gradients']
    #             child_samples = child_data.get('acc_no', 1)
    #             total_samples += child_samples
    #
    #             for var, grad in child_grads.items():
    #                 if var not in merged_gradients:
    #                     merged_gradients[var] = grad
    #                 else:
    #                     merged_gradients[var] += grad
    #
    #         # 加上自己的梯度
    #         local_samples = self.optimizer.acc_no
    #         total_samples += local_samples
    #
    #         for var, grad in self.optimizer.acc_gradient.items():
    #             if var not in merged_gradients:
    #                 merged_gradients[var] = grad
    #             else:
    #                 merged_gradients[var] += grad
    #
    #         self.children_gradients = merged_gradients
    #         self.received_acc_no = total_samples
    #         self.reduce_ready = True
    #         self.reduce_cond.notify_all()
    #
    # def _broadcast_callback(self, final_gradients):
    #     """Broadcast阶段：接收最终梯度"""
    #     print(f'[BROADCAST] Worker {self.worker_index} received final gradients')
    #
    #     with self.broadcast_cond:
    #         self.final_gradients = final_gradients
    #         self.broadcast_ready = True
    #         self.broadcast_cond.notify_all()
    #
    # def _optimizer_update(self):
    #     """执行一次Tree AllReduce梯度同步与参数更新"""
    #
    #     # Phase 1: Reduce阶段 - 从叶子到根聚合梯度
    #     if not self.is_leaf:
    #         # 等待所有子节点发送梯度
    #         with self.reduce_cond:
    #             while not self.reduce_ready:
    #                 self.reduce_cond.wait()
    #
    #         # 使用聚合后的梯度
    #         aggregated_gradients = self.children_gradients
    #         aggregated_samples = self.received_acc_no
    #     else:
    #         # 叶子节点只使用本地梯度
    #         aggregated_gradients = self.optimizer.acc_gradient
    #         aggregated_samples = self.optimizer.acc_no
    #
    #     # 如果不是根节点，向父节点发送聚合后的梯度
    #     if not self.is_root:
    #         print(f'[REDUCE] Worker {self.worker_index} sending gradients to parent {self.parent_id}')
    #         self.client.send_gradients_to_parent(aggregated_gradients, aggregated_samples)
    #
    #     # Phase 2: Broadcast阶段 - 从根到叶子分发最终梯度
    #     if self.is_root:
    #         # 根节点计算最终梯度（平均化）
    #         final_gradients = {}
    #         for var, grad in aggregated_gradients.items():
    #             final_gradients[var] = grad / self.worker_num
    #
    #         print(f'[BROADCAST] Root worker {self.worker_index} broadcasting final gradients')
    #         # 更新自己的参数
    #         self.optimizer.apply_gradients(final_gradients, summarize=False, acc_no=self.optimizer.acc_no)
    #
    #         # 向子节点广播
    #         if not self.is_leaf:
    #             self.client.broadcast_to_children(final_gradients)
    #     else:
    #         # 非根节点等待接收最终梯度
    #         with self.broadcast_cond:
    #             while not self.broadcast_ready:
    #                 self.broadcast_cond.wait()
    #
    #         # 更新本地参数
    #         self.optimizer.apply_gradients(self.final_gradients, summarize=False, acc_no=self.optimizer.acc_no)
    #
    #         # 继续向子节点广播
    #         if not self.is_leaf:
    #             self.client.broadcast_to_children(self.final_gradients)
    #
    #     # 重置状态为下一轮做准备
    #     with self.reduce_cond:
    #         self.children_gradients = {}
    #         self.reduce_ready = False
    #
    #     with self.broadcast_cond:
    #         self.final_gradients = None
    #         self.broadcast_ready = False

class DistTrainerTreeAllReduce(Trainer):
    """
    Tree All-Reduce 模式的分布式训练 - 修复版本
    """

    def __init__(self, *args, **kargs):
        Trainer.__init__(self, *args, **kargs)

        # 集群信息 - 修复：确保worker数量固定
        self.cluster_conf = kargs['cluster_conf']
        self.worker_index = kargs['worker_index']
        self.total_workers = kargs.get('total_workers', len(self.cluster_conf['workers']))  # 新增

        self.workers = self.cluster_conf['workers']
        self.worker_num = self.total_workers  # 使用固定的total_workers
        self.host = self.workers[self.worker_index]

        # 构建固定的二叉树拓扑
        self._build_tree_topology()

        # 本节点是否已被初始化
        self.is_init = False
        self.init_cond = threading.Condition()

        # 获取所有可训练变量
        self.variables = get_trainable_variables_from_graph()

        # 用于reduce阶段的梯度聚合
        self.children_gradients = {}
        self.children_ready_count = 0
        self.reduce_ready = False
        self.reduce_cond = threading.Condition()

        # 用于broadcast阶段的最终梯度
        self.final_gradients = None
        self.broadcast_ready = False
        self.broadcast_cond = threading.Condition()

        # 简化的服务器（移除gRPC依赖）
        self.server_thread = None
        self.start_server()

        print(
            f'[TREE] Worker {self.worker_index} topology: parent={self.parent_id}, children={self.children_ids}, total_workers={self.total_workers}')

    def _build_tree_topology(self):
        """构建固定的二叉树拓扑结构"""
        # 父节点计算
        self.parent_id = None if self.worker_index == 0 else (self.worker_index - 1) // 2

        # 子节点计算 - 基于total_workers，不是当前连接的workers
        left_child = 2 * self.worker_index + 1
        right_child = 2 * self.worker_index + 2

        self.children_ids = []
        if left_child < self.total_workers:
            self.children_ids.append(left_child)
        if right_child < self.total_workers:
            self.children_ids.append(right_child)

        self.is_root = (self.worker_index == 0)
        self.is_leaf = len(self.children_ids) == 0

    def start_server(self):
        """启动简化的服务器"""

        def server_loop():
            print(f"[TREE] Worker {self.worker_index} server listening on {self.host}")
            # 简化实现：使用文件或内存队列进行通信
            # 这里只是占位，实际需要实现具体的通信机制

        self.server_thread = threading.Thread(target=server_loop, daemon=True)
        self.server_thread.start()

    def _variable_weights_init(self):
        """修复的权重初始化流程"""
        var_weights_dict = {var.name: var.value for var in self.variables}
        print(f'[INIT] Worker {self.worker_index} initializing weights')

        # 添加启动延迟，确保所有workers都启动
        time.sleep(self.worker_index * 0.5 + 2)  # 错开启动时间

        if self.worker_index == 0:
            # 根节点等待一段时间确保所有workers就绪
            print(f'[INIT] Root worker waiting for all {self.total_workers} workers to be ready...')
            time.sleep(3)  # 等待其他workers启动

            # 标记自己已初始化
            with self.init_cond:
                self.is_init = True
                self.init_cond.notify_all()

            # 向子节点发送初始化信号（简化实现）
            self._init_children(var_weights_dict)
        else:
            # 非根节点等待父节点初始化
            print(f'[INIT] Worker {self.worker_index} waiting for parent initialization...')

            # 简化：等待固定时间
            time.sleep(5)

            with self.init_cond:
                self.is_init = True
                self.init_cond.notify_all()

            # 向子节点传播初始化
            if not self.is_leaf:
                self._init_children(var_weights_dict)

    def _init_children(self, var_weights_dict):
        """向子节点发送初始化数据"""
        for child_id in self.children_ids:
            print(f'[INIT] Worker {self.worker_index} initializing child {child_id}')
            # 简化实现：这里应该有实际的通信逻辑

    def _optimizer_update(self):
        """修复的Tree AllReduce梯度同步"""
        print(f'[ALLREDUCE] Worker {self.worker_index} starting allreduce round')

        try:
            # Phase 1: Reduce阶段 - 从叶子到根聚合梯度
            self._reduce_phase()

            # Phase 2: Broadcast阶段 - 从根到叶子分发最终梯度
            self._broadcast_phase()

            print(f'[ALLREDUCE] Worker {self.worker_index} completed allreduce round')

        except Exception as e:
            print(f'[ERROR] Worker {self.worker_index} allreduce failed: {e}')
            # 回退到本地更新
            self.optimizer.update()

    def _reduce_phase(self):
        """Reduce阶段：从叶子到根聚合梯度"""
        if not self.is_leaf:
            # 等待子节点发送梯度（简化：等待固定时间）
            print(f'[REDUCE] Worker {self.worker_index} waiting for {len(self.children_ids)} children')
            time.sleep(1)  # 简化的等待

            # 模拟接收子节点梯度
            self._simulate_receive_children_gradients()

        # 如果不是根节点，向父节点发送聚合梯度
        if not self.is_root:
            aggregated_gradients = self._get_aggregated_gradients()
            print(f'[REDUCE] Worker {self.worker_index} sending gradients to parent {self.parent_id}')
            self._send_to_parent(aggregated_gradients)

    def _broadcast_phase(self):
        """Broadcast阶段：从根到叶子分发最终梯度"""
        if self.is_root:
            # 根节点计算最终梯度
            final_gradients = self._compute_final_gradients()
            print(f'[BROADCAST] Root worker broadcasting final gradients')

            # 更新自己的参数
            self._apply_final_gradients(final_gradients)

            # 向子节点广播
            self._broadcast_to_children(final_gradients)
        else:
            # 等待父节点的最终梯度
            print(f'[BROADCAST] Worker {self.worker_index} waiting for final gradients')
            time.sleep(1)  # 简化等待

            # 模拟接收最终梯度
            final_gradients = self._simulate_receive_final_gradients()

            # 更新参数
            self._apply_final_gradients(final_gradients)

            # 继续向子节点广播
            if not self.is_leaf:
                self._broadcast_to_children(final_gradients)

    def _simulate_receive_children_gradients(self):
        """模拟接收子节点梯度（简化实现）"""
        # 这里应该是真实的网络通信，现在用本地梯度模拟
        self.children_gradients = {}
        for child_id in self.children_ids:
            # 简化：使用本地梯度的副本模拟子节点梯度
            self.children_gradients[child_id] = dict(self.optimizer.acc_gradient)

    def _get_aggregated_gradients(self):
        """获取聚合后的梯度"""
        aggregated = dict(self.optimizer.acc_gradient)

        # 加入子节点的梯度
        for child_gradients in self.children_gradients.values():
            for var, grad in child_gradients.items():
                if var in aggregated:
                    aggregated[var] += grad

        return aggregated

    def _send_to_parent(self, gradients):
        """向父节点发送梯度（简化实现）"""
        # 这里应该有实际的网络通信逻辑
        pass

    def _compute_final_gradients(self):
        """计算最终梯度（根节点）"""
        final_gradients = self._get_aggregated_gradients()

        # 平均化梯度
        for var, grad in final_gradients.items():
            final_gradients[var] = grad / self.total_workers

        return final_gradients

    def _simulate_receive_final_gradients(self):
        """模拟接收最终梯度"""
        # 简化：返回本地梯度的平均值
        final_gradients = {}
        for var, grad in self.optimizer.acc_gradient.items():
            final_gradients[var] = grad / self.total_workers
        return final_gradients

    def _apply_final_gradients(self, final_gradients):
        """应用最终梯度更新参数"""
        self.optimizer.apply_gradients(final_gradients, summarize=False, acc_no=self.optimizer.acc_no)

    def _broadcast_to_children(self, final_gradients):
        """向子节点广播最终梯度"""
        for child_id in self.children_ids:
            print(f'[BROADCAST] Worker {self.worker_index} broadcasting to child {child_id}')
            # 这里应该有实际的网络通信逻辑