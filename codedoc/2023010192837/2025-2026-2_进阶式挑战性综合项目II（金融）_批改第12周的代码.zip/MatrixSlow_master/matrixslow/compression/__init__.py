# -*- coding: utf-8 -*-
"""
模型压缩模块初始化文件 - 完整修复版
matrixslow/compression/__init__.py
"""

from .pruning import StructuredPruner, AdaptivePruner
from .quantization import MixedPrecisionQuantizer, QuantizationType, LayerSensitivity

__all__ = [
    'StructuredPruner', 'AdaptivePruner',
    'MixedPrecisionQuantizer', 'QuantizationType', 'LayerSensitivity'
]

__version__ = "1.0.0"
__author__ = "MatrixSlow Compression Team"