# -*- coding: utf-8 -*-
"""
混合精度量化实现 - 完整修复版
支持INT8、INT16和FP16的混合精度量化，并提供敏感性分析
修复了空数组和数值稳定性问题
"""

import numpy as np
from typing import Dict, List, Tuple, Union, Optional
from enum import Enum


class QuantizationType(Enum):
    """量化类型枚举"""
    INT8 = "int8"
    INT16 = "int16"
    FP16 = "fp16"
    FP32 = "fp32"


class LayerSensitivity(Enum):
    """层敏感性等级"""
    LOW = "low"  # 低敏感性，可以使用INT8
    MEDIUM = "medium"  # 中等敏感性，使用INT16
    HIGH = "high"  # 高敏感性，使用FP16
    CRITICAL = "critical"  # 关键层，保持FP32


class MixedPrecisionQuantizer:
    """
    混合精度量化器
    支持不同层使用不同精度，并提供敏感性分析
    """

    def __init__(self,
                 default_precision: QuantizationType = QuantizationType.INT8,
                 sensitivity_threshold: float = 0.1,
                 calibration_samples: int = 100):
        """
        初始化混合精度量化器

        Args:
            default_precision: 默认量化精度
            sensitivity_threshold: 敏感性阈值
            calibration_samples: 校准样本数量
        """
        self.default_precision = default_precision
        self.sensitivity_threshold = sensitivity_threshold
        self.calibration_samples = calibration_samples

        # 存储每层的量化配置
        self.layer_quantization_config = {}
        self.layer_statistics = {}
        self.quantization_parameters = {}

    def analyze_weight_distribution(self, weights: np.matrix, layer_name: str) -> Dict:
        """
        分析权重分布特征 - 修复版本

        修复内容：
        1. 检查权重矩阵是否为空
        2. 处理剪枝后可能出现的空数组情况
        3. 添加数值稳定性检查
        """
        weights_flat = np.array(weights).flatten()

        # 修复1：检查权重数组是否为空
        if weights_flat.size == 0:
            print(f"⚠️  警告: {layer_name} 权重为空数组，跳过分析")
            return {
                'mean': 0.0,
                'std': 0.0,
                'min': 0.0,
                'max': 0.0,
                'range': 0.0,
                'percentile_99': 0.0,
                'percentile_1': 0.0,
                'outlier_ratio': 0.0,
                'dynamic_range': 0.0,
                'is_empty': True
            }

        # 修复2：处理全零数组的情况
        if np.all(weights_flat == 0):
            print(f"⚠️  警告: {layer_name} 所有权重为零，使用默认值")
            return {
                'mean': 0.0,
                'std': 0.0,
                'min': 0.0,
                'max': 0.0,
                'range': 0.0,
                'percentile_99': 0.0,
                'percentile_1': 0.0,
                'outlier_ratio': 0.0,
                'dynamic_range': 0.0,
                'is_zero': True
            }

        # 修复3：安全计算统计信息
        try:
            stats = {
                'mean': float(np.mean(weights_flat)),
                'std': float(np.std(weights_flat)),
                'min': float(np.min(weights_flat)),
                'max': float(np.max(weights_flat)),
                'range': float(np.max(weights_flat) - np.min(weights_flat)),
                'percentile_99': float(np.percentile(weights_flat, 99)),
                'percentile_1': float(np.percentile(weights_flat, 1)),
                'outlier_ratio': self._calculate_outlier_ratio(weights_flat),
                'dynamic_range': self._calculate_dynamic_range(weights_flat)
            }

            self.layer_statistics[layer_name] = stats
            return stats

        except Exception as e:
            print(f"⚠️  警告: {layer_name} 统计计算失败: {e}")
            # 返回安全的默认值
            return {
                'mean': 0.0,
                'std': 1.0,  # 非零std避免除零错误
                'min': -1.0,
                'max': 1.0,
                'range': 2.0,
                'percentile_99': 1.0,
                'percentile_1': -1.0,
                'outlier_ratio': 0.0,
                'dynamic_range': 1.0,
                'error': str(e)
            }

    def _calculate_outlier_ratio(self, values: np.ndarray, threshold: float = 3.0) -> float:
        """计算异常值比例 - 修复版本"""
        if values.size == 0:
            return 0.0

        try:
            mean = np.mean(values)
            std = np.std(values)

            # 避免除零错误
            if std < 1e-10:
                return 0.0

            outliers = np.abs(values - mean) > threshold * std
            return float(np.sum(outliers) / len(values))

        except Exception:
            return 0.0

    def _calculate_dynamic_range(self, values: np.ndarray) -> float:
        """计算动态范围 - 修复版本"""
        if values.size == 0:
            return 0.0

        try:
            non_zero_values = values[values != 0]
            if len(non_zero_values) == 0:
                return 0.0

            abs_values = np.abs(non_zero_values)
            max_val = np.max(abs_values)
            min_val = np.min(abs_values)

            # 避免除零和log错误
            if min_val <= 0 or max_val <= 0:
                return 0.0

            return float(np.log10(max_val / min_val))

        except Exception:
            return 0.0

    def determine_layer_sensitivity(self, weights: np.matrix, layer_name: str) -> LayerSensitivity:
        """
        确定层的敏感性等级 - 修复版本
        """
        # 修复：首先检查权重是否有效
        if weights.size == 0:
            print(f"⚠️  {layer_name} 权重为空，设为CRITICAL保护")
            return LayerSensitivity.CRITICAL

        weights_flat = np.array(weights).flatten()

        # 修复：检查是否全为零
        if np.all(weights_flat == 0):
            print(f"⚠️  {layer_name} 权重全为零，设为LOW敏感性")
            return LayerSensitivity.LOW

        # 获取权重分布统计
        stats = self.analyze_weight_distribution(weights, layer_name)

        # 修复：检查统计信息是否有效
        if 'error' in stats or 'is_empty' in stats:
            print(f"⚠️  {layer_name} 统计信息无效，使用默认MEDIUM敏感性")
            return LayerSensitivity.MEDIUM

        # 基于多个指标判断敏感性
        sensitivity_score = 0

        try:
            # 1. 动态范围检查
            dynamic_range = stats.get('dynamic_range', 0.0)
            if dynamic_range > 6:
                sensitivity_score += 2
            elif dynamic_range > 4:
                sensitivity_score += 1

            # 2. 异常值比例检查
            outlier_ratio = stats.get('outlier_ratio', 0.0)
            if outlier_ratio > 0.1:
                sensitivity_score += 2
            elif outlier_ratio > 0.05:
                sensitivity_score += 1

            # 3. 标准差检查
            std = stats.get('std', 0.0)
            mean = abs(stats.get('mean', 0.0))
            if mean > 1e-10:  # 避免除零
                normalized_std = std / mean
                if normalized_std > 2.0:
                    sensitivity_score += 2
                elif normalized_std > 1.0:
                    sensitivity_score += 1

            # 4. 特殊层类型判断
            if 'output' in layer_name.lower() or 'classifier' in layer_name.lower():
                sensitivity_score += 2

        except Exception as e:
            print(f"⚠️  {layer_name} 敏感性计算出错: {e}，使用默认值")
            return LayerSensitivity.MEDIUM

        # 根据得分确定敏感性等级
        if sensitivity_score >= 5:
            return LayerSensitivity.CRITICAL
        elif sensitivity_score >= 3:
            return LayerSensitivity.HIGH
        elif sensitivity_score >= 1:
            return LayerSensitivity.MEDIUM
        else:
            return LayerSensitivity.LOW

    def get_quantization_type_for_sensitivity(self, sensitivity: LayerSensitivity) -> QuantizationType:
        """
        根据敏感性确定量化类型
        """
        mapping = {
            LayerSensitivity.LOW: QuantizationType.INT8,
            LayerSensitivity.MEDIUM: QuantizationType.INT16,
            LayerSensitivity.HIGH: QuantizationType.FP16,
            LayerSensitivity.CRITICAL: QuantizationType.FP32
        }
        return mapping[sensitivity]

    def calculate_quantization_parameters(self, weights: np.matrix, quant_type: QuantizationType) -> Dict:
        """
        计算量化参数 - 修复版本
        """
        # 修复：检查权重有效性
        if weights.size == 0:
            print(f"⚠️  权重为空，返回默认量化参数")
            return {'scale': 1.0, 'zero_point': 0, 'type': quant_type.value, 'is_empty': True}

        weights_flat = np.array(weights).flatten()

        # 修复：处理浮点精度
        if quant_type == QuantizationType.FP32:
            return {'scale': 1.0, 'zero_point': 0, 'type': 'fp32'}
        elif quant_type == QuantizationType.FP16:
            return {'scale': 1.0, 'zero_point': 0, 'type': 'fp16'}

        # 修复：安全计算min/max
        try:
            w_min = float(np.min(weights_flat))
            w_max = float(np.max(weights_flat))
        except Exception:
            print(f"⚠️  无法计算权重范围，使用默认值")
            w_min, w_max = -1.0, 1.0

        # 修复：处理相等的min/max值
        if abs(w_max - w_min) < 1e-10:
            print(f"⚠️  权重范围过小，调整为默认范围")
            scale = 1.0
            zero_point = 0

            return {
                'scale': scale,
                'zero_point': zero_point,
                'qmin': 0,
                'qmax': 255,
                'type': quant_type.value,
                'constant_weights': True
            }

        # 正常的量化参数计算
        if quant_type == QuantizationType.INT8:
            qmin, qmax = -128, 127
        elif quant_type == QuantizationType.INT16:
            qmin, qmax = -32768, 32767
        else:
            raise ValueError(f"Unsupported quantization type: {quant_type}")

        # 计算scale和zero_point
        scale = (w_max - w_min) / (qmax - qmin)
        zero_point = qmin - w_min / scale
        zero_point = int(np.round(np.clip(zero_point, qmin, qmax)))

        return {
            'scale': scale,
            'zero_point': zero_point,
            'qmin': qmin,
            'qmax': qmax,
            'type': quant_type.value
        }

    def quantize_weights(self, weights: np.matrix, quant_params: Dict) -> np.matrix:
        """
        量化权重 - 修复版本
        """
        # 修复：处理特殊情况
        if 'is_empty' in quant_params:
            print(f"⚠️  权重为空，返回原权重")
            return weights

        if 'constant_weights' in quant_params:
            print(f"⚠️  常数权重，跳过量化")
            return weights

        # 处理浮点精度
        if quant_params['type'] == 'fp32':
            return weights
        elif quant_params['type'] == 'fp16':
            try:
                return np.mat(weights.astype(np.float16))
            except Exception:
                print(f"⚠️  FP16转换失败，保持原精度")
                return weights

        # 整数量化处理
        try:
            scale = quant_params['scale']
            zero_point = quant_params['zero_point']
            qmin = quant_params['qmin']
            qmax = quant_params['qmax']

            # 执行量化
            quantized = np.round(weights / scale + zero_point)
            quantized = np.clip(quantized, qmin, qmax)

            # 反量化
            dequantized = (quantized - zero_point) * scale

            return np.mat(dequantized)

        except Exception as e:
            print(f"⚠️  量化失败: {e}，返回原权重")
            return weights

    def quantize_layer(self, weights: np.matrix, layer_name: str,
                       force_precision: Optional[QuantizationType] = None) -> Tuple[np.matrix, Dict]:
        """
        量化单个层 - 修复版本
        """
        # 修复：增加输入验证
        if weights.size == 0:
            print(f"⚠️  {layer_name} 权重为空，跳过量化")
            return weights, {
                'layer_name': layer_name,
                'quantization_type': 'skipped',
                'error': 'empty_weights'
            }

        try:
            # 确定量化精度
            if force_precision:
                quant_type = force_precision
                sensitivity = LayerSensitivity.LOW  # 占位符
            else:
                sensitivity = self.determine_layer_sensitivity(weights, layer_name)
                quant_type = self.get_quantization_type_for_sensitivity(sensitivity)

            # 计算量化参数
            quant_params = self.calculate_quantization_parameters(weights, quant_type)

            # 执行量化
            quantized_weights = self.quantize_weights(weights, quant_params)

            # 记录配置
            quantization_info = {
                'layer_name': layer_name,
                'original_shape': weights.shape,
                'quantization_type': quant_type.value,
                'sensitivity': sensitivity.value if not force_precision else 'forced',
                'quantization_params': quant_params,
                'compression_ratio': self._calculate_compression_ratio(quant_type),
                'quantization_error': self._calculate_quantization_error(weights, quantized_weights)
            }

            self.layer_quantization_config[layer_name] = quantization_info
            self.quantization_parameters[layer_name] = quant_params

            print(f"量化层 {layer_name}: {quant_type.value}, "
                  f"敏感性: {sensitivity.value if not force_precision else 'forced'}, "
                  f"压缩比: {quantization_info['compression_ratio']:.1f}x, "
                  f"量化误差: {quantization_info['quantization_error']:.6f}")

            return quantized_weights, quantization_info

        except Exception as e:
            print(f"❌ {layer_name} 量化失败: {e}")
            return weights, {
                'layer_name': layer_name,
                'quantization_type': 'failed',
                'error': str(e)
            }

    def _calculate_compression_ratio(self, quant_type: QuantizationType) -> float:
        """计算压缩比例"""
        base_bits = 32  # FP32
        if quant_type == QuantizationType.INT8:
            return base_bits / 8
        elif quant_type == QuantizationType.INT16:
            return base_bits / 16
        elif quant_type == QuantizationType.FP16:
            return base_bits / 16
        else:
            return 1.0

    def _calculate_quantization_error(self, original: np.matrix, quantized: np.matrix) -> float:
        """计算量化误差 - 修复版本"""
        try:
            if original.shape != quantized.shape:
                return float('inf')  # 形状不匹配

            diff = np.array(original - quantized)
            if diff.size == 0:
                return 0.0

            mse = np.mean(diff ** 2)
            return float(mse)

        except Exception:
            return 0.0  # 计算失败时返回0

    def quantize_full_model(self, layer_weights: Dict[str, np.matrix],
                            custom_precision: Optional[Dict[str, QuantizationType]] = None) -> Dict[str, np.matrix]:
        """
        量化整个模型
        """
        quantized_model = {}

        print("开始混合精度量化...")
        print("=" * 50)

        for layer_name, weights in layer_weights.items():
            # 检查是否有自定义精度设置
            force_precision = None
            if custom_precision and layer_name in custom_precision:
                force_precision = custom_precision[layer_name]

            # 量化层
            quantized_weights, _ = self.quantize_layer(weights, layer_name, force_precision)
            quantized_model[layer_name] = quantized_weights

        print("=" * 50)
        self._print_quantization_summary()

        return quantized_model

    def _print_quantization_summary(self):
        """打印量化摘要"""
        print("量化摘要:")

        type_counts = {}
        total_compression = 0
        total_error = 0
        layer_count = 0

        for layer_name, config in self.layer_quantization_config.items():
            quant_type = config['quantization_type']
            type_counts[quant_type] = type_counts.get(quant_type, 0) + 1
            total_compression += config['compression_ratio']
            total_error += config['quantization_error']
            layer_count += 1

        print(f"量化层数: {layer_count}")
        print("精度分布:")
        for quant_type, count in type_counts.items():
            print(f"  {quant_type}: {count} 层 ({count / layer_count:.1%})")

        if layer_count > 0:
            avg_compression = total_compression / layer_count
            avg_error = total_error / layer_count
            print(f"平均压缩比: {avg_compression:.2f}x")
            print(f"平均量化误差: {avg_error:.6f}")

    def get_quantization_statistics(self) -> Dict:
        """获取量化统计信息"""
        return {
            'layer_configs': self.layer_quantization_config,
            'layer_statistics': self.layer_statistics,
            'quantization_parameters': self.quantization_parameters
        }