# -*- coding: utf-8 -*-
"""
结构化剪枝实现 - 完整修复版
支持通道级别的结构化剪枝，可以直接减少模型参数和计算量
修复了过度剪枝和空数组问题
"""

import numpy as np
import copy
from typing import Dict, List, Tuple, Optional


class StructuredPruner:
    """
    结构化剪枝器，支持卷积层和全连接层的通道/神经元级别剪枝
    """

    def __init__(self, pruning_ratio: float = 0.5, importance_metric: str = "l1_norm"):
        """
        初始化结构化剪枝器

        Args:
            pruning_ratio: 剪枝比例，0-1之间
            importance_metric: 重要性度量方法，支持 "l1_norm", "l2_norm", "variance"
        """
        self.pruning_ratio = pruning_ratio
        self.importance_metric = importance_metric
        self.pruned_indices = {}  # 记录每层被剪枝的通道/神经元索引

    def calculate_channel_importance(self, weights: np.matrix) -> np.ndarray:
        """
        计算通道重要性得分 - 修复版本
        """
        # 修复1：检查输入有效性
        if weights.size == 0:
            print(f"⚠️  权重矩阵为空")
            return np.array([])

        if weights.shape[0] == 0:
            print(f"⚠️  输出通道数为0")
            return np.array([])

        try:
            if self.importance_metric == "l1_norm":
                importance_scores = np.array([
                    np.sum(np.abs(weights[i, :]))
                    for i in range(weights.shape[0])
                ])
            elif self.importance_metric == "l2_norm":
                importance_scores = np.array([
                    np.sqrt(np.sum(np.power(weights[i, :], 2)))
                    for i in range(weights.shape[0])
                ])
            elif self.importance_metric == "variance":
                importance_scores = np.array([
                    np.var(weights[i, :]) if weights[i, :].size > 0 else 0.0
                    for i in range(weights.shape[0])
                ])
            else:
                raise ValueError(f"Unsupported importance metric: {self.importance_metric}")

            # 修复2：处理异常值
            importance_scores = np.nan_to_num(importance_scores, nan=0.0, posinf=1e6, neginf=0.0)

            # 修复3：确保所有得分都是有限的正数或零
            importance_scores = np.abs(importance_scores)

            return importance_scores

        except Exception as e:
            print(f"⚠️  重要性计算失败: {e}")
            # 返回均匀的重要性得分
            return np.ones(weights.shape[0])

    def get_pruning_indices(self, importance_scores: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """
        根据重要性得分确定需要剪枝的通道索引 - 修复版本

        修复内容：
        1. 确保至少保留足够的通道
        2. 处理重要性得分异常的情况
        3. 添加更严格的保护机制
        """
        num_channels = len(importance_scores)

        # 修复1：更严格的最小保留通道数
        if num_channels <= 2:
            print(f"⚠️  通道数过少({num_channels})，跳过剪枝")
            keep_indices = np.arange(num_channels)
            prune_indices = np.array([])
            return keep_indices, prune_indices

        # 修复2：限制最大剪枝比例，避免过度剪枝
        max_pruning_ratio = 0.8  # 最多剪枝80%
        effective_pruning_ratio = min(self.pruning_ratio, max_pruning_ratio)

        # 修复3：确保至少保留2个通道
        num_keep = max(2, int(num_channels * (1 - effective_pruning_ratio)))
        num_keep = min(num_keep, num_channels)  # 不能超过总数

        # 修复4：处理importance_scores的异常情况
        if np.any(np.isnan(importance_scores)) or np.any(np.isinf(importance_scores)):
            print(f"⚠️  发现异常重要性得分，使用随机选择")
            indices = np.arange(num_channels)
            np.random.shuffle(indices)
            keep_indices = indices[:num_keep]
            prune_indices = indices[num_keep:]
        else:
            # 正常的重要性排序
            sorted_indices = np.argsort(importance_scores)[::-1]  # 降序排列
            keep_indices = sorted_indices[:num_keep]
            prune_indices = sorted_indices[num_keep:]

        # 修复5：确保索引有效
        keep_indices = np.sort(keep_indices)  # 保持原有顺序
        prune_indices = np.sort(prune_indices)

        print(f"   保留通道: {len(keep_indices)}/{num_channels} "
              f"(实际剪枝比例: {len(prune_indices) / num_channels:.1%})")

        return keep_indices, prune_indices

    def prune_conv_layer(self, conv_weights: np.matrix, layer_name: str) -> np.matrix:
        """
        对卷积层进行结构化剪枝 - 修复版本
        """
        print(f"\n🔍 分析卷积层 {layer_name}:")
        print(f"   原始形状: {conv_weights.shape}")

        # 修复1：检查权重矩阵有效性
        if conv_weights.size == 0:
            print(f"⚠️  {layer_name} 权重为空，跳过剪枝")
            return conv_weights

        if conv_weights.shape[0] <= 2:
            print(f"⚠️  {layer_name} 输出通道数太少({conv_weights.shape[0]})，跳过剪枝")
            return conv_weights

        try:
            # 计算每个输出通道的重要性
            importance_scores = self.calculate_channel_importance(conv_weights)

            # 检查重要性得分的有效性
            if len(importance_scores) == 0:
                print(f"⚠️  {layer_name} 重要性得分为空，跳过剪枝")
                return conv_weights

            # 获取剪枝索引
            keep_indices, prune_indices = self.get_pruning_indices(importance_scores)

            # 如果没有需要剪枝的通道，直接返回
            if len(prune_indices) == 0:
                print(f"⚠️  {layer_name} 无通道需要剪枝")
                return conv_weights

            # 记录剪枝信息
            self.pruned_indices[layer_name] = {
                'keep_indices': keep_indices,
                'prune_indices': prune_indices,
                'original_shape': conv_weights.shape,
                'pruned_shape': (len(keep_indices), conv_weights.shape[1]),
                'importance_scores': importance_scores,
                'pruning_ratio_actual': len(prune_indices) / conv_weights.shape[0]
            }

            # 执行剪枝
            pruned_weights = conv_weights[keep_indices, :]

            print(f"   ✂️  剪枝结果: {conv_weights.shape} -> {pruned_weights.shape}")
            print(f"   📊 实际剪枝比例: {len(prune_indices) / conv_weights.shape[0]:.2%}")

            return pruned_weights

        except Exception as e:
            print(f"❌ {layer_name} 剪枝失败: {e}")
            return conv_weights

    def prune_fc_layer(self, fc_weights: np.matrix, layer_name: str, is_input_layer: bool = False) -> np.matrix:
        """
        对全连接层进行结构化剪枝 - 修复版本
        """
        print(f"\n🔍 分析全连接层 {layer_name}:")
        print(f"   原始形状: {fc_weights.shape}")

        # 修复1：检查权重矩阵有效性
        if fc_weights.size == 0:
            print(f"⚠️  {layer_name} 权重为空，跳过剪枝")
            return fc_weights

        # 修复2：对输出层更保守的处理
        if 'output' in layer_name.lower():
            if fc_weights.shape[0] <= 10:  # 分类数较少时
                print(f"⚠️  {layer_name} 是输出层且类别数较少，跳过剪枝")
                return fc_weights
            else:
                # 输出层使用更小的剪枝比例
                original_ratio = self.pruning_ratio
                self.pruning_ratio = min(0.2, original_ratio)  # 最多剪枝20%
                print(f"   🛡️  输出层保护：剪枝比例调整为 {self.pruning_ratio:.1%}")

        if fc_weights.shape[0] <= 3:
            print(f"⚠️  {layer_name} 神经元数太少({fc_weights.shape[0]})，跳过剪枝")
            return fc_weights

        try:
            # 计算每个输出神经元的重要性
            importance_scores = self.calculate_channel_importance(fc_weights)

            # 获取剪枝索引
            keep_indices, prune_indices = self.get_pruning_indices(importance_scores)

            # 如果没有需要剪枝的神经元，直接返回
            if len(prune_indices) == 0:
                print(f"⚠️  {layer_name} 无神经元需要剪枝")
                if 'output' in layer_name.lower():
                    self.pruning_ratio = original_ratio  # 恢复原始剪枝比例
                return fc_weights

            # 记录剪枝信息
            self.pruned_indices[layer_name] = {
                'keep_indices': keep_indices,
                'prune_indices': prune_indices,
                'original_shape': fc_weights.shape,
                'pruned_shape': (len(keep_indices), fc_weights.shape[1]),
                'importance_scores': importance_scores,
                'pruning_ratio_actual': len(prune_indices) / fc_weights.shape[0],
                'layer_type': 'fully_connected',
                'is_input_layer': is_input_layer
            }

            # 执行剪枝
            pruned_weights = fc_weights[keep_indices, :]

            print(f"   ✂️  剪枝结果: {fc_weights.shape} -> {pruned_weights.shape}")
            print(f"   📊 实际剪枝比例: {len(prune_indices) / fc_weights.shape[0]:.2%}")

            # 恢复原始剪枝比例（如果修改过）
            if 'output' in layer_name.lower():
                self.pruning_ratio = original_ratio

            return pruned_weights

        except Exception as e:
            print(f"❌ {layer_name} 剪枝失败: {e}")
            # 恢复原始剪枝比例（如果修改过）
            if 'output' in layer_name.lower():
                self.pruning_ratio = original_ratio
            return fc_weights

    def get_pruning_statistics(self) -> Dict:
        """
        获取剪枝统计信息 - 修复版本
        """
        if not self.pruned_indices:
            return {
                'layer_stats': {},
                'total_compression_ratio': 1.0,
                'total_parameter_reduction': 0,
                'message': 'No pruning performed'
            }

        total_original_params = 0
        total_pruned_params = 0

        stats = {
            'layer_stats': {},
            'total_compression_ratio': 1.0,
            'total_parameter_reduction': 0
        }

        try:
            for layer_name, info in self.pruned_indices.items():
                original_params = info['original_shape'][0] * info['original_shape'][1]
                pruned_params = info['pruned_shape'][0] * info['pruned_shape'][1]

                total_original_params += original_params
                total_pruned_params += pruned_params

                stats['layer_stats'][layer_name] = {
                    'original_params': original_params,
                    'pruned_params': pruned_params,
                    'compression_ratio': pruned_params / original_params if original_params > 0 else 1.0,
                    'parameter_reduction': original_params - pruned_params
                }

            if total_original_params > 0:
                stats['total_compression_ratio'] = total_pruned_params / total_original_params
                stats['total_parameter_reduction'] = total_original_params - total_pruned_params

        except Exception as e:
            print(f"⚠️  统计计算失败: {e}")
            stats['error'] = str(e)

        return stats


class AdaptivePruner(StructuredPruner):
    """
    自适应剪枝器，可以根据层的敏感性调整剪枝比例
    """

    def __init__(self, base_pruning_ratio: float = 0.5, sensitivity_threshold: float = 0.1):
        super().__init__(base_pruning_ratio)
        self.base_pruning_ratio = base_pruning_ratio
        self.sensitivity_threshold = sensitivity_threshold
        self.layer_sensitivities = {}

    def calculate_layer_sensitivity(self, layer_weights: np.matrix, layer_name: str) -> float:
        """
        计算层的敏感性（简化版本）
        """
        try:
            # 计算权重的标准差作为敏感性度量
            weight_std = np.std(layer_weights)
            weight_mean = np.mean(np.abs(layer_weights))

            # 敏感性 = 标准差 / 平均绝对值
            sensitivity = weight_std / (weight_mean + 1e-8)
            self.layer_sensitivities[layer_name] = sensitivity

            return sensitivity
        except Exception as e:
            print(f"⚠️  {layer_name} 敏感性计算失败: {e}")
            return 0.1  # 返回默认敏感性

    def adaptive_prune_layer(self, weights: np.matrix, layer_name: str) -> np.matrix:
        """
        根据层敏感性自适应调整剪枝比例
        """
        try:
            sensitivity = self.calculate_layer_sensitivity(weights, layer_name)

            # 根据敏感性调整剪枝比例
            if sensitivity > self.sensitivity_threshold:
                # 敏感层减少剪枝比例
                adjusted_ratio = self.base_pruning_ratio * 0.5
            else:
                # 不敏感层可以增加剪枝比例
                adjusted_ratio = min(self.base_pruning_ratio * 1.2, 0.8)

            # 临时调整剪枝比例
            original_ratio = self.pruning_ratio
            self.pruning_ratio = adjusted_ratio

            print(f"层 {layer_name} 敏感性: {sensitivity:.4f}, 调整剪枝比例: {adjusted_ratio:.2%}")

            # 执行剪枝
            if 'conv' in layer_name.lower():
                result = self.prune_conv_layer(weights, layer_name)
            else:
                result = self.prune_fc_layer(weights, layer_name)

            # 恢复原始剪枝比例
            self.pruning_ratio = original_ratio

            return result

        except Exception as e:
            print(f"❌ {layer_name} 自适应剪枝失败: {e}")
            return weights